<?php
require_once '../../config/database.php';
session_start();
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'] ?? '', ['SUPERADMIN', 'ADMIN', 'POS'])) {
    header("Location: ../../login.php");
    exit;
}
require_once '../../includes/header.php';
?>
<div id="app" v-cloak class="flex flex-col h-screen">
    <nav class="bg-white border-b border-slate-200 h-16 flex items-center justify-between px-6 z-20 shadow-sm relative">
        <div class="flex items-center gap-3">
            <a href="<?php echo $baseUrl; ?>modules/pos/dashboard.php" class="w-10 h-10 bg-slate-100 hover:bg-slate-200 rounded-lg flex items-center justify-center text-slate-600 transition-colors">
                <i class="fas fa-arrow-left text-lg"></i>
            </a>
            <div>
                <h1 class="text-xl font-bold text-slate-800 leading-none">Laporan Penjualan</h1>
                <span class="text-xs text-slate-500 font-medium">POS System</span>
            </div>
        </div>
        <div class="flex items-center gap-4">
            <span class="text-sm font-medium text-slate-500 bg-slate-100 px-3 py-1 rounded-full">{{ currentDateFormatted }}</span>
        </div>
    </nav>

    <main class="flex-1 overflow-y-auto p-8">
        <div class="max-w-5xl mx-auto">
            <div class="flex justify-between items-center mb-6">
                <div class="flex items-center gap-4">
                    <input type="date" v-model="filterDate" @change="fetchData" class="border border-slate-300 rounded-lg px-4 py-2 text-sm focus:outline-none focus:border-blue-500">
                    <h2 class="text-lg font-bold text-slate-700">Transaksi Tanggal {{ formatDate(filterDate) }}</h2>
                </div>
                <button @click="openModal()" class="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-bold hover:bg-blue-700 shadow-sm transition-colors">
                    <i class="fas fa-plus mr-2"></i> Tambah Transaksi
                </button>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div class="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
                    <p class="text-xs font-bold text-slate-500 uppercase mb-1">Total Pemasukan</p>
                    <p class="text-xl font-bold text-emerald-600">{{ formatCurrency(summary.income) }}</p>
                </div>
                <div class="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
                    <p class="text-xs font-bold text-slate-500 uppercase mb-1">Total Pengeluaran</p>
                    <p class="text-xl font-bold text-red-600">{{ formatCurrency(summary.expense) }}</p>
                </div>
                <div class="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
                    <p class="text-xs font-bold text-slate-500 uppercase mb-1">Saldo Bersih</p>
                    <p class="text-xl font-bold text-blue-600">{{ formatCurrency(summary.income - summary.expense) }}</p>
                </div>
            </div>

            <div class="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
                <table class="w-full text-sm text-left">
                    <thead class="bg-slate-50 text-slate-500 font-bold uppercase text-xs">
                        <tr>
                            <th class="px-6 py-3">Waktu</th>
                            <th class="px-6 py-3">No. Ref</th>
                            <th class="px-6 py-3">Deskripsi</th>
                            <th class="px-6 py-3">Tipe</th>
                            <th class="px-6 py-3 text-right">Jumlah</th>
                            <th class="px-6 py-3 text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100">
                        <tr v-for="t in transactions" :key="t.id" class="hover:bg-slate-50 transition-colors">
                            <td class="px-6 py-4 font-mono text-slate-600">{{ t.trans_date.substring(11, 16) }}</td>
                            <td class="px-6 py-4 font-mono text-slate-500 text-xs">{{ t.trans_number }}</td>
                            <td class="px-6 py-4 font-medium text-slate-800">{{ t.description }}</td>
                            <td class="px-6 py-4">
                                <span :class="t.type === 'INCOME' ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'" class="px-2 py-1 rounded text-xs font-bold uppercase">
                                    {{ t.type === 'INCOME' ? 'Masuk' : 'Keluar' }}
                                </span>
                            </td>
                            <td class="px-6 py-4 text-right font-bold" :class="t.type === 'INCOME' ? 'text-emerald-600' : 'text-red-600'">
                                {{ formatCurrency(t.amount) }}
                            </td>
                            <td class="px-6 py-4 text-center">
                                <div class="flex items-center justify-center gap-2">
                                    <button @click="openModal(t)" class="text-slate-400 hover:text-blue-600"><i class="fas fa-pencil-alt"></i></button>
                                    <button @click="deleteTransaction(t)" class="text-slate-400 hover:text-red-600"><i class="fas fa-trash"></i></button>
                                </div>
                            </td>
                        </tr>
                        <tr v-if="transactions.length === 0">
                            <td colspan="6" class="px-6 py-8 text-center text-slate-400 italic">
                                Belum ada transaksi hari ini.
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <div v-if="showModal" class="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
        <div class="bg-white rounded-xl shadow-xl w-full max-w-md p-6">
            <h3 class="text-lg font-bold text-slate-800 mb-4">{{ form.id ? 'Edit Transaksi' : 'Tambah Transaksi' }}</h3>
            <form @submit.prevent="saveTransaction">
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-bold text-slate-700 mb-1">Tipe Transaksi</label>
                        <select v-model="form.type" class="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-blue-500">
                            <option value="INCOME">Pemasukan (Penjualan)</option>
                            <option value="EXPENSE">Pengeluaran (Belanja)</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-bold text-slate-700 mb-1">Deskripsi</label>
                        <input type="text" v-model="form.description" class="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-blue-500" required placeholder="Contoh: Jual Nasi Goreng">
                    </div>
                    <div>
                        <label class="block text-sm font-bold text-slate-700 mb-1">Nominal (Rp)</label>
                        <input type="number" v-model="form.amount" class="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-blue-500" required min="0">
                    </div>
                    <div>
                        <label class="block text-sm font-bold text-slate-700 mb-1">Waktu</label>
                        <input type="datetime-local" v-model="form.date" class="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-blue-500">
                    </div>
                </div>
                <div class="flex justify-end gap-3 mt-6">
                    <button type="button" @click="showModal = false" class="px-4 py-2 text-slate-600 hover:text-slate-800 font-medium text-sm">Batal</button>
                    <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-lg font-bold text-sm hover:bg-blue-700">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
const { createApp } = Vue;
createApp({
    data() {
        return {
            baseUrl: window.BASE_URL || '/',
            filterDate: new Date().toISOString().split('T')[0],
            transactions: [],
            showModal: false,
            form: { id: null, type: 'INCOME', description: '', amount: '', date: '' }
        }
    },
    computed: {
        currentDateFormatted() {
            return new Date().toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
        },
        summary() {
            return this.transactions.reduce((acc, t) => {
                if (t.type === 'INCOME') acc.income += parseFloat(t.amount);
                else acc.expense += parseFloat(t.amount);
                return acc;
            }, { income: 0, expense: 0 });
        }
    },
    mounted() {
        this.fetchData();
    },
    methods: {
        normalizeBaseUrl() {
            if (this.baseUrl === '/' || !this.baseUrl) {
                const m = (window.location.pathname || '').match(/^\/(AIS|AIStest)\//i);
                this.baseUrl = m ? `/${m[1]}/` : '/';
            }
        },
        formatDate(dateStr) {
            return new Date(dateStr).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' });
        },
        formatCurrency(value) {
            return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(value);
        },
        async fetchData() {
            try {
                this.normalizeBaseUrl();
                const res = await fetch(this.baseUrl + 'api/pos.php?action=get_transactions&date=' + encodeURIComponent(this.filterDate));
                const json = await res.json();
                if (json.success) {
                    this.transactions = json.data;
                }
            } catch (e) {
                console.error(e);
            }
        },
        openModal(t = null) {
            if (t) {
                this.form = {
                    id: t.id,
                    type: t.type,
                    description: t.description,
                    amount: parseFloat(t.amount),
                    date: t.trans_date.replace(' ', 'T')
                };
            } else {
                const now = new Date();
                now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
                this.form = { id: null, type: 'INCOME', description: '', amount: '', date: now.toISOString().slice(0, 16) };
            }
            this.showModal = true;
        },
        async saveTransaction() {
            try {
                this.normalizeBaseUrl();
                const res = await fetch(this.baseUrl + 'api/pos.php?action=save_transaction', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(this.form)
                });
                const json = await res.json();
                if (json.success) {
                    this.showModal = false;
                    this.fetchData();
                } else {
                    alert(json.message);
                }
            } catch (e) {
                console.error(e);
                alert('Gagal menyimpan transaksi');
            }
        },
        async deleteTransaction(t) {
            if (!confirm('Hapus transaksi "' + t.description + '"?')) return;
            try {
                this.normalizeBaseUrl();
                const res = await fetch(this.baseUrl + 'api/pos.php?action=delete_transaction', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id: t.id })
                });
                const json = await res.json();
                if (json.success) {
                    this.fetchData();
                } else {
                    alert(json.message);
                }
            } catch (e) {
                console.error(e);
                alert('Gagal menghapus transaksi');
            }
        }
    }
}).mount('#app');
</script>
