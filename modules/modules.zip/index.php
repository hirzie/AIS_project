<?php
session_start();
header("Location: " . ((($_SERVER['SERVER_PORT'] ?? 80) == 8000) ? '/' : '/AIS/') . "index.php");
exit;
