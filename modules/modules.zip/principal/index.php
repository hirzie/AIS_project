<?php
require_once '../../includes/guard.php';
require_login_and_module('principal');
require_once '../../includes/header.php';
require_once '../../config/database.php';
$__displayName = $_SESSION['username'] ?? 'Pengguna';
if (!empty($_SESSION['person_id'])) {
    $st = $pdo->prepare("SELECT name FROM core_people WHERE id = ?");
    $st->execute([$_SESSION['person_id']]);
    $nm = $st->fetchColumn();
    if ($nm) { $__displayName = $nm; }
}
?>
<div id="app" v-cloak class="flex flex-col h-screen">
    <nav class="bg-white border-b border-slate-200 h-16 flex items-center justify-between px-6 z-20 shadow-sm">
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 bg-slate-800 rounded-lg flex items-center justify-center text-white shadow-lg">
                <i class="fas fa-user-tie text-xl"></i>
            </div>
            <div>
                <h1 class="text-xl font-bold text-slate-800 leading-none">Principal View</h1>
                <span class="text-xs text-slate-500 font-medium">Kepala Unit</span>
            </div>
        </div>
        <div class="flex items-center gap-4">
            <div class="flex items-center bg-slate-100 rounded-lg p-1 border border-slate-200">
                <button @click="currentUnit='tk'" :class="unitClass('tk')" class="px-3 py-1 rounded text-xs font-bold">TK</button>
                <button @click="currentUnit='sd'" :class="unitClass('sd')" class="px-3 py-1 rounded text-xs font-bold">SD</button>
                <button @click="currentUnit='smp'" :class="unitClass('smp')" class="px-3 py-1 rounded text-xs font-bold">SMP</button>
                <button @click="currentUnit='sma'" :class="unitClass('sma')" class="px-3 py-1 rounded text-xs font-bold">SMA</button>
                <button @click="currentUnit='asrama'" :class="unitClass('asrama')" class="px-3 py-1 rounded text-xs font-bold">Asrama</button>
            </div>
            <div class="flex items-center bg-slate-100 rounded-lg p-1 border border-slate-200">
                <button @click="currentPosition='kepala'" :class="positionClass('kepala')" class="px-3 py-1 rounded text-xs font-bold">Kepala Sekolah</button>
                <button @click="currentPosition='wakasek'" :class="positionClass('wakasek')" class="px-3 py-1 rounded text-xs font-bold">Wakasek</button>
                <button @click="currentPosition='wali'" :class="positionClass('wali')" class="px-3 py-1 rounded text-xs font-bold">Wali Kelas</button>
            </div>
            <div v-if="showWaliClassSelector" class="flex items-center bg-slate-100 rounded-lg p-1 border border-slate-200">
                <select v-model="selectedClassId" @change="applySelectedClass" class="px-3 py-1 rounded text-xs font-bold bg-white border border-slate-300">
                    <option value="">Pilih Kelas</option>
                    <option v-for="c in classesOptions" :value="c.id">{{ c.name }}</option>
                </select>
            </div>
            <span class="text-sm font-medium text-slate-500 bg-slate-100 px-3 py-1 rounded-full">{{ currentTime }}</span>
            <button onclick="window.location.href='<?php echo $baseUrl; ?>index.php'" class="text-slate-400 hover:text-red-500 transition-colors" title="Keluar ke Menu Utama">
                <i class="fas fa-power-off text-lg"></i>
            </button>
        </div>
    </nav>
    <main class="flex-1 overflow-y-auto p-6 bg-slate-50">
        <div class="max-w-7xl mx-auto space-y-6">
            <div class="bg-gradient-to-r from-indigo-600 via-blue-600 to-emerald-600 text-white rounded-2xl shadow-md px-6 py-5 flex items-center justify-between">
                <div>
                    <div class="text-sm opacity-90">Selamat Datang</div>
                    <div class="text-2xl font-bold leading-tight"><?php echo htmlspecialchars($__displayName); ?></div>
                </div>
                <span class="text-xs bg-white/20 px-3 py-1 rounded-full backdrop-blur-sm">{{ unitName }} · {{ positionName }}</span>
            </div>

            <!-- WALIKELAS LOCK OVERLAY -->
            <div v-if="currentPosition === 'wali' && lockStatus.is_locked" class="fixed inset-0 top-16 z-50 bg-slate-100 flex items-center justify-center backdrop-blur-sm bg-slate-100/95">
                <div class="max-w-3xl w-full mx-6 bg-white border-l-8 border-red-500 rounded-2xl shadow-2xl overflow-hidden relative">
                    <!-- Background Icon -->
                    <div class="absolute top-0 right-0 -mt-8 -mr-8 text-red-50 text-9xl opacity-50 transform rotate-12 pointer-events-none">
                        <i class="fas fa-lock"></i>
                    </div>
                    
                    <div class="p-10 relative z-10">
                        <div class="flex items-start gap-8">
                            <div class="flex-shrink-0">
                                <div class="w-24 h-24 bg-red-100 text-red-600 rounded-full flex items-center justify-center text-5xl shadow-inner animate-pulse">
                                    <i class="fas fa-lock"></i>
                                </div>
                            </div>
                            <div class="flex-1">
                                <h2 class="text-3xl font-bold text-slate-800 mb-2">Akses Terkunci</h2>
                                <p class="text-lg text-slate-600 mb-6 leading-relaxed">
                                    Mohon maaf, akses halaman Walikelas Anda dikunci sementara.<br>
                                    <span class="font-bold text-red-600">Harap menghadap Kepala Sekolah untuk membuka kunci.</span>
                                </p>
                                
                                <div class="bg-slate-50 rounded-xl p-6 border border-slate-200 mb-8">
                                    <h3 class="text-sm font-bold text-slate-400 uppercase tracking-wider mb-4 border-b border-slate-200 pb-2">Penyebab Kunci</h3>
                                    <ul class="space-y-4">
                                        <li v-for="lock in lockStatus.locks" :key="lock.type || lock" class="flex items-start gap-4">
                                            <i class="fas fa-times-circle text-red-500 text-xl mt-0.5"></i>
                                            <div>
                                                <div class="font-bold text-slate-800 text-lg">{{ lock.message || lock }}</div>
                                                <div v-if="lock.detail" class="text-slate-500 mt-1">{{ lock.detail }}</div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>

                                <div class="flex flex-wrap gap-4">
                                    <button @click="checkLockStatus" class="bg-white hover:bg-slate-50 text-slate-700 border-2 border-slate-200 px-8 py-4 rounded-xl font-bold text-lg transition-all flex items-center gap-3 hover:border-slate-300">
                                        <i class="fas fa-sync-alt"></i>
                                        Cek Status Lagi
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div v-if="currentPosition === 'wali' && currentUnit !== 'asrama' && !lockStatus.is_locked" class="mb-6 border-b border-slate-200">
            <div class="flex items-center gap-6">
                <button @click="homeroomTab='DASH'" :class="waliTabClass('DASH')" class="pb-3 text-sm font-bold border-b-2 transition-colors">Dashboard</button>
                <button @click="homeroomTab='SISWA'" :class="waliTabClass('SISWA')" class="pb-3 text-sm font-bold border-b-2 transition-colors">Data Siswa</button>
                <button @click="homeroomTab='JADWAL'" :class="waliTabClass('JADWAL')" class="pb-3 text-sm font-bold border-b-2 transition-colors">Pelajaran</button>
                <button @click="homeroomTab='ABSENSI'" :class="waliTabClass('ABSENSI')" class="pb-3 text-sm font-bold border-b-2 transition-colors">Absensi</button>
                <button @click="homeroomTab='BK'" :class="waliTabClass('BK')" class="pb-3 text-sm font-bold border-b-2 transition-colors">BK</button>
                <button @click="homeroomTab='INVENTARIS'" :class="waliTabClass('INVENTARIS')" class="pb-3 text-sm font-bold border-b-2 transition-colors">Inventaris</button>
                <button @click="homeroomTab='TUGAS'" :class="homeroomTab==='TUGAS' ? 'border-red-600 text-red-600' : 'border-transparent text-red-600 hover:text-red-800'" class="pb-3 text-sm font-bold border-b-2 transition-colors">Tugas Saya</button>
            </div>
        </div>
            <div v-if="currentPosition === 'wali' && currentUnit !== 'asrama' && !lockStatus.is_locked && homeroomTab==='DASH'" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div class="bg-white rounded-xl shadow-sm border border-slate-200 p-4">
                    <div class="text-sm text-slate-500 mb-1">Total Siswa</div>
                    <div class="text-2xl font-bold text-slate-800">{{ classStudents.length }}</div>
                </div>
                <div class="bg-white rounded-xl shadow-sm border border-slate-200 p-4">
                    <div class="text-sm text-slate-500 mb-1">Kehadiran Hari Ini</div>
                    <div class="flex items-end gap-2">
                        <div class="text-2xl font-bold text-emerald-600">{{ attendancePercent }}%</div>
                        <div class="text-xs text-slate-400 mb-1">Hadir</div>
                    </div>
                </div>
                <div class="bg-white rounded-xl shadow-sm border border-slate-200 p-4">
                    <div class="text-sm text-slate-500 mb-1">Tidak Hadir</div>
                    <div class="text-2xl font-bold text-red-600">{{ absentStudents.length }}</div>
                    <div class="text-xs text-slate-400">Sakit/Izin/Alfa</div>
                </div>
                <div class="bg-white rounded-xl shadow-sm border border-slate-200 p-4">
                    <div class="text-sm text-slate-500 mb-1">Kasus BK Aktif</div>
                    <div class="text-2xl font-bold text-amber-600">{{ pendingIssues.length }}</div>
                </div>
            </div>
            <div v-if="currentPosition === 'wali' && currentUnit !== 'asrama' && !lockStatus.is_locked && homeroomTab==='SISWA'" class="grid grid-cols-1 gap-6">
                <div class="flex items-center justify-between mb-4">
                     <div class="text-sm font-bold text-slate-800">Daftar Siswa {{ className || 'Kelas Wali' }}</div>
                     <input v-model="studentSearch" type="text" placeholder="Cari nama/NIS..." class="border border-slate-300 rounded px-3 py-1 text-sm w-64" />
                </div>
                <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                    <table class="w-full text-sm text-left">
                        <thead class="bg-slate-50 text-slate-500 font-bold uppercase text-xs">
                            <tr>
                                <th class="px-6 py-3 w-16 text-center">No</th>
                                <th class="px-6 py-3">NIS</th>
                                <th class="px-6 py-3">Nama Siswa</th>
                                <th class="px-6 py-3 text-center">L/P</th>
                                <th class="px-6 py-3">Tempat, Tgl Lahir</th>
                                <th class="px-6 py-3 text-right">Aksi</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100">
                            <tr v-for="(s, index) in filteredClassStudents" :key="s.id" class="hover:bg-slate-50">
                                <td class="px-6 py-4 text-center text-slate-500">{{ index + 1 }}</td>
                                <td class="px-6 py-4 font-mono text-slate-600">{{ s.nis || '-' }}</td>
                                <td class="px-6 py-4">
                                    <div class="font-bold text-slate-800">{{ s.name }}</div>
                                </td>
                                <td class="px-6 py-4 text-center font-bold" :class="s.gender==='L'?'text-blue-600':'text-pink-600'">{{ s.gender || '-' }}</td>
                                <td class="px-6 py-4 text-slate-600 text-xs">
                                    {{ s.birth_place || '-' }}, {{ s.birth_date ? new Date(s.birth_date).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' }) : '-' }}
                                </td>
                                <td class="px-6 py-4 text-right">
                                    <button @click="openStudentModal(s)" class="text-xs font-bold text-slate-600 hover:text-slate-800 bg-slate-100 px-3 py-1 rounded mr-2">Lihat Detail</button>
                                    <button @click="openPortfolio(s)" class="text-xs font-bold text-blue-600 hover:text-blue-800 bg-blue-50 px-3 py-1 rounded">Portfolio</button>
                                </td>
                            </tr>
                            <tr v-if="filteredClassStudents.length === 0">
                                <td colspan="6" class="px-6 py-12 text-center text-slate-400">Tidak ada data siswa.</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <div v-if="currentPosition === 'wali' && currentUnit !== 'asrama' && !lockStatus.is_locked && homeroomTab==='ABSENSI'" class="grid grid-cols-1 gap-6">
                <div class="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                    <div class="flex items-center justify-between mb-6">
                        <div>
                            <h3 class="text-lg font-bold text-slate-800 mb-1">Absensi Harian</h3>
                            <p class="text-xs text-slate-500">Kelola kehadiran siswa untuk tanggal terpilih.</p>
                        </div>
                        <div class="flex items-center gap-3">
                             <input type="date" v-model="dailyDate" class="border border-slate-300 rounded px-3 py-2 text-sm font-bold text-slate-700 focus:outline-none focus:border-blue-500">
                             <button @click="saveDailyBatch()" class="bg-blue-600 text-white px-4 py-2 rounded text-sm font-bold hover:bg-blue-700 transition-colors">Simpan Absensi</button>
                        </div>
                    </div>
                    
                    <div class="overflow-x-auto">
                        <table class="w-full text-sm text-left">
                            <thead class="bg-slate-50 text-slate-500 font-bold uppercase text-xs">
                                <tr>
                                    <th class="px-4 py-3 w-10 text-center">No</th>
                                    <th class="px-4 py-3">Nama Siswa</th>
                                    <th class="px-4 py-3 text-center w-24">Hadir</th>
                                    <th class="px-4 py-3 text-center w-24">Sakit</th>
                                    <th class="px-4 py-3 text-center w-24">Izin</th>
                                    <th class="px-4 py-3 text-center w-24">Alfa</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100">
                                <tr v-for="(s, idx) in classStudents" :key="s.id" class="hover:bg-slate-50">
                                    <td class="px-4 py-3 text-center text-slate-500">{{ idx + 1 }}</td>
                                    <td class="px-4 py-3 font-bold text-slate-700">{{ s.name }}</td>
                                    <td class="px-4 py-3 text-center">
                                        <label class="cursor-pointer block">
                                            <input type="radio" :name="'att-'+s.id" value="Hadir" v-model="s.status" class="accent-emerald-600 w-4 h-4">
                                        </label>
                                    </td>
                                    <td class="px-4 py-3 text-center">
                                        <label class="cursor-pointer block">
                                            <input type="radio" :name="'att-'+s.id" value="Sakit" v-model="s.status" class="accent-blue-600 w-4 h-4">
                                        </label>
                                    </td>
                                    <td class="px-4 py-3 text-center">
                                        <label class="cursor-pointer block">
                                            <input type="radio" :name="'att-'+s.id" value="Izin" v-model="s.status" class="accent-amber-500 w-4 h-4">
                                        </label>
                                    </td>
                                    <td class="px-4 py-3 text-center">
                                        <label class="cursor-pointer block">
                                            <input type="radio" :name="'att-'+s.id" value="Alfa" v-model="s.status" class="accent-red-600 w-4 h-4">
                                        </label>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div v-if="currentPosition === 'wali' && currentUnit !== 'asrama' && !lockStatus.is_locked && homeroomTab==='JADWAL'" class="grid grid-cols-1 gap-6">
                <div class="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
                    <div class="flex items-center gap-3 mb-4">
                        <div class="w-12 h-12 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center text-xl">
                            <i class="far fa-calendar-alt"></i>
                        </div>
                        <div>
                            <div class="text-sm text-slate-500">Jadwal Pelajaran</div>
                            <div class="text-2xl font-bold text-slate-800">{{ className || 'Kelas Wali' }}</div>
                        </div>
                    </div>
                    <div v-if="academicSlots && academicSlots.length > 0" class="overflow-x-auto">
                        <table class="w-full text-sm">
                            <thead class="bg-slate-50 text-slate-500 font-bold uppercase text-[10px]">
                                <tr>
                                    <th class="px-4 py-2 w-28 border-r border-slate-200">Waktu</th>
                                    <th v-for="d in ['Senin','Selasa','Rabu','Kamis','Jumat']" :key="d" class="px-4 py-2 text-center border-r border-slate-200 min-w-[120px]">{{ d }}</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100">
                                <tr v-for="slot in academicSlots" :key="(slot.id||slot.start)+'-'+(slot.end||'')" v-show="!slot.isBreak">
                                    <td class="px-4 py-2 font-mono text-xs text-slate-500 border-r border-slate-200 bg-slate-50/50">
                                        <div class="font-bold">{{ (slot.start||'').slice(0,5) }} - {{ (slot.end||'').slice(0,5) }}</div>
                                        <div class="text-[10px]">{{ slot.name || '' }}</div>
                                    </td>
                                    <td v-for="d in ['Senin','Selasa','Rabu','Kamis','Jumat']" :key="d + (slot.id||slot.start)" class="p-1 border-r border-slate-100 align-top h-16">
                                        <div v-if="getScheduleItem(d, (slot.start||'').slice(0,5))" class="bg-blue-50 border border-blue-100 p-2 rounded h-full">
                                            <div class="font-bold text-blue-800 text-xs mb-1 line-clamp-2">
                                                {{ getScheduleItem(d, (slot.start||'').slice(0,5)).subject_name }}
                                            </div>
                                            <div class="text-[10px] text-slate-500 flex items-center gap-1">
                                                <i class="fas fa-user-tie text-[9px]"></i>
                                                <span class="truncate">{{ getScheduleItem(d, (slot.start||'').slice(0,5)).teacher_name }}</span>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div v-else class="text-sm text-slate-500">Belum ada slot jadwal.</div>
                </div>
            </div>
            <div v-if="currentPosition === 'wali' && currentUnit !== 'asrama' && !lockStatus.is_locked && homeroomTab==='BK'" class="grid grid-cols-1 gap-6">
                <div class="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
                    <div class="flex items-center justify-between mb-4">
                        <div class="flex items-center gap-3">
                            <div class="w-12 h-12 rounded-xl bg-pink-100 text-pink-600 flex items-center justify-center text-xl">
                                <i class="fas fa-user-shield"></i>
                            </div>
                            <div>
                                <div class="text-sm text-slate-500">BK</div>
                                <div class="text-xs text-slate-400">Tim BK, Konseling, Psikoedukasi</div>
                            </div>
                        </div>
                        <div class="flex items-center gap-2">
                            <button @click="bkTab='KONSELING'" :class="bkTabClass('KONSELING')" class="px-3 py-1 rounded text-[11px] font-bold">Konseling</button>
                            <button @click="bkTab='TIMBK'" :class="bkTabClass('TIMBK')" class="px-3 py-1 rounded text-[11px] font-bold">Tim BK</button>
                            <button @click="bkTab='PSIKO'" :class="bkTabClass('PSIKO')" class="px-3 py-1 rounded text-[11px] font-bold">Psikoedukasi</button>
                        </div>
                    </div>
                    <div v-show="bkTab==='KONSELING'">
                        <div class="flex justify-between items-center mb-2">
                            <div class="text-[11px] text-slate-500">Daftar kejadian menunggu tindakan untuk kelas wali.</div>
                            <button @click="fetchPendingIssues" class="px-2.5 py-1 rounded bg-slate-100 text-slate-600 text-[11px] hover:bg-slate-200">Muat Ulang</button>
                        </div>
                        <div class="space-y-2">
                            <div v-for="i in pendingIssues" :key="i.id" class="p-3 border border-slate-200 rounded-xl">
                                <div class="flex items-center justify-between">
                                    <div class="text-sm font-bold text-slate-800 truncate">{{ i.title }}</div>
                                    <div class="text-[10px] text-slate-400">{{ formatDate(i.created_at) }}</div>
                                </div>
                                <div class="text-[11px] text-slate-500 mb-2">{{ i.student_name }} • {{ i.category }} • {{ i.severity }}</div>
                                <div class="flex items-center gap-2">
                                    <button @click="openResolveModal(i)" class="px-3 py-1 rounded bg-emerald-600 text-white text-[11px] font-bold">Selesaikan Internal</button>
                                    <button @click="openEscalateModal(i)" class="px-3 py-1 rounded bg-red-600 text-white text-[11px] font-bold">Eskalasi ke BK</button>
                                </div>
                            </div>
                            <div v-if="pendingIssues.length===0" class="text-xs text-slate-500">Tidak ada isu menunggu.</div>
                        </div>
                    </div>
                    <div v-show="bkTab==='TIMBK'">
                        <div class="flex items-center gap-3 mb-4">
                            <div class="w-12 h-12 rounded-xl bg-indigo-100 text-indigo-600 flex items-center justify-center text-xl">
                                <i class="fas fa-user-shield"></i>
                            </div>
                            <div>
                                <div class="text-sm text-slate-500">Tim BK Unit</div>
                                <div class="text-xs text-slate-400">Kontak & Peran</div>
                            </div>
                        </div>
                        <div v-if="bkProfile.team && bkProfile.team.length > 0" class="space-y-2">
                            <div v-for="m in bkProfile.team" :key="m.id || m.name" class="flex items-center justify-between p-3 border border-slate-200 rounded-xl">
                                <div>
                                    <div class="text-sm font-bold text-slate-800">{{ m.name }}</div>
                                    <div class="text-[10px] text-slate-500">{{ m.role || 'BK' }}</div>
                                </div>
                                <div class="text-[10px] text-slate-400">{{ m.phone || '-' }}</div>
                            </div>
                        </div>
                        <div v-else class="text-xs text-slate-500">Belum ada data tim BK.</div>
                    </div>
                    <div v-show="bkTab==='PSIKO'">
                        <div class="flex items-center gap-3 mb-4">
                            <div class="w-12 h-12 rounded-xl bg-indigo-100 text-indigo-600 flex items-center justify-center text-xl">
                                <i class="fas fa-book-open"></i>
                            </div>
                            <div>
                                <div class="text-sm text-slate-500">Psikoedukasi</div>
                                <div class="text-xs text-slate-400">Materi untuk siswa/ortu</div>
                            </div>
                        </div>
                        <div v-if="bkArticles.length > 0" class="rounded-xl border border-slate-200 overflow-hidden">
                            <div class="divide-y divide-slate-100">
                                <div v-for="a in bkArticles" :key="a.id || a.title" class="px-4 py-3 bg-white hover:bg-slate-50 transition-colors flex items-center justify-between">
                                    <div>
                                        <div class="font-bold text-slate-800 text-sm">{{ a.title }}</div>
                                        <div class="text-[10px] text-slate-500">{{ a.category || '' }}</div>
                                    </div>
                                    <a :href="a.url || (baseUrl + (a.file_name ? ('uploads/managerial/docs/' + a.file_name) : ''))" target="_blank" class="text-[11px] font-bold text-indigo-600 hover:underline">Buka</a>
                                </div>
                            </div>
                        </div>
                        <div v-else class="text-xs text-slate-500">Belum ada artikel.</div>
                    </div>
                </div>
            </div>
            <div v-if="currentPosition === 'wali' && currentUnit !== 'asrama' && !lockStatus.is_locked && homeroomTab==='INVENTARIS'" class="grid grid-cols-1 gap-6">
                <div class="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
                    <div class="flex items-center gap-3 mb-6">
                        <div class="w-12 h-12 rounded-xl bg-orange-100 text-orange-600 flex items-center justify-center text-xl">
                            <i class="fas fa-boxes"></i>
                        </div>
                        <div>
                            <h3 class="text-lg font-bold text-slate-800">Inventaris Kelas</h3>
                            <p class="text-xs text-slate-500">Daftar aset dan kondisi barang di kelas.</p>
                        </div>
                    </div>
                    <div class="overflow-x-auto">
                        <table class="w-full text-sm text-left">
                            <thead class="bg-slate-50 text-slate-500 font-bold uppercase text-xs">
                                <tr>
                                    <th class="px-6 py-3 w-16 text-center">No</th>
                                    <th class="px-6 py-3">Kode Barang</th>
                                    <th class="px-6 py-3">Nama Barang</th>
                                    <th class="px-6 py-3 text-center">Jumlah</th>
                                    <th class="px-6 py-3 text-center">Kondisi</th>
                                    <th class="px-6 py-3">Keterangan</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100">
                                <tr v-for="(item, index) in inventoryAssets" :key="item.id" class="hover:bg-slate-50">
                                    <td class="px-6 py-4 text-center text-slate-500">{{ index + 1 }}</td>
                                    <td class="px-6 py-4 font-mono text-slate-600 text-xs">{{ item.id }}</td>
                                    <td class="px-6 py-4 font-bold text-slate-800">{{ item.name }}</td>
                                    <td class="px-6 py-4 text-center font-bold">{{ item.count }}</td>
                                    <td class="px-6 py-4 text-center">
                                        <span class="px-2 py-1 rounded text-xs font-bold" :class="item.condition === 'Baik' ? 'bg-emerald-100 text-emerald-700' : (item.condition === 'Rusak Ringan' ? 'bg-amber-100 text-amber-700' : 'bg-red-100 text-red-700')">
                                            {{ item.condition || 'Baik' }}
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 text-slate-500 text-xs">{{ item.note || '-' }}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div v-if="currentPosition === 'wali' && currentUnit !== 'asrama' && !lockStatus.is_locked && homeroomTab==='TUGAS'" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <!-- Presensi Harian -->
                <div class="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 relative overflow-hidden group hover:shadow-md transition-shadow">
                    <div class="absolute top-0 right-0 p-4 opacity-10 pointer-events-none">
                        <i class="fas fa-calendar-check text-8xl text-emerald-600"></i>
                    </div>
                    <div class="relative z-10 flex flex-col h-full justify-between">
                        <div>
                            <div class="w-12 h-12 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center text-xl mb-4">
                                <i class="fas fa-calendar-day"></i>
                            </div>
                            <h3 class="text-lg font-bold text-slate-800 mb-1">Presensi Harian</h3>
                            <p class="text-sm text-slate-500 mb-6">Wajib diisi setiap hari sekolah sebelum jam 08:00.</p>
                            
                            <div v-if="attendanceSubmitted" class="bg-emerald-50 rounded-xl p-4 border border-emerald-100 mb-6">
                                <div class="flex items-center gap-3">
                                    <div class="w-8 h-8 rounded-full bg-emerald-200 text-emerald-700 flex items-center justify-center text-sm font-bold">
                                        <i class="fas fa-check"></i>
                                    </div>
                                    <div>
                                        <div class="text-sm font-bold text-emerald-800">Sudah Dilakukan</div>
                                        <div class="text-xs text-emerald-600">Terima kasih telah melakukan presensi.</div>
                                    </div>
                                </div>
                            </div>
                            <div v-else class="bg-red-50 rounded-xl p-4 border border-red-100 mb-6 animate-pulse">
                                <div class="flex items-center gap-3">
                                    <div class="w-8 h-8 rounded-full bg-red-200 text-red-700 flex items-center justify-center text-sm font-bold">
                                        <i class="fas fa-exclamation"></i>
                                    </div>
                                    <div>
                                        <div class="text-sm font-bold text-red-800">Belum Dilakukan</div>
                                        <div class="text-xs text-red-600">Mohon segera lakukan presensi siswa.</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <button @click="homeroomTab='ABSENSI'" class="w-full py-3 rounded-xl font-bold transition-colors" :class="attendanceSubmitted ? 'bg-slate-100 text-slate-600 hover:bg-slate-200' : 'bg-red-600 text-white hover:bg-red-700 shadow-lg shadow-red-200'">
                            {{ attendanceSubmitted ? 'Lihat Detail Absensi' : 'Isi Absensi Sekarang' }}
                        </button>
                    </div>
                </div>

                <!-- Inventaris Mingguan -->
                <div class="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 relative overflow-hidden group hover:shadow-md transition-shadow">
                    <div class="absolute top-0 right-0 p-4 opacity-10 pointer-events-none">
                        <i class="fas fa-boxes text-8xl text-orange-600"></i>
                    </div>
                    <div class="relative z-10 flex flex-col h-full justify-between">
                        <div>
                            <div class="w-12 h-12 rounded-xl bg-orange-100 text-orange-600 flex items-center justify-center text-xl mb-4">
                                <i class="fas fa-clipboard-list"></i>
                            </div>
                            <h3 class="text-lg font-bold text-slate-800 mb-1">Laporan Inventaris</h3>
                            <p class="text-sm text-slate-500 mb-6">Wajib dilaporkan setiap hari Sabtu (pekanan).</p>
                            
                            <div v-if="isSaturday" class="bg-orange-50 rounded-xl p-4 border border-orange-100 mb-6">
                                <div class="flex items-center gap-3">
                                    <div class="w-8 h-8 rounded-full bg-orange-200 text-orange-700 flex items-center justify-center text-sm font-bold animate-bounce">
                                        <i class="fas fa-bell"></i>
                                    </div>
                                    <div>
                                        <div class="text-sm font-bold text-orange-800">Jadwal Lapor Hari Ini!</div>
                                        <div class="text-xs text-orange-600">Mohon cek kondisi barang di kelas.</div>
                                    </div>
                                </div>
                            </div>
                            <div v-else class="bg-slate-50 rounded-xl p-4 border border-slate-100 mb-6">
                                <div class="flex items-center gap-3">
                                    <div class="w-8 h-8 rounded-full bg-slate-200 text-slate-500 flex items-center justify-center text-sm font-bold">
                                        <i class="fas fa-clock"></i>
                                    </div>
                                    <div>
                                        <div class="text-sm font-bold text-slate-600">Belum Jadwal Lapor</div>
                                        <div class="text-xs text-slate-500">Jadwal lapor berikutnya hari Sabtu.</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <button @click="homeroomTab='INVENTARIS'" class="w-full py-3 rounded-xl font-bold transition-colors" :class="isSaturday ? 'bg-orange-600 text-white hover:bg-orange-700 shadow-lg shadow-orange-200' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'">
                            {{ isSaturday ? 'Lapor Inventaris Sekarang' : 'Cek Data Inventaris' }}
                        </button>
                    </div>
                </div>

                <!-- Presensi Bulanan -->
                <div class="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 relative overflow-hidden group hover:shadow-md transition-shadow">
                    <div class="absolute top-0 right-0 p-4 opacity-10 pointer-events-none">
                        <i class="fas fa-file-invoice text-8xl text-indigo-600"></i>
                    </div>
                    <div class="relative z-10 flex flex-col h-full justify-between">
                        <div>
                            <div class="w-12 h-12 rounded-xl bg-indigo-100 text-indigo-600 flex items-center justify-center text-xl mb-4">
                                <i class="fas fa-calendar-alt"></i>
                            </div>
                            <h3 class="text-lg font-bold text-slate-800 mb-1">Rekap Bulanan</h3>
                            <p class="text-sm text-slate-500 mb-6">Validasi kehadiran siswa per bulan.</p>
                            
                            <div v-if="monthlyRecapSubmitted" class="bg-emerald-50 rounded-xl p-4 border border-emerald-100 mb-6">
                                <div class="flex items-center gap-3">
                                    <div class="w-8 h-8 rounded-full bg-emerald-200 text-emerald-700 flex items-center justify-center text-sm font-bold">
                                        <i class="fas fa-check"></i>
                                    </div>
                                    <div>
                                        <div class="text-sm font-bold text-emerald-800">Sudah Validasi</div>
                                        <div class="text-xs text-emerald-600">Data bulan ini aman.</div>
                                    </div>
                                </div>
                            </div>
                            <div v-else class="bg-red-50 rounded-xl p-4 border border-red-100 mb-6" :class="{'animate-pulse': monthlyMonth === 1}">
                                <div class="flex items-center gap-3">
                                    <div class="w-8 h-8 rounded-full bg-red-200 text-red-700 flex items-center justify-center text-sm font-bold">
                                        <i class="fas fa-exclamation-circle"></i>
                                    </div>
                                    <div>
                                        <div class="text-sm font-bold text-red-800">{{ monthlyMonth === 1 ? 'Peringatan Januari!' : 'Belum Divalidasi' }}</div>
                                        <div class="text-xs text-red-600">Wajib rekap akhir bulan.</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <button @click="monthlyRecapModal=true" class="w-full py-3 rounded-xl font-bold transition-colors" :class="monthlyRecapSubmitted ? 'bg-slate-100 text-slate-600 hover:bg-slate-200' : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-lg shadow-indigo-200'">
                            {{ monthlyRecapSubmitted ? 'Lihat Rekap' : 'Validasi Sekarang' }}
                        </button>
                    </div>
                </div>
            </div>
            <div v-if="currentPosition === 'kepala'">
                <div class="mb-6 border-b border-slate-200">
                    <div class="flex items-center gap-6 overflow-x-auto">
                        <button @click="principalTab='DASHBOARD'" :class="principalTab==='DASHBOARD' ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-500 hover:text-slate-700'" class="pb-3 text-sm font-bold border-b-2 transition-colors whitespace-nowrap">Dashboard</button>
                        <button @click="principalTab='SISWA'" :class="principalTab==='SISWA' ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-500 hover:text-slate-700'" class="pb-3 text-sm font-bold border-b-2 transition-colors whitespace-nowrap">Data Siswa</button>
                        <button @click="principalTab='PELAJARAN'" :class="principalTab==='PELAJARAN' ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-500 hover:text-slate-700'" class="pb-3 text-sm font-bold border-b-2 transition-colors whitespace-nowrap">Pelajaran</button>
                        <button @click="principalTab='ABSENSI'" :class="principalTab==='ABSENSI' ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-500 hover:text-slate-700'" class="pb-3 text-sm font-bold border-b-2 transition-colors whitespace-nowrap">Absensi</button>
                        <button @click="principalTab='BK'" :class="principalTab==='BK' ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-500 hover:text-slate-700'" class="pb-3 text-sm font-bold border-b-2 transition-colors whitespace-nowrap">BK</button>
                        <button @click="principalTab='INVENTARIS'" :class="principalTab==='INVENTARIS' ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-500 hover:text-slate-700'" class="pb-3 text-sm font-bold border-b-2 transition-colors whitespace-nowrap">Inventaris</button>
                        <button @click="principalTab='TUGAS'" :class="principalTab==='TUGAS' ? 'border-red-600 text-red-600' : 'border-transparent text-red-600 hover:text-red-800'" class="pb-3 text-sm font-bold border-b-2 transition-colors whitespace-nowrap">Tugas Saya</button>
                    </div>
                </div>

                <div v-if="principalTab==='DASHBOARD'" class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <!-- Locked Classes Warning -->
                    <div v-if="unitLocks.length > 0" class="md:col-span-3 bg-red-50 border border-red-200 rounded-xl p-4 mb-2">
                        <div class="flex items-center gap-3 mb-3">
                            <div class="w-10 h-10 rounded-full bg-red-100 text-red-600 flex items-center justify-center text-xl">
                                <i class="fas fa-lock"></i>
                            </div>
                            <div>
                                <h3 class="text-lg font-bold text-red-800">Status Lock Walikelas</h3>
                                <p class="text-xs text-red-600">Ada {{ unitLocks.length }} kelas terkunci yang membutuhkan perhatian.</p>
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            <div v-for="l in unitLocks" :key="l.id" class="bg-white p-3 rounded-lg border border-red-100 shadow-sm flex items-center justify-between">
                                <div>
                                    <div class="font-bold text-slate-800">{{ l.name }}</div>
                                    <div class="text-xs text-red-500 font-medium mt-1">
                                        <span v-for="(lock, idx) in l.locks" :key="idx" class="inline-block bg-red-100 px-1.5 py-0.5 rounded mr-1 mb-1">{{ lock }}</span>
                                    </div>
                                </div>
                                <button @click="openUnlockModal(l)" class="bg-red-600 hover:bg-red-700 text-white px-3 py-1.5 rounded text-xs font-bold transition-colors">
                                    <i class="fas fa-key mr-1"></i> Buka
                                </button>
                            </div>
                        </div>
                    </div>

                    <div class="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
                        <div class="flex items-center gap-3 mb-4">
                            <div class="w-12 h-12 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center text-xl">
                                <i class="fas fa-user-graduate"></i>
                            </div>
                            <div>
                                <div class="text-sm text-slate-500">Jumlah Siswa</div>
                                <div class="text-2xl font-bold text-slate-800">{{ unitStats.studentCount || 0 }}</div>
                            </div>
                        </div>
                        <div class="text-xs text-slate-500">Total siswa aktif pada unit ini.</div>
                    </div>
                    <div class="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
                        <div class="flex items-center gap-3 mb-4">
                            <div class="w-12 h-12 rounded-xl bg-indigo-100 text-indigo-600 flex items-center justify-center text-xl">
                                <i class="fas fa-chalkboard"></i>
                            </div>
                            <div>
                                <div class="text-sm text-slate-500">Jumlah Kelas</div>
                                <div class="text-2xl font-bold text-slate-800">{{ unitStats.classCount || 0 }}</div>
                            </div>
                        </div>
                        <div class="text-xs text-slate-500">Kelas aktif dalam tahun ajaran berjalan.</div>
                    </div>
                    <div class="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
                        <div class="flex items-center gap-3 mb-4">
                            <div class="w-12 h-12 rounded-xl bg-purple-100 text-purple-600 flex items-center justify-center text-xl">
                                <i class="fas fa-user-tie"></i>
                            </div>
                            <div>
                                <div class="text-sm text-slate-500">Jumlah Guru</div>
                                <div class="text-2xl font-bold text-slate-800">{{ unitStats.teacherCount || 0 }}</div>
                            </div>
                        </div>
                        <div class="text-xs text-slate-500">Guru akademik terkait unit ini.</div>
                    </div>
                </div>

                <div v-if="principalTab==='SISWA'" class="bg-white rounded-2xl shadow-sm border border-slate-100 p-6">
                    <h3 class="font-bold text-slate-800 mb-4">Statistik Siswa Per Kelas</h3>
                    <div class="overflow-x-auto">
                        <table class="w-full text-sm text-left">
                            <thead class="bg-slate-50 text-slate-500 font-bold uppercase text-xs">
                                <tr>
                                    <th class="px-4 py-3">Kelas</th>
                                    <th class="px-4 py-3 text-center">Laki-laki</th>
                                    <th class="px-4 py-3 text-center">Perempuan</th>
                                    <th class="px-4 py-3 text-center">Total</th>
                                    <th class="px-4 py-3 text-center">Status Lock</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100">
                                <tr v-for="c in unitStats.classes" :key="c.name" class="hover:bg-slate-50">
                                    <td class="px-4 py-3 font-bold">{{ c.name }}</td>
                                    <td class="px-4 py-3 text-center">{{ c.male || 0 }}</td>
                                    <td class="px-4 py-3 text-center">{{ c.female || 0 }}</td>
                                    <td class="px-4 py-3 text-center font-bold">{{ (c.male||0) + (c.female||0) }}</td>
                                    <td class="px-4 py-3 text-center">
                                        <div v-if="c.isLocked" class="flex flex-col items-center gap-1">
                                            <span class="inline-flex items-center gap-1 bg-red-100 text-red-600 px-2 py-1 rounded-full text-xs font-bold">
                                                <i class="fas fa-lock"></i> Locked
                                            </span>
                                            <button @click="openUnlockModal(c)" class="text-xs text-blue-600 underline hover:text-blue-800 font-bold">Buka Kunci</button>
                                        </div>
                                        <span v-else class="inline-flex items-center gap-1 bg-emerald-100 text-emerald-600 px-2 py-1 rounded-full text-xs font-bold">
                                            <i class="fas fa-check-circle"></i> Aman
                                        </span>
                                    </td>
                                </tr>
                                <tr v-if="!unitStats.classes || unitStats.classes.length===0">
                                    <td colspan="5" class="px-4 py-8 text-center text-slate-400">Belum ada data kelas.</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div v-if="principalTab==='PELAJARAN'" class="bg-white rounded-2xl shadow-sm border border-slate-100 p-6">
                    <div class="text-center py-12">
                        <div class="text-6xl text-slate-200 mb-4"><i class="fas fa-chart-pie"></i></div>
                        <h3 class="text-lg font-bold text-slate-800">Statistik Pelajaran</h3>
                        <p class="text-slate-500 text-sm">Grafik sebaran nilai dan capaian kurikulum akan tampil di sini.</p>
                        <div class="mt-4 inline-block bg-slate-100 text-slate-600 px-3 py-1 rounded text-xs font-bold">Coming Soon</div>
                    </div>
                </div>

                <div v-if="principalTab==='ABSENSI'" class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <div class="bg-white rounded-2xl shadow-sm border border-slate-100 p-6">
                        <div class="flex items-center justify-between mb-4">
                            <h3 class="font-bold text-slate-800">Laporan Harian ({{ new Date(principalDailyDate).toLocaleDateString('id-ID') }})</h3>
                            <input type="date" v-model="principalDailyDate" @change="fetchUnitStats" class="text-xs border border-slate-200 rounded px-2 py-1 outline-none focus:ring-1 focus:ring-blue-500">
                        </div>
                        <div class="space-y-3">
                            <div v-for="c in unitStats.classes" :key="'daily-'+c.name" class="flex items-center justify-between p-3 border border-slate-100 rounded-xl">
                                <div class="font-bold text-slate-700">{{ c.name }}</div>
                                <span :class="c.dailyStatus==='Submitted' ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'" class="px-2 py-1 rounded text-xs font-bold">
                                    {{ c.dailyStatus==='Submitted' ? 'Sudah Rekap' : 'Belum Rekap' }}
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="bg-white rounded-2xl shadow-sm border border-slate-100 p-6">
                        <div class="flex items-center justify-between mb-4">
                            <h3 class="font-bold text-slate-800">Rekap Bulanan ({{ getMonthName(principalMonth) }} {{ principalYear }})</h3>
                            <div class="flex gap-1">
                                <select v-model="principalMonth" @change="fetchUnitStats" class="text-xs border border-slate-200 rounded px-2 py-1 outline-none focus:ring-1 focus:ring-blue-500">
                                    <option v-for="m in 12" :key="m" :value="m">{{ getMonthName(m) }}</option>
                                </select>
                                <input type="number" v-model="principalYear" @change="fetchUnitStats" class="text-xs border border-slate-200 rounded px-2 py-1 w-16 outline-none focus:ring-1 focus:ring-blue-500">
                            </div>
                        </div>
                        <div class="space-y-3">
                            <div v-for="c in unitStats.classes" :key="'monthly-'+c.name" class="flex items-center justify-between p-3 border border-slate-100 rounded-xl">
                                <div class="font-bold text-slate-700">{{ c.name }}</div>
                                <span :class="c.monthlyStatus==='Validated' ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'" class="px-2 py-1 rounded text-xs font-bold">
                                    {{ c.monthlyStatus==='Validated' ? 'Sudah Validasi' : 'Belum Validasi' }}
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                <div v-if="principalTab==='BK'" class="bg-white rounded-2xl shadow-sm border border-slate-100 p-6">
                    <div class="flex items-center justify-between mb-6">
                        <h3 class="font-bold text-slate-800">Aduan & Eskalasi BK</h3>
                        <div class="flex gap-2">
                            <div class="bg-red-50 text-red-700 px-3 py-1 rounded text-xs font-bold">High: {{ unitStats.bkHigh || 0 }}</div>
                            <div class="bg-amber-50 text-amber-700 px-3 py-1 rounded text-xs font-bold">Medium: {{ unitStats.bkMedium || 0 }}</div>
                        </div>
                    </div>
                    <div class="text-center py-8 text-slate-500 text-sm">
                        Belum ada data kasus aktif untuk hari ini.
                    </div>
                </div>

                <div v-if="principalTab==='INVENTARIS'" class="bg-white rounded-2xl shadow-sm border border-slate-100 p-6">
                    <h3 class="font-bold text-slate-800 mb-4">Laporan Inventaris Kelas (Sabtu Pekanan)</h3>
                    <div class="space-y-3">
                        <div v-for="c in unitStats.classes" :key="'inv-'+c.name" class="flex items-center justify-between p-3 border border-slate-100 rounded-xl">
                            <div class="font-bold text-slate-700">{{ c.name }}</div>
                            <span :class="c.inventoryStatus==='Reported' ? 'bg-emerald-100 text-emerald-700' : 'bg-orange-100 text-orange-700'" class="px-2 py-1 rounded text-xs font-bold">
                                {{ c.inventoryStatus==='Reported' ? 'Sudah Lapor' : 'Belum Lapor' }}
                            </span>
                        </div>
                    </div>
                </div>

                <div v-if="principalTab==='TUGAS'" class="bg-white rounded-2xl shadow-sm border border-slate-100 p-6">
                     <div class="flex items-center justify-between mb-6">
                        <h3 class="font-bold text-slate-800">Manajemen Kunci Kelas (Lock Override)</h3>
                        <button @click="fetchUnitLocks" class="text-xs bg-slate-100 hover:bg-slate-200 text-slate-600 px-3 py-1 rounded font-bold"><i class="fas fa-sync-alt mr-1"></i> Refresh</button>
                     </div>
                     
                     <div v-if="unitLocks.length > 0" class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div v-for="l in unitLocks" :key="l.id" class="bg-red-50 border border-red-200 rounded-xl p-4 flex flex-col justify-between">
                            <div>
                                <div class="flex justify-between items-start mb-2">
                                    <div class="font-bold text-lg text-slate-800">{{ l.name }}</div>
                                    <div class="bg-red-200 text-red-800 text-[10px] px-2 py-0.5 rounded-full font-bold uppercase">Locked</div>
                                </div>
                                <div class="space-y-2 mb-4">
                                    <div v-for="(lock, idx) in l.lock_details" :key="idx" class="text-sm bg-white p-2 rounded border border-red-100">
                                        <div class="font-bold text-red-700 flex items-center gap-2">
                                            <i class="fas fa-lock text-xs"></i> {{ lock.message }}
                                        </div>
                                        <div class="text-xs text-slate-500 mt-1 pl-5">{{ lock.detail }}</div>
                                    </div>
                                </div>
                            </div>
                            <div class="pt-3 border-t border-red-200">
                                <button @click="openUnlockModal(l)" class="w-full bg-red-600 hover:bg-red-700 text-white py-2 rounded-lg font-bold text-sm shadow-sm transition-colors flex items-center justify-center gap-2">
                                    <i class="fas fa-key"></i> Buka Kunci Kelas Ini
                                </button>
                            </div>
                        </div>
                     </div>
                     
                     <div v-else class="text-center py-12 bg-slate-50 rounded-xl border border-slate-200 border-dashed">
                        <div class="text-4xl text-slate-300 mb-3"><i class="fas fa-check-circle"></i></div>
                        <h3 class="text-lg font-bold text-slate-700">Semua Kelas Aman</h3>
                        <p class="text-slate-500 text-sm">Tidak ada kelas yang terkunci saat ini.</p>
                    </div>
                </div>
            </div>
            <div v-if="currentPosition === 'wali' && currentUnit !== 'asrama' && homeroomTab==='DASH'" class="space-y-6">
                <!-- Row 1: Key Metrics -->
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <!-- Card 1: Attendance Visual -->
                    <div class="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 flex items-center gap-4">
                        <div class="relative w-20 h-20 flex-shrink-0">
                            <svg width="80" height="80" viewBox="0 0 120 120">
                                <circle cx="60" cy="60" r="54" stroke="#e5e7eb" stroke-width="10" fill="none"></circle>
                                <circle cx="60" cy="60" r="54" :stroke="attendanceRingColor" stroke-width="10" fill="none" stroke-linecap="round" transform="rotate(-90 60 60)" :style="{ strokeDasharray: attendanceRingDasharray, strokeDashoffset: attendanceRingDashoffset }"></circle>
                            </svg>
                            <div class="absolute inset-0 flex items-center justify-center">
                                <div class="text-base font-bold" :class="attendancePercent>=90 ? 'text-emerald-600' : (attendancePercent>=75 ? 'text-amber-600' : 'text-red-600')">{{ attendancePercent }}%</div>
                            </div>
                        </div>
                        <div>
                            <div class="text-sm text-slate-500">Kehadiran Hari Ini</div>
                            <div class="text-xl font-bold text-slate-800 line-clamp-1">{{ className }}</div>
                            <div class="text-xs text-slate-400">{{ dailyDate }}</div>
                        </div>
                    </div>

                    <!-- Card 2: Class Health -->
                    <div class="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 flex flex-col justify-between">
                        <div class="flex items-center justify-between mb-2">
                            <div class="text-sm text-slate-500">Kondisi Kelas</div>
                            <span :class="classCondition==='Hijau' ? 'bg-emerald-100 text-emerald-700' : (classCondition==='Kuning' ? 'bg-amber-100 text-amber-700' : 'bg-red-100 text-red-700')" class="px-2 py-1 rounded text-xs font-bold">{{ classCondition }}</span>
                        </div>
                        <div class="flex justify-between items-end">
                            <div>
                                <div class="text-2xl font-bold text-slate-800">{{ behaviorPointsAvg }}</div>
                                <div class="text-xs text-slate-500">Poin Perilaku Avg</div>
                            </div>
                            <div class="text-right cursor-pointer hover:opacity-75" @click="showAbsentModal=true">
                                <div class="text-2xl font-bold text-red-600">{{ absentStudents.length }}</div>
                                <div class="text-xs text-slate-500">Siswa Absen</div>
                            </div>
                        </div>
                    </div>

                    <!-- Card 3: Issues & Actions -->
                    <div class="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 flex flex-col justify-between">
                        <div class="flex items-center gap-3 mb-2">
                            <div class="w-10 h-10 rounded-lg bg-amber-100 text-amber-600 flex items-center justify-center flex-shrink-0">
                                <i class="fas fa-exclamation-circle"></i>
                            </div>
                            <div>
                                <div class="text-sm text-slate-500">Pending Issues</div>
                                <div class="text-xl font-bold text-slate-800">{{ pendingIssues.length }}</div>
                            </div>
                        </div>
                        <div class="grid grid-cols-2 gap-2 mt-2">
                            <button @click="openDailyVerify()" class="px-3 py-2 rounded bg-slate-800 text-white text-xs font-bold hover:bg-slate-700 transition-colors">Verifikasi Absen</button>
                            <button @click="rollupMonthlyFromDaily()" class="px-3 py-2 rounded bg-blue-600 text-white text-xs font-bold hover:bg-blue-700 transition-colors">Rekap Bulanan</button>
                        </div>
                    </div>
                </div>

                <!-- Row 2: Attendance Calendar & Top Absentees -->
                <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <!-- Calendar (Takes 2 columns) -->
                    <div class="lg:col-span-2 bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
                        <div class="flex items-center justify-between mb-4">
                            <div>
                                <h3 class="font-bold text-slate-800">Kalender Presensi</h3>
                                <div class="text-xs text-slate-500">Overview kehadiran bulanan</div>
                            </div>
                            <div class="flex items-center gap-2">
                                <select v-model="monthlyMonth" class="border border-slate-200 rounded px-2 py-1 text-xs outline-none focus:border-indigo-500">
                                    <option v-for="m in 12" :value="m">{{ m }}</option>
                                </select>
                                <input type="number" v-model.number="monthlyYear" class="border border-slate-200 rounded px-2 py-1 text-xs w-16 outline-none focus:border-indigo-500" />
                            </div>
                        </div>
                        <div class="grid grid-cols-7 gap-2 mb-2 text-center">
                            <div class="text-[10px] font-bold text-slate-400 uppercase">Sen</div>
                            <div class="text-[10px] font-bold text-slate-400 uppercase">Sel</div>
                            <div class="text-[10px] font-bold text-slate-400 uppercase">Rab</div>
                            <div class="text-[10px] font-bold text-slate-400 uppercase">Kam</div>
                            <div class="text-[10px] font-bold text-slate-400 uppercase">Jum</div>
                            <div class="text-[10px] font-bold text-slate-400 uppercase">Sab</div>
                            <div class="text-[10px] font-bold text-slate-400 uppercase">Min</div>
                        </div>
                        <div class="grid grid-cols-7 gap-2">
                            <div v-for="(d, idx) in monthlyCalendar" :key="idx" class="p-2 rounded-lg border border-slate-100 text-center hover:bg-slate-50 transition-colors" :class="{'opacity-0 pointer-events-none border-transparent': !d.date}">
                                <div class="text-[10px] text-slate-400 mb-1">{{ d.date ? d.date.substring(8,10) : '' }}</div>
                                <div v-if="d.date" class="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                                    <div class="h-full" :class="calendarBarClass(d.present_pct)" :style="{ width: (d.present_pct === -1 ? 100 : d.present_pct) + '%' }"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Top Absentees (Takes 1 column) -->
                    <div class="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
                        <h3 class="font-bold text-slate-800 mb-4">Perlu Perhatian</h3>
                        <div class="space-y-3">
                            <div v-for="(s, idx) in topAbsentees.slice(0,5)" :key="s.id" class="flex items-center justify-between text-sm group cursor-default">
                                <div class="flex items-center gap-2 overflow-hidden">
                                    <div class="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center text-[10px] font-bold text-slate-600 group-hover:bg-slate-200 transition-colors">{{ idx+1 }}</div>
                                    <span class="truncate text-slate-700 group-hover:text-slate-900 transition-colors">{{ truncateName(s.name) }}</span>
                                </div>
                                <div class="font-bold text-red-600 text-xs bg-red-50 px-2 py-0.5 rounded-full">{{ s.alfa + s.izin + s.sakit }}x</div>
                            </div>
                            <div v-if="topAbsentees.length===0" class="text-xs text-slate-500 text-center py-8 bg-slate-50 rounded-xl border border-slate-100 border-dashed">
                                Data absensi aman.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div v-if="dailyVerifyModal" class="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
                <div class="bg-white rounded-2xl p-6 w-full max-w-lg">
                    <div class="text-lg font-bold mb-3">Verifikasi Absensi Hari Ini</div>
                    <div v-if="!attendanceSubmitted" class="mb-3 bg-red-50 text-red-700 p-3 rounded-xl border border-red-100 text-sm flex items-center gap-2">
                        <i class="fas fa-exclamation-circle animate-pulse"></i>
                        <span>Belum divalidasi. Default: Semua Hadir.</span>
                    </div>
                    <div v-else class="mb-3 bg-emerald-50 text-emerald-700 p-3 rounded-xl border border-emerald-100 text-sm flex items-center gap-2">
                        <i class="fas fa-check-circle"></i>
                        <span>Sudah divalidasi.</span>
                    </div>
                    <div class="space-y-2 max-h-80 overflow-y-auto">
                        <div v-for="s in classStudents" :key="s.id" class="flex items-center justify-between p-3 border border-slate-200 rounded-xl">
                            <div class="min-w-0 flex-1">
                                <div class="text-sm font-bold text-slate-800 truncate">{{ truncateName(s.name) }}</div>
                                <div class="text-[10px] text-slate-500 truncate">{{ s.nis || 'NIS' }}</div>
                            </div>
                            <select v-model="s.status" class="border border-slate-300 rounded px-2 py-1 text-sm">
                                <option>Hadir</option>
                                <option>Izin</option>
                                <option>Sakit</option>
                                <option>Alfa</option>
                                <option>Cuti</option>
                            </select>
                        </div>
                    </div>
                    <div class="mt-4 flex items-center justify-end gap-2">
                        <button @click="dailyVerifyModal=false" class="px-3 py-2 rounded bg-slate-100 text-slate-700 text-sm">Batal</button>
                        <button @click="saveDailyBatch()" class="px-3 py-2 rounded bg-slate-800 text-white text-sm">{{ attendanceSubmitted ? 'Update' : 'Validasi & Simpan' }}</button>
                    </div>
                </div>
            </div>
            <div v-if="showAbsentModal" class="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
                <div class="bg-white rounded-2xl p-6 w-full max-w-md">
                    <div class="text-lg font-bold mb-3">Daftar Absen Hari Ini</div>
                    <div class="space-y-2 max-h-64 overflow-y-auto">
                        <div v-for="s in absentStudents" :key="s.id" class="flex items-center justify-between p-3 border border-slate-200 rounded-xl">
                            <div class="text-sm font-bold text-slate-800">{{ s.name }}</div>
                            <div class="text-[11px] text-slate-500">{{ s.status }}</div>
                        </div>
                        <div v-if="absentStudents.length===0" class="text-xs text-slate-500">Tidak ada siswa absen.</div>
                    </div>
                    <div class="mt-4 text-right">
                        <button @click="showAbsentModal=false" class="px-3 py-2 rounded bg-slate-800 text-white text-sm">Tutup</button>
                    </div>
                </div>
            </div>
            <div v-if="inventoryModal" class="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
                <div class="bg-white rounded-2xl p-6 w-full max-w-md">
                    <div class="text-lg font-bold mb-3">Lapor Kerusakan</div>
                    <div class="space-y-3">
                        <div class="text-sm text-slate-700">{{ inventorySelected ? inventorySelected.name : '' }}</div>
                        <div class="flex items-center gap-2">
                            <input type="number" min="1" v-model.number="inventoryReportCount" class="w-24 border border-slate-300 rounded px-2 py-1 text-sm" />
                            <input type="text" v-model="inventoryReportDesc" placeholder="Deskripsi singkat" class="flex-1 border border-slate-300 rounded px-3 py-1 text-sm" />
                        </div>
                        <input type="text" v-model="inventoryReportPhotoName" placeholder="Nama file foto (dummy)" class="w-full border border-slate-300 rounded px-3 py-1 text-sm" />
                    </div>
                    <div class="mt-4 flex items-center justify-end gap-2">
                        <button @click="inventoryModal=false" class="px-3 py-2 rounded bg-slate-100 text-slate-700 text-sm">Batal</button>
                        <button @click="submitInventoryReport()" class="px-3 py-2 rounded bg-slate-800 text-white text-sm">Kirim</button>
                    </div>
                </div>
            </div>
            <div v-if="studentPortfolioModal" class="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
                <div class="bg-white rounded-2xl p-6 w-full max-w-lg">
                    <div class="text-lg font-bold mb-3">Student Portfolio</div>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <div class="rounded-xl p-3 border border-slate-200">
                            <div class="text-[11px] text-slate-500">Akademik</div>
                            <div class="text-sm font-bold text-slate-800">Rata-rata: {{ portfolioStudent.academic_avg }}</div>
                            <div class="text-[10px] text-slate-500">Top: {{ portfolioStudent.academic_top_subject }}</div>
                        </div>
                        <div class="rounded-xl p-3 border border-slate-200">
                            <div class="text-[11px] text-slate-500">Perpus</div>
                            <div class="text-sm font-bold text-slate-800">Pinjaman Aktif: {{ portfolioStudent.library_loans }}</div>
                            <div class="text-[10px] text-slate-500">Telat: {{ portfolioStudent.library_late }}</div>
                        </div>
                        <div class="rounded-xl p-3 border border-slate-200">
                            <div class="text-[11px] text-slate-500">BK</div>
                            <div class="text-sm font-bold text-slate-800">Poin Pelanggaran: {{ portfolioStudent.bk_points }}</div>
                            <div class="text-[10px] text-slate-500">Kasus Aktif: {{ portfolioStudent.bk_active_cases }}</div>
                        </div>
                    </div>
                    <div class="mt-4 text-right">
                        <button @click="studentPortfolioModal=false" class="px-3 py-2 rounded bg-slate-800 text-white text-sm">Tutup</button>
                    </div>
                </div>
            </div>
            <div v-if="monthlyRecapModal" class="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
                <div class="bg-white rounded-2xl p-6 w-full max-w-2xl">
                    <div class="flex items-center justify-between mb-4">
                        <div class="text-lg font-bold text-slate-800">Validasi Presensi Bulanan</div>
                        <button @click="monthlyRecapModal=false" class="text-slate-400 hover:text-slate-600"><i class="fas fa-times"></i></button>
                    </div>
                    
                    <div class="mb-4">
                        <div class="bg-blue-50 border border-blue-100 rounded-xl p-4 flex items-start gap-3">
                            <i class="fas fa-info-circle text-blue-600 mt-1"></i>
                            <div>
                                <div class="text-sm font-bold text-blue-800">Tahun Ajaran Aktif</div>
                                <div class="text-xs text-blue-600 leading-relaxed">
                                    Silakan validasi rekap kehadiran siswa setiap akhir bulan. Bulan yang belum divalidasi akan berwarna merah.
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 mb-6">
                        <div v-for="m in monthlyRecaps" :key="m.id" 
                             class="relative p-3 rounded-xl border transition-all"
                             :class="m.status === 'validated' ? 'bg-emerald-50 border-emerald-200' : (m.status === 'pending' ? 'bg-white border-red-300 shadow-sm hover:shadow-md cursor-pointer group' : 'bg-slate-50 border-slate-100 opacity-60')"
                             @click="confirmValidateMonth(m)">
                            
                            <div class="flex justify-between items-start mb-2">
                                <span class="text-xs font-bold uppercase tracking-wider" :class="m.status==='validated'?'text-emerald-700':(m.status==='pending'?'text-red-700':'text-slate-500')">{{ m.name }}</span>
                                <i v-if="m.status === 'validated'" class="fas fa-check-circle text-emerald-500"></i>
                                <i v-else-if="m.status === 'pending'" class="fas fa-exclamation-circle text-red-500 animate-pulse"></i>
                            </div>
                            
                            <div class="text-[10px]" :class="m.status==='validated'?'text-emerald-600':(m.status==='pending'?'text-red-600':'text-slate-400')">
                                {{ m.status === 'validated' ? 'Sudah Validasi' : (m.status === 'pending' ? 'Belum Validasi' : 'Belum Tersedia') }}
                            </div>
                            
                            <div v-if="m.status === 'pending'" class="absolute inset-0 bg-red-500/5 opacity-0 group-hover:opacity-100 transition-opacity rounded-xl"></div>
                        </div>
                    </div>

                    <div class="flex items-center justify-end gap-2 border-t border-slate-100 pt-4">
                        <button @click="monthlyRecapModal=false" class="px-4 py-2 rounded-xl bg-slate-100 text-slate-700 font-bold hover:bg-slate-200 transition-colors">Tutup</button>
                    </div>
                </div>
            </div>
            <div v-if="currentUnit === 'asrama'" class="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
                <div class="bg-white rounded-2xl p-4 shadow-sm border border-slate-100">
                    <div class="flex items-center justify-between mb-2">
                        <div class="text-[12px] font-bold text-slate-700">Rekap Mingguan</div>
                        <div class="text-[10px] text-slate-400">7 hari terakhir</div>
                    </div>
                    <div class="grid grid-cols-3 gap-2 text-center">
                        <div class="rounded-lg p-3 bg-emerald-50">
                            <div class="text-xl font-bold text-emerald-700">{{ weeklyMonthlyZero.weekly.safe }}</div>
                            <div class="text-[10px] text-emerald-600">Aman</div>
                        </div>
                        <div class="rounded-lg p-3 bg-red-50">
                            <div class="text-xl font-bold text-red-700">{{ weeklyMonthlyZero.weekly.incident }}</div>
                            <div class="text-[10px] text-red-600">Insiden</div>
                        </div>
                        <div class="rounded-lg p-3 bg-amber-50">
                            <div class="text-xl font-bold text-amber-700">{{ getWeeklyPending }}</div>
                            <div class="text-[10px] text-amber-600">Lupa</div>
                        </div>
                    </div>
                </div>
                <div class="bg-white rounded-2xl p-4 shadow-sm border border-slate-100">
                    <div class="flex items-center justify-between mb-2">
                        <div class="text-[12px] font-bold text-slate-700">Rekap Bulanan</div>
                        <div class="text-[10px] text-slate-400">31 hari terakhir</div>
                    </div>
                    <div class="grid grid-cols-3 gap-2 text-center">
                        <div class="rounded-lg p-3 bg-emerald-50">
                            <div class="text-xl font-bold text-emerald-700">{{ weeklyMonthlyZero.monthly.safe }}</div>
                            <div class="text-[10px] text-emerald-600">Aman</div>
                        </div>
                        <div class="rounded-lg p-3 bg-red-50">
                            <div class="text-xl font-bold text-red-700">{{ weeklyMonthlyZero.monthly.incident }}</div>
                            <div class="text-[10px] text-red-600">Insiden</div>
                        </div>
                        <div class="rounded-lg p-3 bg-amber-50">
                            <div class="text-xl font-bold text-amber-700">{{ getMonthlyPending }}</div>
                            <div class="text-[10px] text-amber-600">Lupa</div>
                        </div>
                    </div>
                </div>
                <div class="bg-white rounded-2xl p-4 shadow-sm border border-slate-100 relative overflow-hidden">
                    <div class="absolute inset-0 pointer-events-none" :class="zeroUrgencyClass"></div>
                    <div class="relative">
                        <div class="flex items-center justify-between mb-2">
                            <div class="text-[12px] font-bold text-slate-700">Status Laporan Malam</div>
                            <div class="text-[10px] text-slate-400">{{ zeroUrgencyText }}</div>
                        </div>
                        <div class="space-y-2 max-h-32 overflow-y-auto">
                            <div v-for="r in zeroTodayReports" :key="r.name + r.created_at" class="flex items-center justify-between p-2 rounded border border-slate-200">
                                <div class="text-[12px] font-bold text-slate-800 truncate">{{ r.name }}</div>
                                <div class="flex items-center gap-2 text-[11px]">
                                    <span :class="r.status==='SAFE' ? 'text-emerald-600' : (r.status==='INCIDENT' ? 'text-amber-600' : 'text-red-600')">{{ r.status }}</span>
                                    <span class="text-slate-400">{{ new Date(r.created_at).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }) }}</span>
                                    <button v-if="String(r.status||'').toUpperCase()==='PENDING'" @click="nudgeMusyrif(r.name)" class="ml-2 px-2 py-0.5 rounded bg-red-600 text-white font-bold">Hubungi</button>
                                </div>
                            </div>
                            <div v-if="zeroTodayReports.length === 0" class="text-xs text-slate-500">Belum ada laporan.</div>
                        </div>
                    </div>
                </div>
            </div>
            <div v-if="currentUnit === 'asrama'" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div class="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
                    <div class="flex items-center gap-3 mb-4">
                        <div class="w-12 h-12 rounded-xl bg-amber-100 text-amber-600 flex items-center justify-center text-xl">
                            <i class="fas fa-sign-out-alt"></i>
                        </div>
                        <div>
                            <div class="text-sm text-slate-500">Izin Berjalan</div>
                            <div class="text-2xl font-bold text-slate-800">{{ permissionsActive.length }}</div>
                        </div>
                    </div>
                    <div class="space-y-2">
                        <div v-for="p in permissionsActive.slice(0,6)" :key="p.id" class="flex items-center justify-between p-3 border border-slate-200 rounded-xl">
                            <div>
                                <div class="text-sm font-bold text-slate-800 truncate">{{ p.student_name }}</div>
                                <div class="text-[10px] text-slate-500">{{ p.permission_type }} • {{ p.status }}</div>
                            </div>
                            <div class="text-[10px] text-slate-400">{{ formatDate(p.start_date) }}–{{ formatDate(p.end_date) }}</div>
                        </div>
                        <div v-if="permissionsActive.length === 0" class="text-xs text-slate-500">Tidak ada izin aktif.</div>
                    </div>
                </div>
                <div class="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
                    <div class="flex items-center gap-3 mb-4">
                        <div class="w-12 h-12 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center text-xl">
                            <i class="fas fa-trophy"></i>
                        </div>
                        <div>
                            <div class="text-sm text-slate-500">Prestasi Terbaru</div>
                            <div class="text-2xl font-bold text-slate-800">{{ achievementsRecent.length }}</div>
                        </div>
                    </div>
                    <div class="space-y-2">
                        <div v-for="a in achievementsRecent.slice(0,6)" :key="a.id" class="flex items-center justify-between p-3 border border-slate-200 rounded-xl">
                            <div>
                                <div class="text-sm font-bold text-slate-800 truncate">{{ a.student_name }}</div>
                                <div class="text-[10px] text-slate-500">{{ a.category }} • {{ a.points }} Poin</div>
                            </div>
                            <div class="text-[10px] text-slate-400">{{ formatDate(a.record_date) }}</div>
                        </div>
                        <div v-if="achievementsRecent.length === 0" class="text-xs text-slate-500">Belum ada data prestasi.</div>
                    </div>
                </div>
                <div class="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
                    <div class="flex items-center gap-3 mb-4">
                        <div class="w-12 h-12 rounded-xl bg-red-100 text-red-600 flex items-center justify-center text-xl">
                            <i class="fas fa-exclamation-triangle"></i>
                        </div>
                        <div>
                            <div class="text-sm text-slate-500">Pelanggaran Terbaru</div>
                            <div class="text-2xl font-bold text-slate-800">{{ violationsRecent.length }}</div>
                        </div>
                    </div>
                    <div class="space-y-2">
                        <div v-for="v in violationsRecent.slice(0,6)" :key="v.id" class="flex items-center justify-between p-3 border border-slate-200 rounded-xl">
                            <div>
                                <div class="text-sm font-bold text-slate-800 truncate">{{ v.student_name }}</div>
                                <div class="text-[10px] text-slate-500">{{ v.category }} • {{ v.points }} Poin</div>
                            </div>
                            <div class="text-[10px] text-slate-400">{{ formatDate(v.record_date) }}</div>
                        </div>
                        <div v-if="violationsRecent.length === 0" class="text-xs text-slate-500">Belum ada data pelanggaran.</div>
                    </div>
                </div>
            </div>
            <div v-if="currentUnit === 'asrama'" class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div class="lg:col-span-2">
                    <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                        <div class="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
                            <h3 class="font-bold text-slate-800 flex items-center gap-2">
                                <i class="fas fa-layer-group text-indigo-600"></i> Center Asrama
                            </h3>
                            <div class="flex items-center gap-2">
                                <button @click="activeTab='MEETINGS'" class="text-[11px] font-bold px-3 py-1 rounded" :class="activeTab==='MEETINGS' ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-700'">Rapat</button>
                                <button @click="activeTab='TASKS'" class="text-[11px] font-bold px-3 py-1 rounded" :class="activeTab==='TASKS' ? 'bg-amber-600 text-white' : 'bg-slate-100 text-slate-700'">Task</button>
                                <button @click="activeTab='PROC'" class="text-[11px] font-bold px-3 py-1 rounded" :class="activeTab==='PROC' ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-700'">Pengajuan</button>
                                <button @click="activeTab='DOCS'" class="text-[11px] font-bold px-3 py-1 rounded" :class="activeTab==='DOCS' ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-700'">Dokumen</button>
                                <button @click="activeTab='ZERO'" class="text-[11px] font-bold px-3 py-1 rounded" :class="activeTab==='ZERO' ? 'bg-red-600 text-white' : 'bg-slate-100 text-slate-700'">Zero Report</button>
                            </div>
                        </div>
                        <div class="p-5">
                            <div v-show="activeTab==='MEETINGS'">
                                <div class="flex items-center justify-between mb-3">
                                    <div class="text-[12px] font-bold text-slate-600">Rapat Asrama</div>
                                    <span class="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-700" v-if="recentMeetingCount > 0">{{ recentMeetingCount }} baru</span>
                                </div>
                                <div v-if="meetings.length > 0" class="rounded-xl border border-slate-200 overflow-hidden">
                                    <div class="divide-y divide-slate-100">
                                        <div v-for="m in meetings" :key="m.id" class="px-4 py-3 bg-white hover:bg-slate-50 transition-colors">
                                            <div class="flex items-center justify-between">
                                                <div>
                                                    <div class="font-bold text-slate-800 text-sm">{{ m.title }}</div>
                                                    <div class="text-[10px] font-mono text-slate-500">{{ m.meeting_number }}</div>
                                                </div>
                                                <div class="text-right">
                                                    <div class="text-[10px] text-slate-400">{{ formatDate(m.meeting_date) }}</div>
                                                    <div class="flex gap-2 justify-end mt-1">
                                                        <a :href="baseUrl + 'api/meetings.php?action=list_documents&meeting_id=' + m.id" target="_blank" class="text-[10px] font-bold text-indigo-600 hover:underline">Dokumen</a>
                                                    </div>
                                                </div>
                                            </div>
                                            <p class="text-xs text-slate-500 mt-2" v-if="m.notes">{{ m.notes }}</p>
                                        </div>
                                    </div>
                                </div>
                                <div v-else class="text-center text-slate-400 text-sm py-3">Belum ada rapat.</div>
                            </div>
                            <div v-show="activeTab==='TASKS'">
                                <div class="flex items-center justify-between mb-3">
                                    <div class="text-[12px] font-bold text-slate-600">Task Asrama</div>
                                    <button @click="tasks.push({ id: Date.now(), text: '', done: false })" class="text-[11px] font-bold px-3 py-1 rounded bg-amber-600 text-white">Tambah</button>
                                </div>
                                <div v-if="tasks.length > 0" class="rounded-xl border border-slate-200 overflow-hidden">
                                    <div class="divide-y divide-slate-100">
                                        <div v-for="(t, idx) in tasks" :key="t.id" class="px-4 py-3 bg-white">
                                            <div class="flex items-center gap-2">
                                                <input type="checkbox" v-model="t.done" @change="saveTasks">
                                                <input v-model="t.text" @change="saveTasks" class="flex-1 border border-slate-300 rounded px-3 py-1 text-sm">
                                                <button @click="tasks.splice(idx,1); saveTasks()" class="text-[11px] font-bold px-2 py-1 rounded bg-red-600 text-white">Hapus</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div v-else class="text-center text-slate-400 text-sm py-3">Belum ada task.</div>
                            </div>
                            <div v-show="activeTab==='PROC'">
                                <div class="text-[12px] font-bold text-slate-600 mb-3">Pengajuan</div>
                                <div v-if="approvals.length > 0" class="rounded-xl border border-slate-200 overflow-hidden">
                                    <div class="divide-y divide-slate-100">
                                        <div v-for="a in approvals" :key="a.id" class="px-4 py-3 bg-white hover:bg-slate-50 transition-colors">
                                            <div class="flex items-center justify-between">
                                                <div>
                                                    <div class="font-bold text-slate-800 text-sm">{{ a.title || a.type }}</div>
                                                    <div class="text-[10px] text-slate-500">{{ a.status }}</div>
                                                </div>
                                                <div class="text-right">
                                                    <div class="text-[10px] text-slate-400">{{ formatDate(a.created_at) }}</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div v-else class="text-center text-slate-400 text-sm py-3">Belum ada pengajuan.</div>
                            </div>
                            <div v-show="activeTab==='DOCS'">
                                <div class="text-[12px] font-bold text-slate-600 mb-3">Dokumen Rapat</div>
                                <div v-if="documents.length > 0" class="rounded-xl border border-slate-200 overflow-hidden">
                                    <div class="divide-y divide-slate-100">
                                        <div v-for="d in documents" :key="d.id" class="px-4 py-3 bg-white hover:bg-slate-50 transition-colors flex items-center justify-between">
                                            <div>
                                                <div class="font-bold text-slate-800 text-sm">{{ d.title || d.file_name }}</div>
                                                <div class="text-[10px] text-slate-500">{{ d.meeting_title || d.meeting_number }}</div>
                                            </div>
                                            <a :href="baseUrl + (d.url || ('uploads/managerial/docs/' + d.file_name))" target="_blank" class="text-[11px] font-bold px-3 py-1 rounded bg-indigo-600 text-white">Buka</a>
                                        </div>
                                    </div>
                                </div>
                                <div v-else class="text-center text-slate-400 text-sm py-3">Belum ada dokumen.</div>
                            </div>
                            <div v-show="activeTab==='ZERO'">
                                <div class="text-[12px] font-bold text-slate-800 mb-3 flex items-center gap-2">
                                    <i class="fas fa-shield-alt text-red-600"></i> Monitoring Zero Report (Harian)
                                </div>
                                <div class="grid grid-cols-3 gap-3 mb-4">
                                    <div class="rounded-xl border border-slate-200 p-3 bg-emerald-50 text-center">
                                        <div class="text-2xl font-bold text-emerald-700">{{ zeroCounts.safe }}</div>
                                        <div class="text-[10px] text-emerald-600">Sudah Lapor Aman</div>
                                    </div>
                                    <div class="rounded-xl border border-slate-200 p-3 bg-amber-50 text-center">
                                        <div class="text-2xl font-bold text-amber-700">{{ zeroCounts.incident }}</div>
                                        <div class="text-[10px] text-amber-600">Ada Insiden</div>
                                    </div>
                                    <div class="rounded-xl border border-slate-200 p-3 bg-red-50 text-center">
                                        <div class="text-2xl font-bold text-red-700">{{ zeroCounts.pending }}</div>
                                        <div class="text-[10px] text-red-600">Belum Lapor</div>
                                    </div>
                                </div>
                                <div class="rounded-xl border border-slate-200 overflow-hidden">
                                    <div class="p-3 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
                                        <div class="text-[12px] font-bold text-slate-700">Rekap Hari Ini</div>
                                        <div class="text-[10px] text-slate-500">Top Responder: {{ topResponder.name || '-' }} ({{ topResponder.time || '-' }})</div>
                                    </div>
                                    <div class="divide-y divide-slate-100">
                                        <div v-for="r in zeroTodayReports" :key="r.name + r.created_at" class="px-4 py-2 bg-white flex items-center justify-between">
                                            <div class="text-sm font-bold text-slate-800">{{ r.name }}</div>
                                            <div class="flex items-center text-[11px]">
                                                <span :class="r.status==='SAFE' ? 'text-emerald-600' : (r.status==='INCIDENT' ? 'text-amber-600' : 'text-red-600')">{{ r.status }}</span>
                                                <span class="text-slate-400 ml-2">{{ formatDate(r.created_at) }}</span>
                                                <button v-if="String(r.status||'').toUpperCase()==='PENDING'" @click="nudgeMusyrif(r.name)" class="ml-3 px-2 py-0.5 rounded bg-red-600 text-white font-bold">Hubungi</button>
                                            </div>
                                        </div>
                                        <div v-if="zeroTodayReports.length === 0" class="px-4 py-3 text-center text-slate-400 text-sm">Belum ada laporan.</div>
                                    </div>
                                </div>
                                <div class="mt-4">
                                    <div class="text-[12px] font-bold text-slate-800 mb-2">Butuh Persetujuan Anda Segera</div>
                                    <div class="grid grid-cols-1 gap-2">
                                        <div v-for="a in approvals.filter(x => x.status!=='APPROVED').sort((x,y)=>getWaitingHours(y)-getWaitingHours(x)).slice(0,6)" :key="a.id" class="p-2 border border-slate-200 rounded bg-white">
                                            <div class="flex items-center justify-between mb-1">
                                                <div class="text-[12px] text-slate-700 truncate">{{ a.title || (a.module + ' #' + a.reference_no) }}</div>
                                                <div class="text-[10px] font-bold" :class="a.status==='PENDING' ? 'text-amber-600' : 'text-red-600'">{{ a.status }}</div>
                                            </div>
                                            <div class="h-2 rounded bg-red-100 overflow-hidden">
                                                <div class="h-2 bg-red-600" :style="{ width: getWaitingBarWidth(a) }"></div>
                                            </div>
                                            <div class="text-[10px] text-red-600 mt-1">Menunggu Anda selama {{ getWaitingText(a) }}</div>
                                        </div>
                                        <div v-if="approvals.filter(x => x.status!=='APPROVED').length === 0" class="text-xs text-slate-500">Tidak ada isu terbuka.</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <aside class="lg:col-span-1">
                    <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden h-full flex flex-col">
                        <div class="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
                            <h3 class="font-bold text-slate-800 flex items-center gap-2">
                                <i class="fas fa-comments text-indigo-600"></i> Chat Asrama
                            </h3>
                        </div>
                        <div class="p-5 flex-1 overflow-y-auto">
                            <div v-if="chatMessages.length > 0" class="space-y-3">
                                <div v-for="(c, idx) in chatMessages" :key="c.id" class="flex items-start justify-between">
                                    <div class="max-w-[80%]">
                                        <div class="text-[12px] text-slate-700 bg-slate-50 border border-slate-200 rounded px-3 py-2">{{ c.text }}</div>
                                        <div class="text-[10px] text-slate-400 mt-1">{{ formatChatTime(c.ts) }}</div>
                                    </div>
                                    <button @click="deleteChatMessage(idx)" class="text-[10px] font-bold text-red-600">Hapus</button>
                                </div>
                            </div>
                            <div v-else class="text-center text-slate-400 text-sm py-3">Belum ada pesan.</div>
                        </div>
                        <div class="p-4 border-t border-slate-100 bg-white">
                            <div class="flex items-center gap-2">
                                <input v-model="chatInput" @keyup.enter="sendChat" class="flex-1 border border-slate-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-indigo-500" placeholder="Tulis pesan...">
                                <button @click="sendChat" class="px-3 py-2 rounded bg-indigo-600 text-white text-[12px] font-bold">Kirim</button>
                            </div>
                        </div>
                    </div>
                </aside>
            </div>
            <div v-if="currentUnit !== 'asrama' && currentPosition !== 'wali'" class="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
                <div class="p-5 border-b border-slate-100 flex items-center justify-between">
                    <h3 class="text-lg font-bold text-slate-800">Aktivitas Terkini</h3>
                    <div class="flex items-center gap-2">
                        <button @click="setActivityTab('PRESENSI')" :class="activityButtonClass('PRESENSI')" class="text-xs font-bold px-3 py-1 rounded">Presensi</button>
                        <button @click="setActivityTab('RAPAT')" :class="activityButtonClass('RAPAT')" class="text-xs font-bold px-3 py-1 rounded">Rapat</button>
                        <button @click="setActivityTab('KEGIATAN')" :class="activityButtonClass('KEGIATAN')" class="text-xs font-bold px-3 py-1 rounded">Kegiatan</button>
                    </div>
                </div>
                <div class="p-5">
                    <div v-if="activeActivityTab === 'PRESENSI'">
                        <div v-if="activities.PRESENSI.length > 0" class="space-y-3">
                            <div v-for="a in activities.PRESENSI" :key="a.created_at + (a.entity_id || '')" class="flex items-center justify-between p-3 border border-slate-200 rounded-xl">
                                <div>
                                    <div class="text-sm font-bold text-slate-800">{{ a.title || (a.action + ' Presensi') }}</div>
                                    <div class="text-[10px] text-slate-500">{{ formatDate(a.created_at) }}</div>
                                </div>
                                <div class="text-xs text-slate-500">{{ a.people_name || a.username || '-' }}</div>
                            </div>
                        </div>
                        <div v-else class="text-xs text-slate-500">Belum ada aktivitas presensi.</div>
                    </div>
                    <div v-if="activeActivityTab === 'RAPAT'">
                        <div v-if="activities.RAPAT.length > 0" class="space-y-3">
                            <div v-for="a in activities.RAPAT" :key="a.created_at + (a.entity_id || '')" class="flex items-center justify-between p-3 border border-slate-200 rounded-xl">
                                <div>
                                    <div class="text-sm font-bold text-slate-800">{{ a.title || 'Rapat' }}</div>
                                    <div class="text-[10px] text-slate-500">{{ formatDate(a.created_at) }}</div>
                                </div>
                                <div class="text-xs text-slate-500">{{ a.people_name || a.username || '-' }}</div>
                            </div>
                        </div>
                        <div v-else class="text-xs text-slate-500">Belum ada aktivitas rapat.</div>
                    </div>
                    <div v-if="activeActivityTab === 'KEGIATAN'">
                        <div v-if="activities.KEGIATAN.length > 0" class="space-y-3">
                            <div v-for="a in activities.KEGIATAN" :key="a.created_at + (a.entity_id || '')" class="flex items-center justify-between p-3 border border-slate-200 rounded-xl">
                                <div>
                                    <div class="text-sm font-bold text-slate-800">{{ a.title || 'Kegiatan' }}</div>
                                    <div class="text-[10px] text-slate-500">{{ formatDate(a.created_at) }}</div>
                                </div>
                                <div class="text-xs text-slate-500">{{ a.people_name || a.username || '-' }}</div>
                            </div>
                        </div>
                        <div v-else class="text-xs text-slate-500">Belum ada aktivitas kegiatan.</div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <div v-if="resolveModal" class="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm" v-cloak>
        <div class="bg-white rounded-xl shadow-2xl w-full max-w-md overflow-hidden flex flex-col">
            <div class="p-4 border-b border-slate-100 bg-emerald-50 flex items-center justify-between">
                <h3 class="font-bold text-slate-800 text-sm">Selesaikan Internal</h3>
                <button @click="resolveModal=false" class="text-slate-500"><i class="fas fa-times"></i></button>
            </div>
            <div class="p-4 space-y-3">
                <div class="text-xs text-slate-500">Berikan catatan peringatan untuk siswa terkait.</div>
                <div>
                    <label class="block text-xs font-bold text-slate-700 mb-1">Catatan Peringatan</label>
                    <textarea v-model="resolveNote" rows="3" class="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm"></textarea>
                </div>
            </div>
            <div class="p-4 border-t border-slate-100 bg-slate-50 text-right">
                <button @click="resolveModal=false" class="px-3 py-1 text-[12px] font-bold border border-slate-300 text-slate-600 rounded">Batal</button>
                <button @click="submitResolveInternal" class="ml-2 px-3 py-1 text-[12px] font-bold bg-emerald-600 text-white rounded">Tandai Selesai</button>
            </div>
        </div>
    </div>
    <div v-if="escalateModal" class="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm" v-cloak>
        <div class="bg-white rounded-xl shadow-2xl w-full max-w-md overflow-hidden flex flex-col">
            <div class="p-4 border-b border-slate-100 bg-red-50 flex items-center justify-between">
                <h3 class="font-bold text-slate-800 text-sm">Eskalasi ke BK</h3>
                <button @click="escalateModal=false" class="text-slate-500"><i class="fas fa-times"></i></button>
            </div>
            <div class="p-4 space-y-3">
                <div class="text-xs text-slate-500">Berikan catatan pengantar untuk BK.</div>
                <div>
                    <label class="block text-xs font-bold text-slate-700 mb-1">Catatan Pengantar</label>
                    <textarea v-model="escalateNote" rows="3" class="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm"></textarea>
                </div>
            </div>
            <div class="p-4 border-t border-slate-100 bg-slate-50 text-right">
                <button @click="escalateModal=false" class="px-3 py-1 text-[12px] font-bold border border-slate-300 text-slate-600 rounded">Batal</button>
                <button @click="submitEscalateBK" class="ml-2 px-3 py-1 text-[12px] font-bold bg-red-600 text-white rounded">Eskalasi</button>
            </div>
        </div>
    </div>
    <?php include '../../includes/modals/student_modal.php'; ?>

    <!-- Attendance Validation Modal -->
    <div v-if="attendanceValidationModal" class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" v-cloak>
        <div class="bg-white rounded-2xl shadow-xl w-full max-w-6xl max-h-[90vh] flex flex-col overflow-hidden">
            <div class="px-6 py-4 border-b border-slate-100 flex justify-between items-center bg-slate-50">
                <div>
                    <h3 class="font-bold text-lg text-slate-800">Validasi Presensi Bulanan</h3>
                    <p class="text-sm text-slate-500">
                        Kelas: {{ className }} | Bulan: {{ attendanceBatchMonth }}/{{ attendanceBatchYear }}
                    </p>
                </div>
                <div class="flex items-center gap-3">
                    <div class="flex items-center bg-blue-50 border border-blue-100 rounded-xl px-3 py-1.5 shadow-sm">
                        <span class="text-[10px] font-bold text-blue-400 uppercase mr-2">Hari Aktif</span>
                        <input v-model.number="attendanceBatchActiveDays" type="number" @input="recalculateAllBatch" class="bg-transparent border-none text-sm font-bold text-blue-700 focus:ring-0 outline-none w-12 text-center" placeholder="22">
                    </div>
                    <button @click="attendanceValidationModal = false" class="text-slate-400 hover:text-slate-600">
                        <i class="fas fa-times text-xl"></i>
                    </button>
                </div>
            </div>
            
            <div class="flex-1 overflow-auto p-0 bg-slate-50">
                <div v-if="attendanceBatchLoading" class="flex items-center justify-center h-64">
                    <i class="fas fa-spinner fa-spin text-3xl text-blue-500"></i>
                </div>
                <div v-else class="overflow-x-auto">
                    <table class="w-full text-left border-collapse bg-white">
                        <thead class="sticky top-0 z-10 bg-slate-50 shadow-sm">
                            <tr>
                                <th class="px-4 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-center w-12 border-b border-slate-200">No</th>
                                <th class="px-4 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-widest w-24 border-b border-slate-200">NIS</th>
                                <th class="px-4 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-widest border-b border-slate-200">Nama Siswa</th>
                                <th class="px-2 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-center w-20 bg-slate-100/50 border-b border-slate-200">Izin</th>
                                <th class="px-2 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-center w-20 bg-slate-100/50 border-b border-slate-200">Sakit</th>
                                <th class="px-2 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-center w-20 bg-slate-100/50 border-b border-slate-200">Alfa</th>
                                <th class="px-2 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-center w-20 bg-slate-100/50 border-b border-slate-200">Cuti</th>
                                <th class="px-2 py-3 text-[10px] font-bold text-blue-600 uppercase tracking-widest text-center w-20 border-l border-slate-100 border-b border-slate-200">Hadir</th>
                                <th class="px-4 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-widest border-b border-slate-200">Keterangan</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100">
                            <tr v-for="(s, idx) in attendanceBatchStudents" :key="s.id" class="hover:bg-slate-50 transition-colors">
                                <td class="px-4 py-2 text-xs text-center text-slate-400 font-mono border-r border-slate-100">{{ idx + 1 }}</td>
                                <td class="px-4 py-2 text-xs text-slate-500 font-mono border-r border-slate-100">{{ s.nis }}</td>
                                <td class="px-4 py-2 text-sm font-bold text-slate-700">{{ s.name }}</td>
                                
                                <td class="px-2 py-2 bg-slate-50/30">
                                    <input v-model.number="s.izin" @input="recalculateBatch(s)" type="number" class="w-full text-center py-1 bg-white border border-slate-200 rounded text-sm font-bold text-slate-700 focus:border-blue-500 focus:ring-0" placeholder="0">
                                </td>
                                <td class="px-2 py-2 bg-slate-50/30">
                                    <input v-model.number="s.sakit" @input="recalculateBatch(s)" type="number" class="w-full text-center py-1 bg-white border border-slate-200 rounded text-sm font-bold text-slate-700 focus:border-blue-500 focus:ring-0" placeholder="0">
                                </td>
                                <td class="px-2 py-2 bg-slate-50/30">
                                    <input v-model.number="s.alfa" @input="recalculateBatch(s)" type="number" class="w-full text-center py-1 bg-white border border-slate-200 rounded text-sm font-bold text-slate-700 focus:border-blue-500 focus:ring-0" placeholder="0">
                                </td>
                                <td class="px-2 py-2 bg-slate-50/30">
                                    <input v-model.number="s.cuti" @input="recalculateBatch(s)" type="number" class="w-full text-center py-1 bg-white border border-slate-200 rounded text-sm font-bold text-slate-700 focus:border-blue-500 focus:ring-0" placeholder="0">
                                </td>
                                
                                <td class="px-2 py-2 border-l border-slate-100">
                                    <div class="w-full text-center py-1 bg-blue-50 text-blue-700 font-bold rounded text-sm">
                                        {{ s.hadir }}
                                    </div>
                                </td>
                                <td class="px-4 py-2">
                                    <input v-model="s.remarks" type="text" class="w-full px-2 py-1 border border-slate-100 rounded text-xs text-slate-500 italic focus:border-blue-500 focus:ring-0" placeholder="...">
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="p-4 border-t border-slate-100 bg-white flex justify-end gap-3">
                <button @click="attendanceValidationModal = false" class="px-4 py-2 text-sm font-medium text-slate-500 hover:text-slate-700 bg-slate-50 hover:bg-slate-100 rounded-lg transition-colors">
                    Batal
                </button>
                <button @click="saveBatchAttendance" :disabled="attendanceBatchSaving || attendanceBatchLoading" class="px-6 py-2 text-sm font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-lg shadow-blue-200 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center gap-2">
                    <i v-if="attendanceBatchSaving" class="fas fa-spinner fa-spin"></i>
                    <span>{{ attendanceBatchSaving ? 'Menyimpan...' : 'Simpan & Validasi' }}</span>
                </button>
            </div>
        </div>
    </div>
    <!-- Unlock Modal -->
    <div v-if="showUnlockModal" class="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm" v-cloak>
        <div class="bg-white rounded-xl shadow-2xl w-full max-w-md overflow-hidden flex flex-col">
            <div class="p-4 border-b border-slate-100 bg-indigo-50 flex items-center justify-between">
                <h3 class="font-bold text-slate-800 text-sm">Buka Kunci Walikelas</h3>
                <button @click="showUnlockModal=false" class="text-slate-500"><i class="fas fa-times"></i></button>
            </div>
            <div class="p-4 space-y-4">
                <div class="bg-indigo-50 border border-indigo-100 rounded-lg p-3 flex items-start gap-3">
                    <i class="fas fa-info-circle text-indigo-500 mt-0.5"></i>
                    <div class="text-xs text-indigo-700">
                        Anda akan membuka kunci akses untuk kelas <b>{{ selectedLockClass ? selectedLockClass.name : '-' }}</b>.
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-700 mb-1">Jenis Kunci yang Dibuka</label>
                    <select v-model="unlockType" class="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm font-bold text-slate-700">
                        <option value="ALL">Semua (Buka Total)</option>
                        <option value="ATTENDANCE">Absensi (M+5)</option>
                        <option value="FACILITY">Fasilitas (Sabtu)</option>
                        <option value="COMPLAINT">Aduan (Komplain)</option>
                    </select>
                    <p class="text-[10px] text-slate-500 mt-1">Pilih jenis kunci spesifik atau buka semua.</p>
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-700 mb-1">Durasi Buka (Jam)</label>
                    <input type="number" v-model.number="unlockDuration" class="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm" placeholder="24">
                </div>
                
                <div>
                    <label class="block text-xs font-bold text-slate-700 mb-1">Alasan Pembukaan</label>
                    <textarea v-model="unlockReason" rows="2" class="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm" placeholder="Contoh: Sudah konfirmasi lisan..."></textarea>
                </div>
            </div>
            <div class="p-4 border-t border-slate-100 bg-slate-50 text-right">
                <button @click="showUnlockModal=false" class="px-3 py-1 text-[12px] font-bold border border-slate-300 text-slate-600 rounded">Batal</button>
                <button @click="submitUnlock" class="ml-2 px-3 py-1 text-[12px] font-bold bg-indigo-600 text-white rounded hover:bg-indigo-700">Buka Kunci</button>
            </div>
        </div>
    </div>
</div>
<script type="module">
import { studentMixin } from '<?php echo $baseUrl; ?>assets/js/modules/student.js';
import { utilsMixin } from '<?php echo $baseUrl; ?>assets/js/modules/utils.js';
const { createApp } = Vue;
createApp({
    mixins: [studentMixin, utilsMixin],
    data() {
        return {
            baseUrl: (window.BASE_URL || (window.location.pathname.includes('/AIS/') ? '/AIS/' : '/')),
            currentUnit: localStorage.getItem('principalUnit') || 'sd',
            principalTab: 'DASHBOARD',
            principalDailyDate: new Date().toISOString().split('T')[0],
            principalMonth: new Date().getMonth() + 1,
            principalYear: new Date().getFullYear(),
            // Lock System
            lockStatus: { is_locked: false, locks: [], overrides: [] },
            unitLocks: [],
            showUnlockModal: false,
            selectedLockClass: null,
            unlockReason: '',
            unlockDuration: 24,
            unlockType: 'ALL',
            unitStats: {
                studentCount: 0,
                attendancePct: 0,
                bkActive: 0,
                inventoryIssues: 0,
                classes: []
            },
            currentTime: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
            isSaturday: new Date().getDay() === 6,
            attendanceSubmitted: false,
            monthlyRecapSubmitted: false,
            monthlyRecapModal: false,
            monthlyRecaps: [], // Added for monthly recap list
            currentPosition: (function(){ var s = localStorage.getItem('principalPosition'); if (s) return s; var r = String(window.USER_ROLE || '').toUpperCase(); return r === 'SUPERADMIN' ? 'wali' : 'kepala'; })(),
            userRole: (window.USER_ROLE || ''),
            classesOptions: [],
            selectedClassId: '',
            className: '',
            homeroomClassId: null,
            dailyDate: new Date().toISOString().substring(0,10),
            monthlyMonth: (new Date()).getMonth() + 1,
            monthlyYear: (new Date()).getFullYear(),
            monthlySource: '-',
            monthlyCalendar: [],
            monthlyStudentRows: [],
            topAbsentees: [],
            classStudents: [
                
            ],
            classCondition: 'Kuning',
            behaviorPointsAvg: 78,
            pendingIssues: [],
            resolveModal: false,
            resolveIncident: null,
            resolveNote: '',
            escalateModal: false,
            escalateIncident: null,
            escalateNote: '',
            bkQueue: [],
            inventoryAssets: [
                { id: 'INV-CHAIR', name: 'Kursi Siswa', count: 36, condition: 'Baik', note: 'Lengkap' },
                { id: 'INV-TABLE', name: 'Meja Siswa', count: 36, condition: 'Baik', note: 'Lengkap' },
                { id: 'INV-BOARD', name: 'Papan Tulis', count: 1, condition: 'Rusak Ringan', note: 'Ada noda spidol permanen' },
                { id: 'INV-AC', name: 'AC', count: 1, condition: 'Baik', note: 'Baru diservis' },
                { id: 'INV-CLOCK', name: 'Jam Dinding', count: 1, condition: 'Mati', note: 'Perlu ganti baterai' },
                { id: 'INV-CLEAN', name: 'Alat Kebersihan', count: 1, condition: 'Baik', note: 'Sapu, Pel, Pengki' }
            ],
            inventoryModal: false,
            inventorySelected: null,
            inventoryReportCount: 1,
            inventoryReportDesc: '',
            inventoryReportPhotoName: '',
            maintenanceTickets: [
                { id: 'MT-900', item: 'Papan Tulis', count: 1, status: 'In Progress', date: new Date(Date.now()-86400000).toISOString() }
            ],
            tasksDaily: [
                { id: 'TD-1', text: 'Verifikasi Absensi', done: false },
                { id: 'TD-2', text: 'Jurnal Kelas', done: false }
            ],
            tasksWeekly: [
                { id: 'TW-1', text: 'Zero Report Sarpras', done: false },
                { id: 'TW-2', text: 'Evaluasi Kedisiplinan', done: false }
            ],
            tasksMonthly: [
                { id: 'TM-1', text: 'Rekap Presensi', done: false },
                { id: 'TM-2', text: 'Rapat Orang Tua', done: false }
            ],
            bkLogs: [
                { id: 'BK-1', title: 'Konseling ringan', student: 'Dimas Putra', status: 'Closed', date: new Date(Date.now()-7200000).toISOString() }
            ],
            libraryNotifications: [
                { id: 'LIB-1', student: 'Citra Lestari', book: 'Fisika Dasar', status: 'Telat', due: new Date(Date.now()+86400000).toISOString() }
            ],
            teacherNotes: [
                { id: 'TN-1', text: 'Kondisi kelas perlu penertiban saat jam terakhir', ts: Date.now()-5400000 }
            ],
            teacherNoteInput: '',
            showAbsentModal: false,
            dailyVerifyModal: false,
            studentPortfolioModal: false,
            portfolioStudent: { academic_avg: 86, academic_top_subject: 'Matematika', library_loans: 2, library_late: 1, bk_points: 5, bk_active_cases: 0 },
            attendanceSummary: { present: 0, permit: 0, absent: 0 },
            classAttendanceSummary: [],
            activities: { PRESENSI: [], RAPAT: [], KEGIATAN: [] },
            studentCount: 0,
            classCount: 0,
            teacherCount: 0,
            activeActivityTab: 'PRESENSI',
            academicSlots: [],
            boardingGender: 'all',
            boardingCount: 0,
            permissionsActive: [],
            achievementsRecent: [],
            violationsRecent: [],
            roomsTop: [],
            halaqohTop: [],
            musyrifCount: 0,
            musyrifList: [],
            boardingStudents: [],
            activeTab: 'MEETINGS',
            meetings: [],
            approvals: [],
            documents: [],
            tasks: [],
            chatMessages: [],
            chatInput: '',
            recentMeetingCount: 0,
            zeroTodayReports: [],
            zeroCounts: { safe: 0, incident: 0, pending: 0 },
            topResponder: { name: null, time: null },
            counselingSummary: { achievements_recent: 0, cases_recent: 0, counseling_sessions_recent: 0 },
            weeklyMonthlyZero: { weekly: { safe: 0, incident: 0 }, monthly: { safe: 0, incident: 0 } },
            zeroUrgencyText: '',
            zeroUrgencyClass: '',
            classScheduleMap: {},
            bkSchedule: [],
            homeroomTab: 'DASH',
            bkTab: 'KONSELING',
            bkProfile: { profile: {}, team: [] },
            bkArticles: [],
            studentSearch: '',
            // Attendance Batch Validation Data
            attendanceValidationModal: false,
            attendanceBatchStudents: [],
            attendanceBatchActiveDays: 22,
            attendanceBatchMonth: null,
            attendanceBatchYear: null,
            attendanceBatchLoading: false,
            attendanceBatchSaving: false,
            // Lock System
            lockStatus: { is_locked: false, locks: [], overrides: [] },
            unitLocks: [],
            showUnlockModal: false,
            unlockForm: { class_id: '', lock_type: 'ALL', hours: 24, reason: '' },
            unlockTargetClass: null,
            facilityCheckModal: false,
            facilityCheck: { status: 'GOOD', notes: '' }
        };
    },
    computed: {
        unitName() {
            const map = { tk: 'TK', sd: 'SD', smp: 'SMP', sma: 'SMA', asrama: 'Asrama' };
            return map[this.currentUnit] || 'Unit';
        },
        positionName() {
            const map = { kepala: 'Kepala Sekolah', wakasek: 'Wakasek', wali: 'Wali Kelas' };
            return map[this.currentPosition] || 'Peran';
        },
        isAdmin() {
            const r = String(this.userRole || '').toUpperCase();
            return r === 'SUPERADMIN' || r === 'ADMIN';
        },
        isSuperAdmin() {
            const r = String(this.userRole || '').toUpperCase();
            return r === 'SUPERADMIN';
        },
        showWaliClassSelector() {
            return this.currentPosition === 'wali' && this.currentUnit !== 'asrama' && this.isSuperAdmin;
        },
        attendancePercent() {
            const total = this.classStudents.length || 0;
            const hadir = this.classStudents.filter(s => s.status === 'Hadir').length;
            const pct = total ? Math.round((hadir / total) * 100) : 0;
            return pct;
        },
        attendanceRingColor() {
            const p = this.attendancePercent;
            if (p >= 90) return '#10b981';
            if (p >= 75) return '#f59e0b';
            return '#ef4444';
        },
        attendanceRingDasharray() {
            const r = 54;
            const c = 2 * Math.PI * r;
            return c;
        },
        attendanceRingDashoffset() {
            const r = 54;
            const c = 2 * Math.PI * r;
            const p = this.attendancePercent;
            return c * (1 - (p / 100));
        },
        absentStudents() {
            const bad = ['Alfa','Izin','Sakit'];
            return this.classStudents.filter(s => bad.includes(s.status));
        },
        taskProgressDaily() {
            const t = this.tasksDaily;
            const total = t.length || 0;
            const done = t.filter(x => x.done).length;
            return total ? done / total : 0;
        },
        taskProgressWeekly() {
            const t = this.tasksWeekly;
            const total = t.length || 0;
            const done = t.filter(x => x.done).length;
            return total ? done / total : 0;
        },
        taskProgressMonthly() {
            const t = this.tasksMonthly;
            const total = t.length || 0;
            const done = t.filter(x => x.done).length;
            return total ? done / total : 0;
        },
        completionRate() {
            const avg = (this.taskProgressDaily + this.taskProgressWeekly + this.taskProgressMonthly) / 3;
            return avg;
        },
        wakasekWarning() {
            const now = new Date();
            const day = now.getDate();
            const rec = this.tasksMonthly.find(x => x.id==='TM-1');
            const done = rec ? !!rec.done : false;
            return day > 5 && !done;
        },
        getWeeklyPending() {
            const total = this.musyrifCount || 0;
            const reported = (this.weeklyMonthlyZero.weekly.safe || 0) + (this.weeklyMonthlyZero.weekly.incident || 0);
            return Math.max(0, total - reported);
        },
        getMonthlyPending() {
            const total = this.musyrifCount || 0;
            const reported = (this.weeklyMonthlyZero.monthly.safe || 0) + (this.weeklyMonthlyZero.monthly.incident || 0);
            return Math.max(0, total - reported);
        },
        moduleCode() {
            return this.currentUnit === 'asrama' ? 'BOARDING' : 'ACADEMIC';
        },
        activeClasses() {
            return this.classesOptions || [];
        },
        filteredClassStudents() {
            const q = String(this.studentSearch || '').toLowerCase();
            const rows = this.classStudents || [];
            if (!q) return rows;
            return rows.filter(s => (String(s.name||'').toLowerCase().includes(q) || String(s.nis||'').toLowerCase().includes(q)));
        }
    },
    watch: {
        currentUnit(n) {
            localStorage.setItem('principalUnit', n);
            this.unitName = n.toUpperCase();
            
            if (n === 'asrama') {
                // Asrama Logic
                this.attendanceSummary = { present: 0, permit: 0, absent: 0 };
                this.studentCount = 0;
                this.classCount = 0;
                this.teacherCount = 0;
                this.boardingCount = 0;
                this.activeTab = 'ZERO';
                
                this.fetchBoardingCount();
                this.fetchAsramaStats();
                this.fetchMeetings();
                this.fetchApprovals();
                this.fetchDocuments();
                this.loadTasks();
                this.loadChatMessages();
                this.fetchZeroTodayReports();
                this.fetchZeroSummary();
            } else {
                // School Unit Logic
                this.boardingCount = 0;
                this.clearAsramaStats();
                this.meetings = [];
                this.approvals = [];
                this.documents = [];
                this.tasks = [];
                this.chatMessages = [];
                this.chatInput = '';
                this.activeTab = 'MEETINGS';
                this.recentMeetingCount = 0;
                this.zeroTodayReports = [];
                this.zeroCounts = { safe: 0, incident: 0, pending: 0 };
                this.topResponder = { name: null, time: null };

                if (this.currentPosition === 'kepala') {
                    this.fetchUnitStats();
                    this.fetchUnitLocks();
                } else {
                    this.fetchAttendance();
                    this.fetchStats();
                    this.fetchAcademicAgenda();
                    this.fetchCounselingSummary();
                }
            }
            
            this.refreshActivities();
            if (this.showWaliClassSelector) {
                this.fetchClassesForUnit();
            }
        },
        currentPosition(n) {
            localStorage.setItem('principalPosition', n);
            
            if (n === 'kepala') {
                this.fetchUnitStats();
                this.fetchUnitLocks();
            } else if (this.currentUnit !== 'asrama') {
                this.fetchStats();
                this.refreshActivities();
            }
            
            if (n === 'wali') {
                this.checkLockStatus();
                this.fetchHomeroomClass();
                if (this.showWaliClassSelector) {
                    this.fetchClassesForUnit();
                }
                this.fetchAcademicAgenda();
                this.fetchBkProfile();
                this.fetchBkArticles();
                this.generateAcademicMonths();
            }
        },
        dailyDate() {
            if (this.homeroomClassId) {
                this.fetchDailyAttendance();
            }
        },
        homeroomClassId(val) {
            if (val && this.currentPosition === 'wali') {
                this.checkLockStatus();
            }
        },
        monthlyMonth() {
            this.fetchMonthlyData();
        },
        monthlyYear() {
            this.fetchMonthlyData();
        },
        principalTab(val) {
            if (val === 'TUGAS' && this.currentPosition === 'kepala') {
                this.fetchUnitLocks();
            }
        }
    },
    methods: {
        positionClass(code) {
            return this.currentPosition === code ? 'bg-white text-slate-800 shadow ring-1 ring-slate-200' : 'text-slate-600';
        },
        getMonthName(m) {
            const months = ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
            return months[m-1] || '';
        },
        confirmValidateMonth(m) {
            this.openValidationModal(m);
        },
        openValidationModal(m) {
            if (!this.homeroomClassId) return;
            this.attendanceBatchMonth = m.val;
            this.attendanceBatchYear = m.year;
            this.attendanceValidationModal = true;
            this.fetchBatchStudents();
        },
        async fetchBatchStudents() {
            this.attendanceBatchLoading = true;
            try {
                this.normalizeBaseUrl();
                const res = await fetch(this.baseUrl + `api/attendance.php?action=get_students_for_attendance&class_id=${this.homeroomClassId}&month=${this.attendanceBatchMonth}&year=${this.attendanceBatchYear}`);
                const data = await res.json();
                if (data && data.success) {
                    this.attendanceBatchStudents = data.data.map(s => ({
                        ...s,
                        izin: Number(s.izin) || 0,
                        sakit: Number(s.sakit) || 0,
                        alfa: Number(s.alfa) || 0,
                        cuti: Number(s.cuti) || 0,
                        hadir: (typeof s.hadir === 'number' ? s.hadir : Number(s.hadir)) || this.attendanceBatchActiveDays,
                        remarks: s.remarks || ''
                    }));
                    if (this.attendanceBatchStudents.length > 0 && this.attendanceBatchStudents[0].active_days) {
                        this.attendanceBatchActiveDays = this.attendanceBatchStudents[0].active_days;
                    }
                    this.recalculateAllBatch();
                }
            } catch (e) {
                alert('Gagal mengambil data siswa');
            } finally {
                this.attendanceBatchLoading = false;
            }
        },
        recalculateBatch(student) {
            const active = Number(this.attendanceBatchActiveDays) || 0;
            const izin = Number(student.izin) || 0;
            const sakit = Number(student.sakit) || 0;
            const alfa = Number(student.alfa) || 0;
            const cuti = Number(student.cuti) || 0;
            const exceptions = izin + sakit + alfa + cuti;
            student.hadir = Math.max(0, active - exceptions);
        },
        recalculateAllBatch() {
            this.attendanceBatchStudents.forEach(s => this.recalculateBatch(s));
        },
        async saveBatchAttendance() {
            this.attendanceBatchSaving = true;
            try {
                this.normalizeBaseUrl();
                const res = await fetch(this.baseUrl + 'api/attendance.php?action=save_attendance_batch', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        class_id: this.homeroomClassId,
                        month: this.attendanceBatchMonth,
                        year: this.attendanceBatchYear,
                        active_days: this.attendanceBatchActiveDays,
                        records: this.attendanceBatchStudents
                    })
                });
                const data = await res.json();
                if (data && data.success) {
                    alert('Presensi berhasil disimpan!');
                    this.attendanceValidationModal = false;
                    await this.fetchClassAttendanceSummary();
                    this.generateAcademicMonths();
                } else {
                    alert((data && data.message) ? data.message : 'Gagal menyimpan presensi');
                }
            } catch (e) {
                alert('Terjadi kesalahan sistem');
            } finally {
                this.attendanceBatchSaving = false;
            }
        },
        async fetchClassAttendanceSummary() {
            if (!this.homeroomClassId) { this.classAttendanceSummary = []; return; }
            try {
                this.normalizeBaseUrl();
                const r = await fetch(this.baseUrl + 'api/attendance.php?action=get_class_attendance_summary&class_id=' + encodeURIComponent(this.homeroomClassId));
                const j = await r.json();
                this.classAttendanceSummary = j && j.success ? (j.data || []) : [];
            } catch (_) {
                this.classAttendanceSummary = [];
            }
        },
        async fetchHomeroomClass() {
            try {
                this.normalizeBaseUrl();
                const r = await fetch(this.baseUrl + 'api/attendance.php?action=get_homeroom_class');
                const j = await r.json();
                const d = j && j.success ? j.data : null;
                if (d && d.id) {
                    this.homeroomClassId = d.id;
                    this.className = d.name || '';
                    await this.fetchDailyAttendance();
                    await this.fetchClassAttendanceSummary();
                    await this.fetchPendingIssues();
                    await this.fetchClassSchedule();
                    await this.fetchBkSchedule();
                    await this.fetchBkProfile();
                    await this.fetchBkArticles();
                    this.generateAcademicMonths(); // Ensure data is ready
                } else {
                    this.homeroomClassId = null;
                    this.className = '';
                    this.classStudents = [];
                    this.classAttendanceSummary = [];
                    await this.fetchPendingIssues();
                    this.classScheduleMap = {};
                    this.bkSchedule = [];
                    this.bkProfile = { profile: {}, team: [] };
                    this.bkArticles = [];
                }
            } catch (_) {
                this.homeroomClassId = null;
                this.className = '';
                this.classStudents = [];
                this.classAttendanceSummary = [];
                await this.fetchPendingIssues();
                this.classScheduleMap = {};
                this.bkSchedule = [];
                this.bkProfile = { profile: {}, team: [] };
                this.bkArticles = [];
            }
        },
        async fetchClassesForUnit() {
            try {
                this.normalizeBaseUrl();
                const r = await fetch(this.baseUrl + 'api/get_academic_data.php?unit=' + encodeURIComponent(this.currentUnit));
                const j = await r.json();
                const arr = Array.isArray(j.classes) ? j.classes : [];
                this.classesOptions = arr.map(c => ({ id: c.id, name: c.name }));
                const key = 'waliSelectedClassId_' + this.currentUnit;
                const saved = localStorage.getItem(key) || '';
                if (saved) {
                    this.selectedClassId = saved;
                    this.applySelectedClass();
                }
            } catch (_) {
                this.classesOptions = [];
            }
        },
        async applySelectedClass() {
            const id = this.selectedClassId;
            if (!id) {
                this.homeroomClassId = null;
                this.className = '';
                this.classStudents = [];
                this.classAttendanceSummary = [];
                return;
            }
            const found = this.classesOptions.find(c => String(c.id) === String(id));
            this.homeroomClassId = parseInt(id, 10);
            this.className = found ? (found.name || '') : '';
            localStorage.setItem('waliSelectedClassId_' + this.currentUnit, String(id));
            this.fetchDailyAttendance();
            this.fetchMonthlyData();
            await this.fetchClassAttendanceSummary();
            this.fetchPendingIssues();
            this.fetchClassSchedule();
            this.fetchBkSchedule();
            this.fetchBkProfile();
            this.fetchBkArticles();
            this.generateAcademicMonths(); // Update on class change
        },
        getScheduleItem(dayLabel, timeHHMM) {
            const day = String(dayLabel || '').toUpperCase();
            const t = String(timeHHMM || '');
            const m = this.classScheduleMap || {};
            if (!m[day]) return null;
            const row = m[day][t] || null;
            return row || null;
        },
        async fetchClassSchedule() {
            if (!this.homeroomClassId) { this.classScheduleMap = {}; return; }
            try {
                this.normalizeBaseUrl();
                const r = await fetch(this.baseUrl + 'api/get_schedule.php?class_id=' + encodeURIComponent(this.homeroomClassId));
                const j = await r.json();
                // j is grouped: { SENIN: { '07:00': {...} }, ... }
                const map = (j && typeof j === 'object') ? j : {};
                // Normalize time keys to HH:MM
                const out = {};
                const days = ['SENIN','SELASA','RABU','KAMIS','JUMAT'];
                days.forEach(d => { out[d] = {}; });
                Object.keys(map).forEach(d => {
                    const dd = String(d || '').toUpperCase();
                    const slots = map[d] || {};
                    Object.keys(slots).forEach(k => {
                        const hhmm = String(k || '').slice(0,5);
                        out[dd][hhmm] = slots[k];
                    });
                });
                this.classScheduleMap = out;
            } catch (_) {
                this.classScheduleMap = {};
            }
        },
        async fetchBkSchedule() {
            if (!this.homeroomClassId) { this.bkSchedule = []; return; }
            try {
                this.normalizeBaseUrl();
                const r = await fetch(this.baseUrl + 'api/counseling.php?action=list_bk_schedule&class_id=' + encodeURIComponent(this.homeroomClassId));
                const j = await r.json();
                this.bkSchedule = j && j.success ? (j.data || []) : [];
            } catch (_) {
                this.bkSchedule = [];
            }
        },
        async fetchDailyAttendance() {
            if (!this.homeroomClassId) return;
            try {
                this.normalizeBaseUrl();
                const url = this.baseUrl + 'api/attendance.php?action=get_daily_attendance&class_id=' + encodeURIComponent(this.homeroomClassId) + '&date=' + encodeURIComponent(this.dailyDate);
                const r = await fetch(url);
                const j = await r.json();
                const rows = j && j.success ? (j.data || []) : [];
                this.attendanceSubmitted = rows.length > 0 && rows.some(r => r.status != null);
                this.classStudents = rows.map(s => {
                    const st = String(s.status || 'HADIR').toUpperCase();
                    const map = { 'HADIR': 'Hadir', 'IZIN': 'Izin', 'SAKIT': 'Sakit', 'ALFA': 'Alfa', 'CUTI': 'Cuti' };
                    return { 
                        id: s.id, 
                        name: s.name, 
                        nis: s.nis, 
                        gender: s.gender, 
                        birth_place: s.birth_place, 
                        birth_date: s.birth_date, 
                        status: map[st] || 'Hadir' 
                    };
                });
                await this.fetchMonthlyData();
            } catch (_) {
                this.classStudents = [];
            }
        },
        async fetchMonthlyData() {
            if (!this.homeroomClassId) return;
            try {
                this.normalizeBaseUrl();
                const qs = `class_id=${encodeURIComponent(this.homeroomClassId)}&month=${encodeURIComponent(this.monthlyMonth)}&year=${encodeURIComponent(this.monthlyYear)}`;
                const r1 = await fetch(this.baseUrl + 'api/attendance.php?action=get_class_attendance_month&' + qs);
                const j1 = await r1.json();
                this.monthlySource = j1 && j1.success && j1.data && j1.data.source ? j1.data.source : '-';
                
                const r2 = await fetch(this.baseUrl + 'api/attendance.php?action=get_daily_calendar&' + qs);
                const j2 = await r2.json();
                const rawCalendar = j2 && j2.success ? (j2.data || []) : [];
                
                // Generate full calendar
                const year = parseInt(this.monthlyYear);
                const month = parseInt(this.monthlyMonth);
                const daysInMonth = new Date(year, month, 0).getDate();
                
                // Calculate spacers for Monday start
                const firstDayOfWeek = new Date(year, month - 1, 1).getDay(); // 0=Sun, 1=Mon...
                const spacerCount = (firstDayOfWeek + 6) % 7;
                
                const fullCalendar = [];
                // Add spacers
                for (let i = 0; i < spacerCount; i++) {
                    fullCalendar.push({ date: null });
                }

                for (let d = 1; d <= daysInMonth; d++) {
                    const dateStr = `${year}-${String(month).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
                    const found = rawCalendar.find(x => x.date === dateStr);
                    if (found) {
                        fullCalendar.push(found);
                    } else {
                        // Mark as pending/not validated
                        fullCalendar.push({
                            date: dateStr,
                            hadir: 0, izin: 0, sakit: 0, alfa: 0, cuti: 0,
                            present_pct: -1 // Special value for pending
                        });
                    }
                }
                this.monthlyCalendar = fullCalendar;

                const r3 = await fetch(this.baseUrl + 'api/attendance.php?action=get_month_student_attendance&' + qs);
                const j3 = await r3.json();
                this.monthlyStudentRows = j3 && j3.success ? (j3.data || []) : [];
                const scored = this.monthlyStudentRows.map(s => ({ ...s, score: (s.alfa + s.izin + s.sakit) }));
                scored.sort((a,b) => b.score - a.score);
                this.topAbsentees = scored.slice(0, 5);
            } catch (_) {
                this.monthlySource = '-';
                this.monthlyCalendar = [];
                this.monthlyStudentRows = [];
                this.topAbsentees = [];
            }
        },
        calendarBarClass(pct) {
            if (pct === -1) return 'bg-red-500'; // Pending/Not Validated
            if (pct >= 90) return 'bg-emerald-600';
            if (pct >= 75) return 'bg-amber-500';
            return 'bg-rose-700'; // Bad attendance
        },
        exportMonthlyCsv() {
            const rows = this.monthlyStudentRows || [];
            const header = ['Nama','NIS','Hadir','Izin','Sakit','Alfa','Cuti','Hari Aktif'];
            const lines = [header.join(',')].concat(rows.map(r => [r.name, r.nis || '', r.hadir, r.izin, r.sakit, r.alfa, r.cuti, r.active_days].join(',')));
            const blob = new Blob([lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `rekap_${this.className || 'kelas'}_${this.monthlyMonth}_${this.monthlyYear}.csv`;
            a.click();
            setTimeout(() => URL.revokeObjectURL(url), 2000);
        },
        openDailyVerify() {
            if (!this.homeroomClassId) { alert('Kelas wali tidak ditemukan.'); return; }
            this.dailyVerifyModal = true;
        },
        async saveDailyBatch() {
            try {
                if (!this.homeroomClassId) return;
                const recs = this.classStudents.map(s => {
                    const up = String(s.status || 'Hadir').toUpperCase();
                    const map = { 'HADIR':'HADIR','IZIN':'IZIN','SAKIT':'SAKIT','ALFA':'ALFA','CUTI':'CUTI' };
                    return { id: s.id, status: map[up] || 'HADIR', note: '', request_id: String(Date.now()) + '-' + s.id };
                });
                const payload = { class_id: this.homeroomClassId, date: this.dailyDate, records: recs };
                const r = await fetch(this.baseUrl + 'api/attendance.php?action=save_attendance_daily_batch', { method: 'POST', body: JSON.stringify(payload) });
                const j = await r.json();
                if (j && j.success) {
                    this.dailyVerifyModal = false;
                    await this.fetchDailyAttendance();
                    await this.fetchMonthlyData();
                    alert('Presensi harian tersimpan.');
                } else {
                    alert('Gagal menyimpan presensi.');
                }
            } catch (_) { alert('Gagal menyimpan presensi.'); }
        },
        async rollupMonthlyFromDaily() {
            try {
                if (!this.homeroomClassId) { alert('Kelas wali tidak ditemukan.'); return; }
                const d = new Date(this.dailyDate);
                const m = d.getMonth() + 1;
                const y = d.getFullYear();
                const form = new URLSearchParams();
                form.set('class_id', String(this.homeroomClassId));
                form.set('month', String(m));
                form.set('year', String(y));
                const r = await fetch(this.baseUrl + 'api/attendance.php?action=rollup_daily_to_monthly', { method: 'POST', body: form });
                const j = await r.json();
                if (j && j.success) {
                    alert('Rekap bulanan digenerate dari harian.');
                } else {
                    alert('Gagal generate rekap bulanan.');
                }
            } catch (_) { alert('Gagal generate rekap bulanan.'); }
        },
        openPortfolio(s) {
            this.portfolioStudent = { academic_avg: 86, academic_top_subject: 'Matematika', library_loans: 2, library_late: 0, bk_points: 3, bk_active_cases: 0 };
            this.studentPortfolioModal = true;
        },
        deleteTeacherNote(idx) {
            if (idx < 0 || idx >= this.teacherNotes.length) return;
            this.teacherNotes.splice(idx, 1);
        },
        addTeacherNote() {
            const t = (this.teacherNoteInput || '').trim();
            if (!t) return;
            this.teacherNotes.push({ id: Date.now(), text: t, ts: Date.now() });
            this.teacherNoteInput = '';
        },
        truncateName(name) {
            const n = String(name || '').trim();
            if (!n) return '';
            const words = n.split(/\s+/);
            const cut = words.slice(0, 3).join(' ');
            if (words.length > 3) return cut + '…';
            if (cut.length > 26) return cut.slice(0, 26) + '…';
            return cut;
        },
        openResolveModal(issue) {
            this.resolveIncident = issue;
            this.resolveNote = '';
            this.resolveModal = true;
        },
        async submitResolveInternal() {
            try {
                if (!this.resolveIncident) return;
                this.normalizeBaseUrl();
                const r = await fetch(this.baseUrl + 'api/student_incidents.php?action=resolve_internal', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id: this.resolveIncident.id, note: this.resolveNote })
                });
                const j = await r.json();
                if (j && j.success) {
                    this.resolveModal = false;
                    await this.fetchPendingIssues();
                    alert('Isu ditandai selesai dengan peringatan.');
                } else {
                    alert('Gagal menyelesaikan: ' + ((j && (j.error || j.message)) || ''));
                }
            } catch (_) {
                alert('Kesalahan saat menyelesaikan.');
            }
        },
        openEscalateModal(issue) {
            this.escalateIncident = issue;
            this.escalateNote = '';
            this.escalateModal = true;
        },
        async submitEscalateBK() {
            try {
                if (!this.escalateIncident) return;
                this.normalizeBaseUrl();
                const r = await fetch(this.baseUrl + 'api/student_incidents.php?action=escalate_to_bk', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id: this.escalateIncident.id, intro_note: this.escalateNote })
                });
                const j = await r.json();
                if (j && j.success) {
                    this.escalateModal = false;
                    await this.fetchPendingIssues();
                    alert('Isu dieskalasi ke BK dengan catatan pengantar.');
                } else {
                    alert('Gagal eskalasi: ' + ((j && (j.error || j.message)) || ''));
                }
            } catch (_) {
                alert('Kesalahan saat eskalasi.');
            }
        },
        async fetchPendingIssues() {
            try {
                if (this.currentPosition !== 'wali') { this.pendingIssues = []; return; }
                this.normalizeBaseUrl();
                let url = this.baseUrl + 'api/student_incidents.php?action=list_pending_for_homeroom';
                if (!this.homeroomClassId && this.selectedClassId) {
                    url = this.baseUrl + 'api/student_incidents.php?action=list_pending_for_class&class_id=' + encodeURIComponent(this.selectedClassId);
                }
                const r = await fetch(url);
                const j = await r.json();
                this.pendingIssues = j && j.success ? (j.data || []) : [];
            } catch (_) {
                this.pendingIssues = [];
            }
        },
        openInventoryModal(asset) {
            this.inventorySelected = asset;
            this.inventoryReportCount = 1;
            this.inventoryReportDesc = '';
            this.inventoryReportPhotoName = '';
            this.inventoryModal = true;
        },
        submitInventoryReport() {
            if (!this.inventorySelected) return;
            const item = this.inventorySelected.name;
            const count = this.inventoryReportCount || 1;
            this.maintenanceTickets.push({ id: 'MT-' + Date.now(), item, count, status: 'Pending', date: new Date().toISOString() });
            this.inventoryModal = false;
            alert('Tiket maintenance dibuat (dummy).');
        },
        submitMonthlyRecap() {
            // Validate specific month
            if (this.monthlyRecapSelected) {
                const m = this.monthlyRecaps.find(x => x.id === this.monthlyRecapSelected.id);
                if (m) {
                    m.status = 'validated';
                    m.validated_at = new Date().toISOString();
                }
                this.monthlyRecapSelected = null;
                // Check if current month is validated to update the card status
                const currentMonthIdx = new Date().getMonth(); // 0-11
                const currentMonthId = 'm' + (currentMonthIdx + 1);
                // Simple logic: if the current month is validated, mark card as submitted
                const curr = this.monthlyRecaps.find(x => x.id === currentMonthId);
                if (curr && curr.status === 'validated') {
                    this.monthlyRecapSubmitted = true;
                }
                alert('Rekap presensi bulan ' + m.name + ' berhasil divalidasi.');
            } else {
                this.monthlyRecapSubmitted = true;
                this.monthlyRecapModal = false;
                alert('Rekap presensi bulanan berhasil divalidasi.');
            }
        },
        generateAcademicMonths() {
            // Generate July - June
            const now = new Date();
            const currentMonth = now.getMonth() + 1; // 1-12
            const currentYear = now.getFullYear();
            
            // Determine academic year start
            let startYear = currentYear;
            if (currentMonth < 7) {
                startYear = currentYear - 1;
            }
            
            const months = [
                { id: 'm7', val: 7, name: 'Juli', year: startYear },
                { id: 'm8', val: 8, name: 'Agustus', year: startYear },
                { id: 'm9', val: 9, name: 'September', year: startYear },
                { id: 'm10', val: 10, name: 'Oktober', year: startYear },
                { id: 'm11', val: 11, name: 'November', year: startYear },
                { id: 'm12', val: 12, name: 'Desember', year: startYear },
                { id: 'm1', val: 1, name: 'Januari', year: startYear + 1 },
                { id: 'm2', val: 2, name: 'Februari', year: startYear + 1 },
                { id: 'm3', val: 3, name: 'Maret', year: startYear + 1 },
                { id: 'm4', val: 4, name: 'April', year: startYear + 1 },
                { id: 'm5', val: 5, name: 'Mei', year: startYear + 1 },
                { id: 'm6', val: 6, name: 'Juni', year: startYear + 1 }
            ];

            // Set status based on summary and current date
            this.monthlyRecaps = months.map(m => {
                let status = 'future';
                
                // Check if validated in DB (exists in summary)
                const exists = this.classAttendanceSummary.find(x => x.month == m.val && x.year == m.year);
                
                if (exists) {
                    status = 'validated';
                } else {
                    // Check if past or current
                    const mDate = new Date(m.year, m.val - 1, 1);
                    const nowDate = new Date(currentYear, currentMonth - 1, 1);
                    
                    if (mDate <= nowDate) {
                        status = 'pending';
                    }
                }
                
                return {
                    ...m,
                    status: status, // validated, pending, future
                    validated_at: status === 'validated' ? new Date().toISOString() : null
                };
            });
            
            // Initial check for card status (based on current month)
            const currRecap = this.monthlyRecaps.find(x => x.val === currentMonth);
            this.monthlyRecapSubmitted = currRecap ? currRecap.status === 'validated' : false;
        },
        saveWaliTasks() {
            try {
                const payload = { d: this.tasksDaily, w: this.tasksWeekly, m: this.tasksMonthly };
                localStorage.setItem('wali_tasks', JSON.stringify(payload));
            } catch(_) {}
        },
        getWaitingHours(a) {
            const created = a.created_at ? new Date(a.created_at).getTime() : null;
            if (!created) return 0;
            const diffMs = Date.now() - created;
            return Math.max(0, Math.floor(diffMs / (1000 * 60 * 60)));
        },
        getWaitingBarWidth(a) {
            const h = this.getWaitingHours(a);
            const pct = Math.min(100, Math.floor((h / 72) * 100));
            return pct + '%';
        },
        getWaitingText(a) {
            const h = this.getWaitingHours(a);
            if (h < 24) return h + ' jam';
            const d = Math.floor(h / 24);
            const rem = h % 24;
            if (rem === 0) return d + ' hari';
            return d + ' hari ' + rem + ' jam';
        },
        unitClass(code) {
            return this.currentUnit === code ? 'bg-white text-slate-800 shadow ring-1 ring-slate-200' : 'text-slate-600';
        },
        waliTabClass(code) {
            return this.homeroomTab === code ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300';
        },
        bkTabClass(code) {
            return this.bkTab === code ? 'bg-pink-600 text-white' : 'bg-slate-100 text-slate-700';
        },
        formatDate(s) {
            const d = new Date(s);
            return d.toLocaleDateString('id-ID', { day: 'numeric', month: 'short' });
        },
        activityButtonClass(code) {
            return this.activeActivityTab === code ? 'bg-slate-800 text-white ring-1 ring-slate-200' : 'bg-slate-100 text-slate-600';
        },
        setActivityTab(code) {
            this.activeActivityTab = code;
            this.fetchActivity(code);
        },
        boardingGenderClass(code) {
            return this.boardingGender === code ? 'bg-amber-600 text-white' : 'bg-white text-amber-600';
        },
        async setBoardingGender(code) {
            this.boardingGender = code;
            if (this.currentUnit === 'asrama') {
                await this.fetchBoardingCount();
            }
        },
        async fetchAttendance() {
            try {
                this.attendanceSummary = { present: 0, permit: 0, absent: 0 };
            } catch (_) {}
        },
        async fetchStats() {
            try {
                const unit = this.currentUnit;
                // Classes & student_count per class
                const r1 = await fetch(this.baseUrl + 'api/get_academic_data.php?unit=' + encodeURIComponent(unit));
                const j1 = await r1.json();
                const classes = Array.isArray(j1.classes) ? j1.classes : [];
                this.classCount = classes.length;
                this.studentCount = classes.reduce((acc, c) => acc + (parseInt(c.student_count || 0, 10) || 0), 0);
                this.academicSlots = Array.isArray(j1.timeSlots) ? j1.timeSlots : [];
                // Teachers
                const r2 = await fetch(this.baseUrl + 'api/get_unit_teachers.php?unit=' + encodeURIComponent(unit) + '&type=ACADEMIC');
                const j2 = await r2.json();
                this.teacherCount = Array.isArray(j2) ? j2.length : (Array.isArray(j2.data) ? j2.data.length : 0);
            } catch (_) {
                this.studentCount = 0;
                this.classCount = 0;
                this.teacherCount = 0;
                this.academicSlots = [];
            }
        },
        normalizeBaseUrl() {
            if (this.baseUrl === '/' || !this.baseUrl) {
                const m = (window.location.pathname || '').match(/^\/(AIS|AIStest)\//i);
                this.baseUrl = m ? `/${m[1]}/` : '/';
            }
        },
        async fetchActivity(category) {
            try {
                const r = await fetch(this.baseUrl + 'api/get_activity_logs.php?module=' + encodeURIComponent(this.moduleCode) + '&category=' + encodeURIComponent(category) + '&limit=20');
                const j = await r.json();
                this.activities[category] = j.success ? (j.data || []) : [];
            } catch (_) {
                this.activities[category] = [];
            }
        },
        async refreshActivities() {
            await this.fetchActivity('PRESENSI');
            await this.fetchActivity('RAPAT');
            await this.fetchActivity('KEGIATAN');
        },
        async fetchAcademicAgenda() {
            try {
                const unit = this.currentUnit;
                const r = await fetch(this.baseUrl + 'api/get_academic_data.php?unit=' + encodeURIComponent(unit));
                const j = await r.json();
                this.academicSlots = Array.isArray(j.timeSlots) ? j.timeSlots : [];
            } catch (_) {
                this.academicSlots = [];
            }
        },
        async fetchBkProfile() {
            try {
                this.normalizeBaseUrl();
                const r = await fetch(this.baseUrl + 'api/counseling.php?action=get_bk_unit_profile');
                const j = await r.json();
                this.bkProfile = j.success ? (j.data || { profile:{}, team:[] }) : { profile:{}, team:[] };
            } catch(_) { this.bkProfile = { profile:{}, team:[] }; }
        },
        async fetchBkArticles() {
            try {
                this.normalizeBaseUrl();
                const r = await fetch(this.baseUrl + 'api/counseling.php?action=list_psychoedu');
                const j = await r.json();
                this.bkArticles = j.success ? (j.data || []) : [];
            } catch(_) { this.bkArticles = []; }
        },
        async fetchCounselingSummary() {
            try {
                const unit = this.currentUnit;
                const r = await fetch(this.baseUrl + 'api/counseling.php?action=get_unit_summary&unit=' + encodeURIComponent(unit));
                const j = await r.json();
                this.counselingSummary = j.success ? (j.data || { achievements_recent: 0, cases_recent: 0, counseling_sessions_recent: 0 }) : { achievements_recent: 0, cases_recent: 0, counseling_sessions_recent: 0 };
            } catch (_) {
                this.counselingSummary = { achievements_recent: 0, cases_recent: 0, counseling_sessions_recent: 0 };
            }
        },
        async fetchBoardingCount() {
            try {
                const r = await fetch(this.baseUrl + 'api/boarding.php?action=get_students&gender=' + encodeURIComponent(this.boardingGender));
                const j = await r.json();
                if (j && typeof j === 'object') {
                    if (Array.isArray(j.data)) this.boardingCount = j.data.length;
                    else if (Array.isArray(j)) this.boardingCount = j.length;
                    else if (j.debug && typeof j.debug.count === 'number') this.boardingCount = j.debug.count;
                    else this.boardingCount = 0;
                } else {
                    this.boardingCount = 0;
                }
            } catch (_) {
                this.boardingCount = 0;
            }
        },
        async fetchMeetings() {
            try {
                this.normalizeBaseUrl();
                const res = await fetch(this.baseUrl + 'api/meetings.php?action=list&module=BOARDING&limit=12');
                const data = await res.json();
                this.meetings = data && data.success ? (data.data || []) : [];
                const now = Date.now();
                this.recentMeetingCount = this.meetings.filter(m => {
                    const d = m.meeting_date ? new Date(m.meeting_date).getTime() : 0;
                    return d && (now - d) < (7 * 24 * 60 * 60 * 1000);
                }).length;
            } catch (_) {
                this.meetings = [];
                this.recentMeetingCount = 0;
            }
        },
        async fetchBoardingStudents() {
            try {
                const r = await fetch(this.baseUrl + 'api/boarding.php?action=get_students&gender=all');
                const j = await r.json();
                this.boardingStudents = Array.isArray(j.data) ? j.data : (Array.isArray(j) ? j : []);
            } catch (_) {
                this.boardingStudents = [];
            }
        },
        async fetchApprovals() {
            try {
                this.normalizeBaseUrl();
                const res = await fetch(this.baseUrl + 'api/approval.php?action=get_list&status=ALL');
                const data = await res.json();
                const rows = data && data.success ? (Array.isArray(data.data) ? data.data : []) : [];
                this.approvals = rows.filter(a => String(a.module || '').toUpperCase() === 'BOARDING').slice(0, 12);
            } catch (_) {
                this.approvals = [];
            }
        },
        async fetchDocuments() {
            try {
                this.normalizeBaseUrl();
                const res = await fetch(this.baseUrl + 'api/meetings.php?action=list_documents&module=BOARDING&limit=30');
                const data = await res.json();
                this.documents = data && data.success ? (data.data || []) : [];
            } catch (_) {
                this.documents = [];
            }
        },
        async fetchZeroTodayReports() {
            try {
                this.normalizeBaseUrl();
                const res = await fetch(this.baseUrl + 'api/zero_report.php?action=list_today');
                const data = await res.json();
                this.zeroTodayReports = data && data.success ? (data.data || []) : [];
                if (!data.success || this.zeroTodayReports.length === 0) {
                    const now = Date.now();
                    this.zeroTodayReports = [
                        { name: 'Musyrif Blok A', status: 'SAFE', incident_count: 0, created_at: new Date(now - 5 * 60 * 1000).toISOString() },
                        { name: 'Musyrif Blok B', status: 'INCIDENT', incident_count: 1, created_at: new Date(now - 10 * 60 * 1000).toISOString() },
                        { name: 'Musyrif Blok C', status: 'PENDING', incident_count: 0, created_at: new Date(now).toISOString() }
                    ];
                }
                const safe = this.zeroTodayReports.filter(r => String(r.status || '').toUpperCase() === 'SAFE').length;
                const incident = this.zeroTodayReports.filter(r => String(r.status || '').toUpperCase() === 'INCIDENT').length;
                const pendingRows = this.zeroTodayReports.filter(r => String(r.status || '').toUpperCase() === 'PENDING').length;
                const totalMusyrif = this.musyrifCount || 0;
                const pending = pendingRows > 0 ? pendingRows : Math.max(0, totalMusyrif - (safe + incident));
                this.zeroCounts = { safe, incident, pending };
                if (this.zeroTodayReports.length > 0) {
                    const sorted = [...this.zeroTodayReports].sort((a,b) => new Date(a.created_at) - new Date(b.created_at));
                    const top = sorted[0];
                    this.topResponder = { name: top.name || null, time: new Date(top.created_at).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }) };
                } else {
                    this.topResponder = { name: null, time: null };
                }
                this.updateZeroUrgency();
            } catch (_) {
                this.zeroTodayReports = [];
                this.zeroCounts = { safe: 0, incident: 0, pending: 0 };
                this.topResponder = { name: null, time: null };
            }
        },
        async fetchZeroSummary() {
            try {
                this.normalizeBaseUrl();
                const res = await fetch(this.baseUrl + 'api/zero_report.php?action=summary');
                const data = await res.json();
                if (data.success && data.data) {
                    this.weeklyMonthlyZero = {
                        weekly: data.data.weekly || { safe: 0, incident: 0 },
                        monthly: data.data.monthly || { safe: 0, incident: 0 }
                    };
                } else {
                    this.weeklyMonthlyZero = { weekly: { safe: 0, incident: 0 }, monthly: { safe: 0, incident: 0 } };
                }
            } catch (_) {
                this.weeklyMonthlyZero = { weekly: { safe: 0, incident: 0 }, monthly: { safe: 0, incident: 0 } };
            }
        },
        updateZeroUrgency() {
            const now = new Date();
            const start = new Date();
            const end = new Date();
            start.setHours(21, 0, 0, 0);
            end.setHours(22, 0, 0, 0);
            const pending = this.zeroCounts.pending || 0;
            if (now < start) {
                this.zeroUrgencyText = 'Menunggu jam laporan';
                this.zeroUrgencyClass = '';
                return;
            }
            if (now >= start && now <= end) {
                if (pending > 0) {
                    this.zeroUrgencyText = 'Jam laporan aktif, masih ada yang belum lapor';
                    this.zeroUrgencyClass = 'animate-pulse bg-red-50/60';
                } else {
                    this.zeroUrgencyText = 'Semua blok sudah lapor';
                    this.zeroUrgencyClass = 'bg-emerald-50/40';
                }
                return;
            }
            if (now > end) {
                if (pending > 0) {
                    this.zeroUrgencyText = 'Lewat jam 21:00, masih ada yang belum lapor';
                    this.zeroUrgencyClass = 'animate-pulse bg-red-100/70';
                } else {
                    this.zeroUrgencyText = 'Lewat jam laporan, semua blok sudah aman';
                    this.zeroUrgencyClass = 'bg-emerald-50/40';
                }
            }
        },
        loadTasks() {
            try {
                const raw = localStorage.getItem('boarding_tasks');
                const arr = JSON.parse(raw || '[]');
                this.tasks = Array.isArray(arr) ? arr : [];
            } catch(_) { this.tasks = []; }
        },
        saveTasks() {
            try {
                localStorage.setItem('boarding_tasks', JSON.stringify(this.tasks));
            } catch(_) {}
        },
        loadChatMessages() {
            try {
                const raw = localStorage.getItem('boarding_chat_messages');
                const arr = JSON.parse(raw || '[]');
                this.chatMessages = Array.isArray(arr) ? arr : [];
            } catch(_) { this.chatMessages = []; }
        },
        saveChatMessages() {
            try {
                localStorage.setItem('boarding_chat_messages', JSON.stringify(this.chatMessages));
            } catch(_) {}
        },
        sendChat() {
            const t = (this.chatInput || '').trim();
            if (!t) return;
            this.chatMessages.push({ id: Date.now(), text: t, ts: Date.now() });
            this.chatInput = '';
            this.saveChatMessages();
        },
        nudgeMusyrif(name) {
            const msg = `Pengingat: Mohon segera lakukan Zero Report - ${name}`;
            this.chatMessages.push({ id: Date.now(), text: msg, ts: Date.now() });
            this.saveChatMessages();
            alert('Notifikasi terkirim (dummy) ke ' + name);
        },
        deleteChatMessage(idx) {
            if (idx < 0 || idx >= this.chatMessages.length) return;
            this.chatMessages.splice(idx, 1);
            this.saveChatMessages();
        },
        formatChatTime(ts) {
            const d = new Date(ts);
            return d.toLocaleString('id-ID', { hour: '2-digit', minute: '2-digit', day: 'numeric', month: 'short' });
        },
        async fetchPermissions() {
            try {
                const r = await fetch(this.baseUrl + 'api/boarding_permissions.php?action=get_permissions');
                const j = await r.json();
                const rows = j.success ? (j.data || []) : [];
                const now = new Date();
                this.permissionsActive = rows.filter(x => {
                    const s = x.start_date ? new Date(x.start_date) : null;
                    const e = x.end_date ? new Date(x.end_date) : null;
                    const activeRange = s && e ? (now >= s && now <= e) : (e ? now <= e : true);
                    const statusOk = ['APPROVED','PENDING'].includes((x.status || '').toUpperCase());
                    return statusOk && activeRange;
                });
            } catch (_) {
                this.permissionsActive = [];
            }
        },
        async fetchDiscipline(type) {
            try {
                const r = await fetch(this.baseUrl + 'api/boarding_discipline.php?action=get_records&type=' + encodeURIComponent(type));
                const j = await r.json();
                const rows = j.success ? (j.data || []) : [];
                if (type === 'ACHIEVEMENT') this.achievementsRecent = rows;
                else this.violationsRecent = rows;
            } catch (_) {
                if (type === 'ACHIEVEMENT') this.achievementsRecent = [];
                else this.violationsRecent = [];
            }
        },
        async fetchRooms() {
            try {
                const r = await fetch(this.baseUrl + 'api/boarding_rooms.php?action=get_rooms');
                const j = await r.json();
                const rows = j.success ? (j.data || []) : [];
                this.roomsTop = rows.sort((a,b) => (parseInt(b.occupants_count||0,10)) - (parseInt(a.occupants_count||0,10)));
            } catch (_) {
                this.roomsTop = [];
            }
        },
        async fetchHalaqoh() {
            try {
                const r = await fetch(this.baseUrl + 'api/boarding_halaqoh.php?action=get_halaqoh');
                const j = await r.json();
                const list = j.success ? (j.data || []) : [];
                const map = {};
                for (const s of this.boardingStudents) {
                    const hid = s.halaqoh_id || null;
                    if (!hid) continue;
                    const key = String(hid);
                    map[key] = (map[key] || 0) + 1;
                }
                const merged = list.map(h => {
                    const key = String(h.id);
                    const count = map[key] || 0;
                    return { id: h.id, name: h.name, ustadz_name: h.ustadz_name, count };
                });
                this.halaqohTop = merged.sort((a,b) => b.count - a.count);
            } catch (_) {
                this.halaqohTop = [];
            }
        },
        computeMusyrif() {
            const map = {};
            for (const s of this.boardingStudents) {
                const mid = s.musyrif_id || null;
                const name = s.musyrif_name || null;
                if (!mid && !name) continue;
                const key = String(mid || name);
                if (!map[key]) map[key] = { id: mid || null, name: name || 'Musyrif', count: 0 };
                map[key].count += 1;
            }
            const arr = Object.values(map).sort((a,b) => b.count - a.count);
            this.musyrifList = arr;
            this.musyrifCount = arr.length;
        },
        async fetchAsramaStats() {
            await this.fetchBoardingStudents();
            await this.fetchPermissions();
            await this.fetchDiscipline('ACHIEVEMENT');
            await this.fetchDiscipline('VIOLATION');
            await this.fetchRooms();
            await this.fetchHalaqoh();
            this.computeMusyrif();
        },
        clearAsramaStats() {
            this.permissionsActive = [];
            this.achievementsRecent = [];
            this.violationsRecent = [];
            this.roomsTop = [];
            this.halaqohTop = [];
            this.musyrifCount = 0;
            this.musyrifList = [];
            this.boardingStudents = [];
        },

        async checkLockStatus() {
            if (this.currentPosition !== 'wali') return;
            const classId = this.selectedClassId || this.homeroomClassId;
            if (!classId) return;
            
            try {
                this.normalizeBaseUrl();
                const r = await fetch(`${this.baseUrl}api/lock_check.php?action=check_status&class_id=${classId}`);
                const j = await r.json();
                if (j.success) {
                    this.lockStatus = j;
                }
            } catch (e) { console.error(e); }
        },
        async fetchUnitLocks() {
            if (this.currentPosition !== 'kepala') return;
            try {
                this.normalizeBaseUrl();
                const r = await fetch(`${this.baseUrl}api/lock_check.php?action=get_unit_locks&unit=${this.currentUnit}`);
                const j = await r.json();
                if (j.success) {
                    this.unitLocks = j.data;
                }
            } catch (e) { console.error(e); }
        },
        openUnlockModal(c) {
            this.selectedLockClass = c;
            this.unlockReason = '';
            this.unlockDuration = 24;
            this.unlockType = 'ALL';
            this.showUnlockModal = true;
        },
        async submitUnlock() {
            if (!this.selectedLockClass) return;
            try {
                this.normalizeBaseUrl();
                const r = await fetch(`${this.baseUrl}api/lock_check.php?action=unlock`, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({
                        class_id: this.selectedLockClass.id,
                        lock_type: this.unlockType,
                        hours: this.unlockDuration,
                        reason: this.unlockReason
                    })
                });
                const j = await r.json();
                if (j.success) {
                    alert('Berhasil membuka kunci!');
                    this.showUnlockModal = false;
                    this.fetchUnitLocks();
                } else {
                    alert('Gagal: ' + j.message);
                }
            } catch (e) { alert('Error: ' + e.message); }
        },
        async fetchUnitStats() {
            if (this.currentPosition !== 'kepala') return;
            try {
                this.normalizeBaseUrl();
                // Ensure locks are loaded first for mapping
                await this.fetchUnitLocks();
                
                const unit = this.currentUnit;
                
                // 1. Get Main Academic Data (Classes, Student Counts, Teachers)
                const rMain = await fetch(`${this.baseUrl}api/get_academic_data.php?unit=${encodeURIComponent(unit)}`);
                const jMain = await rMain.json();
                const mainClasses = (jMain.classes && Array.isArray(jMain.classes)) ? jMain.classes : [];
                
                // 2. Get Monthly Attendance Summary
                const pMonth = this.principalMonth;
                const pYear = this.principalYear;
                const rMonthly = await fetch(`${this.baseUrl}api/attendance.php?action=get_attendance_summary&unit=${encodeURIComponent(unit)}&month=${pMonth}&year=${pYear}`);
                const jMonthly = await rMonthly.json();
                const monthlyStats = (jMonthly.success && Array.isArray(jMonthly.data)) ? jMonthly.data : [];
                
                // 3. Get Daily Attendance Status
                const pDate = this.principalDailyDate;
                const rDaily = await fetch(`${this.baseUrl}api/attendance.php?action=get_unit_daily_status&unit=${encodeURIComponent(unit)}&date=${pDate}`);
                const jDaily = await rDaily.json();
                const dailyStats = (jDaily.success && Array.isArray(jDaily.data)) ? jDaily.data : [];
                
                // 4. Get BK Stats
                const rBk = await fetch(`${this.baseUrl}api/counseling.php?action=ticket_stats`);
                const jBk = await rBk.json();
                const bkStats = (jBk.success && jBk.data && jBk.data.counts) ? jBk.data.counts : {};

                // Aggregate Data
                this.unitStats.classCount = mainClasses.length;
                this.unitStats.studentCount = mainClasses.reduce((acc, c) => acc + (parseInt(c.student_count)||0), 0);
                
                const teacherSet = new Set();
                mainClasses.forEach(c => {
                    if (c.homeroom_teacher_id) teacherSet.add(c.homeroom_teacher_id);
                });
                this.unitStats.teacherCount = teacherSet.size;
                
                this.unitStats.bkHigh = parseInt(bkStats['HIGH']||0);
                this.unitStats.bkMedium = parseInt(bkStats['MEDIUM']||0);
                
                // Map classes with status
                this.unitStats.classes = mainClasses.map(c => {
                    const mData = monthlyStats.find(m => String(m.class_id) === String(c.id) && String(m.month) == String(pMonth) && String(m.year) == String(pYear));
                    const dData = dailyStats.find(d => String(d.id) === String(c.id));
                    
                    // Check lock status from unitLocks
                    const lockedClass = this.unitLocks.find(l => String(l.id) === String(c.id));
                    
                    // Dummy inventory logic (random for now as requested)
                    const invStatus = (c.id % 3 === 0) ? 'Reported' : 'Pending'; 

                    return {
                        id: c.id,
                        name: c.name,
                        male: parseInt(c.male_count)||0,
                        female: parseInt(c.female_count)||0,
                        dailyStatus: dData ? dData.status : 'Pending',
                        monthlyStatus: mData ? 'Validated' : 'Pending',
                        inventoryStatus: invStatus,
                        isLocked: !!lockedClass,
                        lockDetails: lockedClass ? lockedClass.locks : []
                    };
                });

            } catch (e) {
                console.error('Error fetching unit stats:', e);
            }
        },
        async handleWindowFocus() {
            if (this.currentPosition === 'wali' && this.homeroomClassId) {
                await this.fetchClassAttendanceSummary();
                this.generateAcademicMonths();
            }
        }
    },
    mounted() {
        // Auto-refresh on window focus
        window.addEventListener('focus', this.handleWindowFocus);

        if (this.currentUnit === 'asrama') {
            this.activeTab = 'ZERO';
            this.fetchBoardingCount();
            this.fetchAsramaStats();
            this.fetchMeetings();
            this.fetchApprovals();
            this.fetchDocuments();
            this.loadTasks();
            this.loadChatMessages();
            this.fetchZeroTodayReports();
        } else {
            // School Unit
            if (this.currentPosition === 'kepala') {
                this.fetchUnitStats();
                this.fetchUnitLocks();
            } else {
                this.fetchAttendance();
                this.fetchStats();
                this.fetchAcademicAgenda();
                this.fetchCounselingSummary();
                if (this.currentPosition === 'wali') {
                    this.fetchHomeroomClass();
                    if (this.showWaliClassSelector) {
                        this.fetchClassesForUnit();
                    }
                }
            }
        }
        
        this.refreshActivities();
        
        setInterval(() => {
            this.currentTime = new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
        }, 1000);
    },
    beforeUnmount() {
        window.removeEventListener('focus', this.handleWindowFocus);
    }
}).mount('#app');
</script>
