<?php
require_once '../../config/database.php';
// Compute BASE_URL
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
if (strpos($host, 'localhost') !== false || $host === '127.0.0.1') {
    $port = $_SERVER['SERVER_PORT'] ?? 80;
    $baseUrl = ($port == 8000) ? '/' : '/AIS/';
} else {
    $scriptName = $_SERVER['SCRIPT_NAME'] ?? '';
    $baseUrl = (stripos($scriptName, '/AIS/') !== false) ? '/AIS/' : '/';
}

// Fetch settings
$stmt = $pdo->query("SELECT * FROM kiosk_settings");
$dbSettings = $stmt->fetchAll(PDO::FETCH_ASSOC);
$settings = [];
foreach ($dbSettings as $row) {
    $decoded = json_decode($row['setting_value'], true);
    $value = (json_last_error() === JSON_ERROR_NONE) ? $decoded : $row['setting_value'];
    $settings[$row['zone']][$row['setting_key']] = $value;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SekolahOS Kiosk Display</title>
    <script>
        window.BASE_URL = '<?php echo $baseUrl; ?>';
    </script>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="<?php echo $baseUrl; ?>assets/js/vue.global.js"></script>
    <link href="<?php echo $baseUrl; ?>assets/css/fontawesome.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@400;700&family=Inter:wght@400;600&family=Amiri&display=swap" rel="stylesheet">
    <style>
        .fade-enter-active, .fade-leave-active { transition: opacity 1s; }
        .fade-enter-from, .fade-leave-to { opacity: 0; }
        .running-text { animation: scroll 20s linear infinite; }
        @keyframes scroll { from { transform: translateX(100%); } to { transform: translateX(-100%); } }
        [v-cloak] { display: none; }
    </style>
</head>
<body class="bg-black text-white overflow-hidden h-screen w-screen">
    <div id="app" v-cloak class="h-full w-full relative">
        <div v-if="zone !== 'masjid'" class="absolute top-0 w-full h-20 bg-gradient-to-r from-blue-900 to-slate-900 flex items-center justify-between px-8 z-20 shadow-xl border-b border-white/10">
            <div class="flex items-center gap-4">
                <div class="w-12 h-12 bg-white rounded-lg flex items-center justify-center text-blue-900 font-bold text-xl">S</div>
                <div>
                    <h1 class="text-2xl font-bold font-['Oswald'] tracking-wide">SEKOLAH PENDIDIKAN INDONESIA</h1>
                    <p class="text-sm text-slate-300">{{ zoneLabel }} Display</p>
                </div>
            </div>
            <div class="text-right">
                <h2 class="text-3xl font-bold font-mono">{{ currentTime }}</h2>
                <p class="text-sm text-slate-300">{{ currentDate }}</p>
            </div>
        </div>

        <div v-if="zone === 'tamu'" class="h-full pt-20 flex flex-col items-center justify-center bg-slate-900 relative overflow-hidden">
            <div class="absolute inset-0 z-0 opacity-30">
                <img src="https://source.unsplash.com/random/1920x1080/?office,modern" class="w-full h-full object-cover">
            </div>
            <div class="z-10 text-center max-w-4xl p-10 bg-black/40 backdrop-blur-md rounded-3xl border border-white/10 shadow-2xl animate-fade">
                <h2 class="text-6xl font-bold font-['Oswald'] mb-6 text-yellow-400">{{ welcomeText }}</h2>
                <p class="text-2xl text-slate-200">Silahkan hubungi resepsionis untuk bantuan lebih lanjut.</p>
                <div class="mt-12 flex justify-center gap-8">
                    <div class="bg-blue-600/80 p-6 rounded-2xl backdrop-blur border border-blue-400/30">
                        <i class="fas fa-wifi text-4xl mb-2"></i>
                        <p class="font-bold">Free WiFi</p>
                        <p class="text-sm text-blue-200">Guest_School</p>
                    </div>
                    <div class="bg-green-600/80 p-6 rounded-2xl backdrop-blur border border-green-400/30">
                        <i class="fas fa-coffee text-4xl mb-2"></i>
                        <p class="font-bold">Coffee Corner</p>
                        <p class="text-sm text-green-200">Self Service</p>
                    </div>
                </div>
            </div>
            <div class="absolute bottom-0 w-full h-16 bg-blue-900 flex items-center overflow-hidden border-t border-white/10 z-20">
                <div class="bg-yellow-500 h-full flex items-center px-6 font-bold text-black z-10 absolute left-0 shadow-lg uppercase">INFO</div>
                <div class="whitespace-nowrap absolute left-0 w-full">
                    <p class="running-text text-2xl font-medium inline-block pl-[100%]">
                        {{ runningText || 'Selamat Datang di Sekolah Pendidikan Indonesia. Tamu harap lapor Satpam.' }}
                    </p>
                </div>
            </div>
        </div>

        <div v-if="zone === 'aula'" class="h-full pt-20 flex flex-col">
            <div class="flex-1 flex overflow-hidden">
                <div class="w-3/4 bg-black relative">
                    <img :src="currentSlide" class="w-full h-full object-cover animate-fade">
                    <div v-if="currentNews" class="absolute bottom-10 left-10 bg-black/70 p-6 rounded-xl border-l-4 border-blue-500 backdrop-blur-sm max-w-2xl animate-fade">
                        <h2 class="text-3xl font-bold mb-2">{{ currentNews.title }}</h2>
                        <p class="text-xl text-slate-200">{{ currentNews.content }}</p>
                    </div>
                </div>
                <div class="w-1/4 bg-slate-900 border-l border-slate-800 flex flex-col">
                    <div class="bg-blue-800 p-4 text-center font-bold text-xl uppercase tracking-widest">Agenda Sekolah</div>
                    <div class="flex-1 p-6 space-y-6 overflow-y-auto">
                        <div v-for="(news, idx) in newsItems" :key="idx" class="border-l-4 border-yellow-500 pl-4">
                             <p class="text-yellow-500 font-bold text-sm">INFO</p>
                             <h3 class="text-xl font-bold">{{ news.title }}</h3>
                             <p class="text-slate-400 text-sm">{{ news.content }}</p>
                        </div>
                         <div v-if="newsItems.length === 0" class="text-slate-500 text-center mt-10">Belum ada info.</div>
                    </div>
                </div>
            </div>
            <div class="h-16 bg-blue-900 flex items-center overflow-hidden relative border-t border-white/10">
                <div class="bg-yellow-500 h-full flex items-center px-6 font-bold text-black z-10 absolute left-0 shadow-lg uppercase">Info Terkini</div>
                <div class="whitespace-nowrap absolute left-0 w-full">
                    <p class="running-text text-2xl font-medium inline-block pl-[100%]">
                         {{ runningText || 'Selamat Datang di Sekolah Pendidikan Indonesia.' }}
                    </p>
                </div>
            </div>
        </div>

        <div v-if="zone === 'masjid'" class="h-full bg-slate-900 relative overflow-hidden flex flex-col" style="background: linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)), #1e293b;">
            <div class="h-24 bg-black/40 backdrop-blur-md flex justify-between items-center px-10 border-b border-white/20">
                <div>
                    <h1 class="text-3xl font-bold font-['Amiri'] text-amber-400">Masjid Al-Amanah</h1>
                    <p class="text-lg text-slate-300">Sekolah Pendidikan Indonesia</p>
                </div>
                <div class="text-right">
                    <h2 class="text-5xl font-bold font-mono tracking-widest text-white drop-shadow-lg">{{ currentTime }}</h2>
                </div>
            </div>
            <div class="flex-1 flex items-center justify-center p-10">
                <div class="grid grid-cols-5 gap-4 w-full max-w-6xl">
                    <div v-for="(time, name) in prayerTimes" :key="name" :class="isNextPrayer(name, time) ? 'bg-green-800/80 border-green-500 scale-110 shadow-2xl z-10' : 'bg-black/60 border-slate-600'" class="backdrop-blur p-6 rounded-2xl text-center border-b-8 transition-all duration-500">
                        <p :class="isNextPrayer(name, time) ? 'text-green-200' : 'text-slate-300'" class="text-xl font-['Amiri'] mb-2 capitalize">{{ name }}</p>
                        <h3 :class="isNextPrayer(name, time) ? 'text-6xl' : 'text-4xl'" class="font-bold">{{ time }}</h3>
                        <p v-if="isNextPrayer(name, time)" class="text-sm mt-4 text-green-200 animate-pulse">Waktu Sholat Berikutnya</p>
                    </div>
                </div>
            </div>
            <div class="h-32 bg-black/60 backdrop-blur-md flex items-center justify-center px-20 text-center border-t border-white/20">
                <div>
                    <p class="text-2xl font-['Amiri'] text-amber-200 mb-2">"Shalat itu adalah tiang agama, barangsiapa mendirikannya maka sungguh ia telah mendirikan agama."</p>
                    <p class="text-slate-400 text-sm">(HR. Baihaqi)</p>
                </div>
            </div>
        </div>

        <div class="absolute bottom-4 right-4 bg-black/80 text-white p-4 rounded-lg backdrop-blur text-xs z-50 opacity-20 hover:opacity-100 transition-opacity">
            <p class="font-bold mb-2">Select Zone (Preview):</p>
            <div class="flex gap-2">
                <button @click="zone = 'tamu'" class="px-3 py-1 bg-slate-700 hover:bg-blue-600 rounded">Tamu</button>
                <button @click="zone = 'aula'" class="px-3 py-1 bg-slate-700 hover:bg-blue-600 rounded">Aula</button>
                <button @click="zone = 'masjid'" class="px-3 py-1 bg-slate-700 hover:bg-blue-600 rounded">Masjid</button>
                <button @click="zone = 'kantor'" class="px-3 py-1 bg-slate-700 hover:bg-blue-600 rounded">Kantor</button>
            </div>
        </div>
    </div>

    <script>
        const { createApp } = Vue;
        const SERVER_SETTINGS = <?php echo json_encode($settings); ?>;
        createApp({
            data() {
                return {
                    settings: SERVER_SETTINGS || {},
                    zone: 'aula',
                    currentTime: '',
                    currentDate: '',
                    slides: [
                        'https://placehold.co/1280x720?text=Selamat+Datang',
                        'https://placehold.co/1280x720?text=School+Activities',
                    ],
                    currentSlideIndex: 0
                }
            },
            computed: {
                zoneLabel() { return this.zone.charAt(0).toUpperCase() + this.zone.slice(1); },
                currentSlide() { return this.slides[this.currentSlideIndex]; },
                welcomeText() { return this.settings.tamu?.welcome_text || 'Selamat Datang'; },
                runningText() { return this.settings.tamu?.running_text || ''; },
                teacherAgenda() { return this.settings.kantor?.teacher_agenda || []; },
                prayerTimes() { return this.settings.masjid?.prayer_times || { subuh:'04:42', dzuhur:'12:00', ashar:'15:30', maghrib:'18:00', isya:'19:15' }; },
                newsItems() { return this.settings.aula?.news_items || []; },
                currentNews() {
                    if (this.newsItems.length > 0) {
                        return this.newsItems[this.currentSlideIndex % this.newsItems.length];
                    }
                    return null;
                }
            },
            methods: {
                isNextPrayer(name, time) { return false; }
            },
            mounted() {
                const urlParams = new URLSearchParams(window.location.search);
                const zoneParam = urlParams.get('zone');
                if (zoneParam) {
                    this.zone = zoneParam;
                    if (this.zone === 'masjid') {
                        window.location.href = (window.BASE_URL || (window.location.pathname.includes('/AIS/') ? '/AIS/' : '/')) + 'masjid_display/dist/index.html';
                        return;
                    }
                }
                setInterval(() => {
                    const now = new Date();
                    this.currentTime = now.toLocaleTimeString('id-ID', {hour: '2-digit', minute:'2-digit', second:'2-digit'});
                    this.currentDate = now.toLocaleDateString('id-ID', {weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'});
                }, 1000);
                setInterval(() => {
                    this.currentSlideIndex = (this.currentSlideIndex + 1) % (Math.max(this.slides.length, this.newsItems.length) || 1);
                }, 5000);
            }
        }).mount('#app');
    </script>
</body>
</html>
