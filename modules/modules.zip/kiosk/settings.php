<?php
require_once '../../config/database.php';
session_start();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    if ($data) {
        try {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare("INSERT INTO kiosk_settings (zone, setting_key, setting_value) VALUES (:zone, :key, :value) ON DUPLICATE KEY UPDATE setting_value = :value");
            foreach ($data as $item) {
                $val = is_array($item['value']) ? json_encode($item['value']) : $item['value'];
                $stmt->execute([
                    ':zone' => $item['zone'],
                    ':key' => $item['key'],
                    ':value' => $val
                ]);
            }
            $pdo->commit();
            echo json_encode(['status' => 'success', 'message' => 'Settings saved successfully']);
            exit;
        } catch (Exception $e) {
            $pdo->rollBack();
            http_response_code(500);
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
            exit;
        }
    }
}
$stmt = $pdo->query("SELECT * FROM kiosk_settings");
$dbSettings = $stmt->fetchAll(PDO::FETCH_ASSOC);
$settings = [];
foreach ($dbSettings as $row) {
    $decoded = json_decode($row['setting_value'], true);
    $value = (json_last_error() === JSON_ERROR_NONE) ? $decoded : $row['setting_value'];
    $settings[$row['zone']][$row['setting_key']] = $value;
}
require_once '../../includes/header.php';
?>
<div id="app" v-cloak class="flex h-screen bg-slate-50">
    <main class="flex-1 overflow-y-auto h-full flex flex-col w-full">
        <header class="bg-white border-b border-slate-200 h-16 flex items-center justify-between px-8 z-10 sticky top-0 shadow-sm">
            <div class="flex items-center gap-4">
                <a href="<?php echo $baseUrl; ?>index.php" class="w-10 h-10 bg-slate-100 text-slate-600 rounded-lg flex items-center justify-center hover:bg-slate-200 transition-colors">
                    <i class="fas fa-arrow-left"></i>
                </a>
                <div class="w-10 h-10 bg-blue-600 text-white rounded-lg flex items-center justify-center text-xl shadow-lg shadow-blue-200">
                    <i class="fas fa-tv"></i>
                </div>
                <div>
                    <h1 class="text-xl font-bold text-slate-800">Kiosk Display Settings</h1>
                    <p class="text-xs text-slate-500 font-medium">Konfigurasi Tampilan Layar Informasi</p>
                </div>
            </div>
            <div class="flex gap-3">
                <a href="<?php echo $baseUrl; ?>modules/kiosk/display.php" target="_blank" class="px-4 py-2 bg-white border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 font-medium transition-colors">
                    <i class="fas fa-external-link-alt mr-2"></i> Preview Display
                </a>
                <button @click="saveSettings" :disabled="saving" class="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-bold shadow-lg shadow-blue-200 transition-all flex items-center gap-2">
                    <i v-if="saving" class="fas fa-spinner fa-spin"></i>
                    <span v-else><i class="fas fa-save"></i></span>
                    {{ saving ? 'Menyimpan...' : 'Simpan Perubahan' }}
                </button>
            </div>
        </header>
        <div class="p-8 max-w-5xl mx-auto w-full">
            <div class="flex gap-2 mb-6 border-b border-slate-200 pb-1 overflow-x-auto">
                <button @click="activeTab = 'tamu'" :class="activeTab === 'tamu' ? 'border-blue-600 text-blue-600 bg-blue-50' : 'border-transparent text-slate-500 hover:text-slate-700 hover:bg-slate-100'" class="px-6 py-3 border-b-2 font-bold rounded-t-lg transition-all whitespace-nowrap">
                    <i class="fas fa-door-open mr-2"></i> Ruang Tamu
                </button>
                <button @click="activeTab = 'kantor'" :class="activeTab === 'kantor' ? 'border-blue-600 text-blue-600 bg-blue-50' : 'border-transparent text-slate-500 hover:text-slate-700 hover:bg-slate-100'" class="px-6 py-3 border-b-2 font-bold rounded-t-lg transition-all whitespace-nowrap">
                    <i class="fas fa-briefcase mr-2"></i> Kantor Guru
                </button>
                <button @click="activeTab = 'masjid'" :class="activeTab === 'masjid' ? 'border-blue-600 text-blue-600 bg-blue-50' : 'border-transparent text-slate-500 hover:text-slate-700 hover:bg-slate-100'" class="px-6 py-3 border-b-2 font-bold rounded-t-lg transition-all whitespace-nowrap">
                    <i class="fas fa-mosque mr-2"></i> Masjid
                </button>
                <button @click="activeTab = 'aula'" :class="activeTab === 'aula' ? 'border-blue-600 text-blue-600 bg-blue-50' : 'border-transparent text-slate-500 hover:text-slate-700 hover:bg-slate-100'" class="px-6 py-3 border-b-2 font-bold rounded-t-lg transition-all whitespace-nowrap">
                    <i class="fas fa-bullhorn mr-2"></i> Aula / Info
                </button>
            </div>
            <div v-if="activeTab === 'tamu'" class="animate-fade">
                <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 space-y-6">
                    <div>
                        <label class="block text-sm font-bold text-slate-700 mb-2">Pesan Selamat Datang</label>
                        <input type="text" v-model="settings.tamu.welcome_text" class="w-full px-4 py-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all" placeholder="Contoh: Selamat Datang di...">
                    </div>
                    <div>
                        <label class="block text-sm font-bold text-slate-700 mb-2">Running Text (Info Bawah)</label>
                        <textarea v-model="settings.tamu.running_text" rows="3" class="w-full px-4 py-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 outline-none" placeholder="Info berjalan di bawah layar..."></textarea>
                    </div>
                </div>
            </div>
            <div v-if="activeTab === 'kantor'" class="animate-fade">
                <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                    <div class="flex justify-between items-center mb-6">
                        <h3 class="font-bold text-lg text-slate-700">Agenda Guru</h3>
                        <button @click="addAgenda" class="text-sm bg-green-100 text-green-700 px-3 py-1.5 rounded-lg font-bold hover:bg-green-200 transition-colors">
                            <i class="fas fa-plus mr-1"></i> Tambah Agenda
                        </button>
                    </div>
                    <div class="space-y-4">
                        <div v-for="(item, index) in settings.kantor.teacher_agenda" :key="index" class="flex gap-4 items-start bg-slate-50 p-4 rounded-xl border border-slate-100 group">
                            <div class="w-32">
                                <label class="text-xs text-slate-500 font-bold uppercase">Jam</label>
                                <input type="time" v-model="item.time" class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm">
                            </div>
                            <div class="flex-1">
                                <label class="text-xs text-slate-500 font-bold uppercase">Kegiatan</label>
                                <input type="text" v-model="item.activity" class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm mb-2" placeholder="Nama Kegiatan">
                                <input type="text" v-model="item.location" class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm" placeholder="Lokasi">
                            </div>
                            <button @click="removeAgenda(index)" class="mt-6 text-slate-400 hover:text-red-500 transition-colors">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                        <div v-if="settings.kantor.teacher_agenda.length === 0" class="text-center py-8 text-slate-400 border-2 border-dashed border-slate-200 rounded-xl">
                            Belum ada agenda.
                        </div>
                    </div>
                </div>
            </div>
            <div v-if="activeTab === 'masjid'" class="animate-fade">
                <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                    <h3 class="font-bold text-lg text-slate-700 mb-6">Jadwal Sholat (Manual)</h3>
                    <div class="grid grid-cols-2 md:grid-cols-5 gap-4">
                        <div v-for="(time, name) in settings.masjid.prayer_times" :key="name" class="bg-slate-50 p-4 rounded-xl border border-slate-100 text-center">
                            <label class="block text-sm font-bold text-slate-500 uppercase mb-2">{{ name }}</label>
                            <input type="time" v-model="settings.masjid.prayer_times[name]" class="w-full text-center text-xl font-bold bg-white border border-slate-300 rounded-lg px-2 py-2 focus:ring-2 focus:ring-green-500 outline-none">
                        </div>
                    </div>
                    <p class="text-xs text-slate-500 mt-4 italic">* Nantinya bisa diintegrasikan dengan API jadwal sholat otomatis.</p>
                </div>
            </div>
            <div v-if="activeTab === 'aula'" class="animate-fade">
                <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                    <div class="flex justify-between items-center mb-6">
                        <h3 class="font-bold text-lg text-slate-700">Berita / Pengumuman</h3>
                        <div class="flex gap-2">
                            <a href="<?php echo $baseUrl; ?>modules/kiosk/display.php?zone=aula" target="_blank" class="text-sm bg-slate-100 text-slate-600 px-3 py-1.5 rounded-lg font-bold hover:bg-slate-200 transition-colors border border-slate-300">
                                <i class="fas fa-eye mr-1"></i> Preview Aula
                            </a>
                            <button @click="addNews" class="text-sm bg-blue-100 text-blue-700 px-3 py-1.5 rounded-lg font-bold hover:bg-blue-200 transition-colors">
                                <i class="fas fa-plus mr-1"></i> Tambah Berita
                            </button>
                        </div>
                    </div>
                    <div class="space-y-4">
                        <div v-for="(news, index) in settings.aula.news_items" :key="index" class="bg-slate-50 p-4 rounded-xl border border-slate-100 relative group">
                            <button @click="removeNews(index)" class="absolute top-4 right-4 text-slate-400 hover:text-red-500 transition-colors">
                                <i class="fas fa-trash"></i>
                            </button>
                            <div class="mb-3 pr-8">
                                <label class="text-xs text-slate-500 font-bold uppercase">Judul</label>
                                <input type="text" v-model="news.title" class="w-full px-3 py-2 rounded-lg border border-slate-300 font-bold text-slate-800" placeholder="Judul Berita">
                            </div>
                            <div>
                                <label class="text-xs text-slate-500 font-bold uppercase">Konten Singkat</label>
                                <textarea v-model="news.content" rows="2" class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm" placeholder="Isi berita..."></textarea>
                            </div>
                        </div>
                        <div v-if="settings.aula.news_items.length === 0" class="text-center py-8 text-slate-400 border-2 border-dashed border-slate-200 rounded-xl">
                            Belum ada berita.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>
<script src="<?php echo $baseUrl; ?>assets/js/app.js" type="module"></script>
<script>
const { createApp } = Vue;
window.SERVER_SETTINGS = <?php echo json_encode($settings); ?>;
createApp({
    data() {
        return {
            baseUrl: window.BASE_URL || '/',
            saving: false,
            activeTab: 'tamu',
            settings: window.SERVER_SETTINGS || {
                tamu: { welcome_text: '', running_text: '' },
                kantor: { teacher_agenda: [] },
                masjid: { prayer_times: { Subuh: '', Dzuhur: '', Ashar: '', Maghrib: '', Isya: '' } },
                aula: { news_items: [] }
            }
        }
    },
    methods: {
        normalizeBaseUrl() {
            if (this.baseUrl === '/' || !this.baseUrl) {
                const m = (window.location.pathname || '').match(/^\/(AIS|AIStest)\//i);
                this.baseUrl = m ? `/${m[1]}/` : '/';
            }
        },
        addAgenda() {
            if (!this.settings.kantor.teacher_agenda) this.settings.kantor.teacher_agenda = [];
            this.settings.kantor.teacher_agenda.push({ time: '', activity: '', location: '' });
        },
        removeAgenda(index) {
            this.settings.kantor.teacher_agenda.splice(index, 1);
        },
        addNews() {
            if (!this.settings.aula.news_items) this.settings.aula.news_items = [];
            this.settings.aula.news_items.push({ title: '', content: '' });
        },
        removeNews(index) {
            this.settings.aula.news_items.splice(index, 1);
        },
        async saveSettings() {
            this.saving = true;
            try {
                this.normalizeBaseUrl();
                const payload = [];
                for (const zone of ['tamu', 'kantor', 'masjid', 'aula']) {
                    const zoneSettings = this.settings[zone] || {};
                    for (const key in zoneSettings) {
                        payload.push({ zone, key, value: zoneSettings[key] });
                    }
                }
                const res = await fetch(window.location.href, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
                const json = await res.json();
                alert(json.message || 'Tersimpan');
            } catch (e) {
                alert('Gagal menyimpan');
            } finally {
                this.saving = false;
            }
        }
    }
}).mount('#app');
</script>
