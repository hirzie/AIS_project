<?php
require_once '../../config/database.php';
require_once '../../includes/header_inventory.php';
?>

<div class="flex flex-col h-screen overflow-hidden">
    <nav class="bg-white border-b border-slate-200 h-16 flex items-center justify-between px-6 z-20 shadow-sm relative">
        <div class="flex items-center gap-4">
            <a href="#" onclick="window.location.href=(window.BASE_URL||(window.location.pathname.includes('/AIS/')?'/AIS/':'/'))+'modules/inventory/dashboard.php'; return false;" class="w-10 h-10 bg-slate-100 rounded-lg flex items-center justify-center text-slate-600 hover:bg-slate-200 transition-colors">
                <i class="fas fa-arrow-left"></i>
            </a>
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 bg-emerald-100 text-emerald-600 rounded-lg flex items-center justify-center">
                    <i class="fas fa-car text-xl"></i>
                </div>
                <div>
                    <h1 class="text-xl font-bold text-slate-800 leading-none">Kendaraan Dinas</h1>
                    <span class="text-xs text-slate-500 font-medium">Manajemen Armada Sekolah</span>
                </div>
            </div>
        </div>
        
        <div class="flex items-center gap-4">
            <button class="text-slate-500 hover:text-slate-700 font-medium text-sm flex items-center gap-2">
                <i class="fas fa-wrench"></i> Jadwal Service
            </button>
            <div class="h-6 w-px bg-slate-300"></div>
            <span class="text-sm font-medium text-slate-500">{{ currentDate }}</span>
        </div>
    </nav>

    <main class="flex-1 overflow-hidden p-4 bg-slate-100 flex flex-col">
        <div class="bg-white p-4 rounded-t-xl border-b border-slate-100 flex justify-between items-center shadow-sm">
            <div class="flex items-center gap-4">
                <div class="relative">
                    <i class="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"></i>
                    <input type="text" v-model="searchQuery" placeholder="Cari kendaraan..." class="pl-10 pr-4 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 w-64">
                </div>
            </div>
            <button @click="openModal()" class="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 transition-colors shadow-sm shadow-emerald-200">
                <i class="fas fa-plus"></i> Tambah Kendaraan
            </button>
        </div>

        <div class="bg-white flex-1 rounded-b-xl shadow-sm overflow-hidden flex flex-col">
            <div class="overflow-x-auto flex-1 custom-scrollbar">
                <table class="w-full text-left border-collapse">
                    <thead class="bg-slate-50 sticky top-0 z-10 shadow-sm">
                        <tr>
                            <th class="p-4 text-xs font-bold text-slate-500 uppercase tracking-wider border-b border-slate-200 w-16">No</th>
                            <th class="p-4 text-xs font-bold text-slate-500 uppercase tracking-wider border-b border-slate-200">Plat Nomor</th>
                            <th class="p-4 text-xs font-bold text-slate-500 uppercase tracking-wider border-b border-slate-200">Kendaraan</th>
                            <th class="p-4 text-xs font-bold text-slate-500 uppercase tracking-wider border-b border-slate-200">Tahun</th>
                            <th class="p-4 text-xs font-bold text-slate-500 uppercase tracking-wider border-b border-slate-200">Warna</th>
                            <th class="p-4 text-xs font-bold text-slate-500 uppercase tracking-wider border-b border-slate-200">Status Service</th>
                            <th class="p-4 text-xs font-bold text-slate-500 uppercase tracking-wider border-b border-slate-200">Pajak STNK</th>
                            <th class="p-4 text-xs font-bold text-slate-500 uppercase tracking-wider border-b border-slate-200 text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100">
                        <tr v-for="(item, index) in filteredItems" :key="item.id" class="hover:bg-slate-50 transition-colors">
                            <td class="p-4 text-sm text-slate-500">{{ index + 1 }}</td>
                            <td class="p-4 text-sm font-mono font-bold text-slate-800 bg-slate-50 rounded w-32 text-center border border-slate-200">{{ item.license_plate }}</td>
                            <td class="p-4 text-sm font-medium text-slate-800">{{ item.name }}</td>
                            <td class="p-4 text-sm text-slate-600">{{ item.year }}</td>
                            <td class="p-4 text-sm text-slate-600">{{ item.color }}</td>
                            <td class="p-4 text-sm">
                                <div class="flex items-center gap-2">
                                    <div class="flex-1 h-2 bg-slate-200 rounded-full overflow-hidden w-24">
                                        <div class="h-full bg-emerald-500" :style="{ width: item.service_health + '%' }"></div>
                                    </div>
                                    <span class="text-xs text-slate-500">{{ item.service_health }}%</span>
                                </div>
                                <div class="text-[10px] text-slate-400 mt-1">Last: {{ item.last_service }}</div>
                            </td>
                            <td class="p-4 text-sm">
                                <span :class="isTaxExpired(item.tax_expiry_date) ? 'text-red-600 font-bold' : 'text-slate-600'">
                                    {{ item.tax_expiry_date || '-' }}
                                </span>
                            </td>
                            <td class="p-4 text-center">
                                <button @click="openService(item)" class="text-slate-400 hover:text-emerald-600 mx-1" title="Riwayat Service"><i class="fas fa-wrench"></i></button>
                                <button @click="openModal(item)" class="text-slate-400 hover:text-blue-600 mx-1" title="Edit"><i class="fas fa-edit"></i></button>
                                <button @click="deleteItem(item)" class="text-slate-400 hover:text-red-600 mx-1" title="Hapus"><i class="fas fa-trash"></i></button>
                            </td>
                        </tr>
                        <tr v-if="filteredItems.length === 0">
                            <td colspan="8" class="p-8 text-center text-slate-500 italic">Data tidak ditemukan</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <div v-if="showModal" class="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
        <div class="bg-white rounded-xl shadow-xl w-full max-w-lg overflow-hidden">
            <div class="px-6 py-4 border-b border-slate-100 flex justify-between items-center">
                <h3 class="font-bold text-lg text-slate-800">{{ form.id ? 'Edit Kendaraan' : 'Tambah Kendaraan' }}</h3>
                <button @click="closeModal" class="text-slate-400 hover:text-slate-600"><i class="fas fa-times"></i></button>
            </div>
            <div class="p-6 space-y-4">
                <div>
                    <label class="block text-xs font-bold text-slate-500 mb-1">Nama Kendaraan</label>
                    <input type="text" v-model="form.name" class="w-full border rounded px-3 py-2 text-sm focus:outline-none focus:border-emerald-500" placeholder="Contoh: Toyota Hiace">
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xs font-bold text-slate-500 mb-1">Plat Nomor</label>
                        <input type="text" v-model="form.license_plate" class="w-full border rounded px-3 py-2 text-sm focus:outline-none focus:border-emerald-500" placeholder="B 1234 CD">
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-slate-500 mb-1">Tipe</label>
                        <input type="text" v-model="form.type" class="w-full border rounded px-3 py-2 text-sm focus:outline-none focus:border-emerald-500" placeholder="Contoh: Minibus">
                    </div>
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xs font-bold text-slate-500 mb-1">Tahun</label>
                        <input type="number" v-model="form.year" class="w-full border rounded px-3 py-2 text-sm focus:outline-none focus:border-emerald-500" placeholder="YYYY">
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-slate-500 mb-1">Warna</label>
                        <input type="text" v-model="form.color" class="w-full border rounded px-3 py-2 text-sm focus:outline-none focus:border-emerald-500" placeholder="Warna">
                    </div>
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xs font-bold text-slate-500 mb-1">Tanggal Service Terakhir</label>
                        <input type="date" v-model="form.last_service" class="w-full border rounded px-3 py-2 text-sm focus:outline-none focus:border-emerald-500">
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-slate-500 mb-1">Tanggal Pajak STNK</label>
                        <input type="date" v-model="form.tax_expiry_date" class="w-full border rounded px-3 py-2 text-sm focus:outline-none focus:border-emerald-500">
                    </div>
                </div>
            </div>
            <div class="px-6 py-4 bg-slate-50 border-t border-slate-100 flex justify-end gap-2">
                <button @click="closeModal" class="px-4 py-2 rounded-lg text-sm font-bold text-slate-600 hover:bg-slate-200">Batal</button>
                <button @click="saveItem" class="px-4 py-2 rounded-lg text-sm font-bold text-white bg-emerald-600 hover:bg-emerald-700 shadow-lg shadow-emerald-200">Simpan</button>
            </div>
        </div>
    </div>

</div>

<script>
    const { createApp } = Vue

    createApp({
        data() {
            return {
                searchQuery: '',
                items: [],
                showModal: false,
                form: {
                    id: null,
                    name: '',
                    license_plate: '',
                    type: '',
                    year: '',
                    color: '',
                    last_service: '',
                    tax_expiry_date: ''
                }
            }
        },
        computed: {
            currentDate() {
                return new Date().toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
            },
            filteredItems() {
                let res = this.items;
                if (this.searchQuery) {
                    const lower = this.searchQuery.toLowerCase();
                    res = res.filter(item => 
                        (item.name || '').toLowerCase().includes(lower) || 
                        (item.license_plate || '').toLowerCase().includes(lower)
                    );
                }
                return res;
            }
        },
        methods: {
            async fetchData() {
                const res = await fetch(window.BASE_URL + 'api/inventory.php?action=get_vehicles');
                const data = await res.json();
                if (data.success) this.items = data.data;
            },
            isTaxExpired(dateStr) {
                if (!dateStr || dateStr === '-') return false;
                const d = new Date(dateStr);
                const today = new Date();
                return d < today;
            },
            openService(item) {
            },
            openModal(item = null) {
                if (item) {
                    this.form = { ...item };
                } else {
                    this.form = {
                        id: null,
                        name: '',
                        license_plate: '',
                        type: '',
                        year: '',
                        color: '',
                        last_service: new Date().toISOString().slice(0, 10),
                        tax_expiry_date: ''
                    };
                }
                this.showModal = true;
            },
            closeModal() {
                this.showModal = false;
            },
            async saveItem() {
                if (!this.form.name || !this.form.license_plate) return alert('Nama dan Plat Nomor wajib diisi!');
                try {
                    const res = await fetch(window.BASE_URL + 'api/inventory.php?action=save_vehicle', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(this.form)
                    });
                    const data = await res.json();
                    if (data.success) {
                        alert(data.message);
                        this.closeModal();
                        this.fetchData();
                    } else {
                        alert(data.message);
                    }
                } catch (e) {
                    console.error(e);
                }
            },
            async deleteItem(item) {
                if (!confirm(`Hapus kendaraan ${item.name}?`)) return;
                try {
                    const res = await fetch(window.BASE_URL + 'api/inventory.php?action=delete_vehicle', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ id: item.id })
                    });
                    const data = await res.json();
                    if (data.success) {
                        this.fetchData();
                    } else {
                        alert(data.message);
                    }
                } catch (e) {
                    console.error(e);
                }
            }
        },
        mounted() {
            this.fetchData();
        }
    }).mount('#app')
</script>
</body>
</html>
