<?php
require_once '../../config/database.php';
require_once '../../includes/header_inventory.php';
?>

<script>window.USE_GLOBAL_APP=false;</script>
<script>
document.addEventListener('DOMContentLoaded',function(){
    try{document.querySelectorAll('[v-cloak]').forEach(function(n){n.removeAttribute('v-cloak');});}catch(_){}
});
</script>

<div id="inventoryDashboard" v-cloak>
<nav class="bg-white border-b border-slate-200 h-16 flex items-center justify-between px-6 z-20 shadow-sm relative">
    <div class="flex items-center gap-3">
        <div class="w-10 h-10 bg-emerald-600 rounded-lg flex items-center justify-center text-white shadow-lg shadow-emerald-200">
            <i class="fas fa-boxes text-xl"></i>
        </div>
        <div>
            <h1 class="text-xl font-bold text-slate-800 leading-none">Inventory & Aset</h1>
            <span class="text-xs text-slate-500 font-medium">Asset Management System</span>
        </div>
    </div>
    <div class="flex items-center gap-4">
        <span class="text-sm font-medium text-slate-500 bg-slate-100 px-3 py-1 rounded-full">{{ currentDate }}</span>
        <button onclick="window.location.href=(window.BASE_URL||(window.location.pathname.includes('/AIS/')?'/AIS/':'/'))+'index.php'" class="text-slate-400 hover:text-red-500 transition-colors" title="Keluar ke Menu Utama">
            <i class="fas fa-power-off text-lg"></i>
        </button>
    </div>
</nav>

<main class="flex-1 overflow-y-auto p-8 flex items-center justify-center bg-slate-50 relative">
    <div class="absolute inset-0 overflow-hidden pointer-events-none opacity-50">
        <div class="absolute -top-[20%] -right-[10%] w-[600px] h-[600px] rounded-full bg-emerald-100/50 blur-3xl"></div>
        <div class="absolute -bottom-[20%] -left-[10%] w-[500px] h-[500px] rounded-full bg-teal-100/50 blur-3xl"></div>
    </div>

    <div class="max-w-6xl w-full grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 relative z-10">
        <div class="group bg-white rounded-2xl p-6 shadow-sm border border-slate-100 hover:shadow-xl hover:-translate-y-1 transition-all duration-300 relative overflow-hidden">
            <div class="absolute top-0 right-0 w-24 h-24 bg-amber-50 rounded-bl-[100px] -mr-4 -mt-4 transition-transform group-hover:scale-110"></div>
            <div class="relative z-10 flex flex-col h-full">
                <a href="#" onclick="window.location.href=(window.BASE_URL||(window.location.pathname.includes('/AIS/')?'/AIS/':'/'))+'modules/inventory/fixed.php'; return false;" class="block">
                    <div class="w-14 h-14 bg-amber-100 text-amber-600 rounded-xl flex items-center justify-center text-2xl mb-6 shadow-sm group-hover:bg-amber-600 group-hover:text-white transition-colors">
                        <i class="fas fa-building"></i>
                    </div>
                    <h3 class="text-xl font-bold text-slate-800 mb-2">Aset Tidak Bergerak</h3>
                    <p class="text-sm text-slate-500 mb-4">Pengelolaan tanah, bangunan, dan infrastruktur fisik sekolah.</p>
                </a>
                <div class="mt-auto pt-4 border-t border-slate-100 grid grid-cols-1 gap-2">
                    <a href="#" onclick="window.location.href=(window.BASE_URL||(window.location.pathname.includes('/AIS/')?'/AIS/':'/'))+'modules/inventory/fixed.php'; return false;" class="flex items-center text-xs font-medium text-slate-500 hover:text-amber-600 transition-colors">
                        <i class="fas fa-landmark w-5 text-center"></i> Tanah & Sertifikat
                    </a>
                    <a href="#" onclick="window.location.href=(window.BASE_URL||(window.location.pathname.includes('/AIS/')?'/AIS/':'/'))+'modules/inventory/fixed.php'; return false;" class="flex items-center text-xs font-medium text-slate-500 hover:text-amber-600 transition-colors">
                        <i class="fas fa-school w-5 text-center"></i> Gedung & Ruangan
                    </a>
                    <a href="#" onclick="window.location.href=(window.BASE_URL||(window.location.pathname.includes('/AIS/')?'/AIS/':'/'))+'modules/inventory/fixed.php'; return false;" class="flex items-center text-xs font-medium text-slate-500 hover:text-amber-600 transition-colors">
                        <i class="fas fa-calculator w-5 text-center"></i> Hitung Penyusutan
                    </a>
                </div>
            </div>
        </div>

        <div class="group bg-white rounded-2xl p-6 shadow-sm border border-slate-100 hover:shadow-xl hover:-translate-y-1 transition-all duration-300 relative overflow-hidden">
            <div class="absolute top-0 right-0 w-24 h-24 bg-blue-50 rounded-bl-[100px] -mr-4 -mt-4 transition-transform group-hover:scale-110"></div>
            <div class="relative z-10 flex flex-col h-full">
                <a href="#" onclick="window.location.href=(window.BASE_URL||(window.location.pathname.includes('/AIS/')?'/AIS/':'/'))+'modules/inventory/movable.php'; return false;" class="block">
                    <div class="w-14 h-14 bg-blue-100 text-blue-600 rounded-xl flex items-center justify-center text-2xl mb-6 shadow-sm group-hover:bg-blue-600 group-hover:text-white transition-colors">
                        <i class="fas fa-chair"></i>
                    </div>
                    <h3 class="text-xl font-bold text-slate-800 mb-2">Aset Bergerak</h3>
                    <p class="text-sm text-slate-500 mb-4">Inventarisasi mebel, elektronik, dan peralatan operasional.</p>
                </a>
                <div class="mt-auto pt-4 border-t border-slate-100 grid grid-cols-1 gap-2">
                    <a href="#" onclick="window.location.href=(window.BASE_URL||(window.location.pathname.includes('/AIS/')?'/AIS/':'/'))+'modules/inventory/movable.php'; return false;" class="flex items-center text-xs font-medium text-slate-500 hover:text-blue-600 transition-colors">
                        <i class="fas fa-laptop w-5 text-center"></i> Elektronik & IT
                    </a>
                    <a href="#" onclick="window.location.href=(window.BASE_URL||(window.location.pathname.includes('/AIS/')?'/AIS/':'/'))+'modules/inventory/movable.php'; return false;" class="flex items-center text-xs font-medium text-slate-500 hover:text-blue-600 transition-colors">
                        <i class="fas fa-couch w-5 text-center"></i> Mebelair
                    </a>
                    <a href="#" onclick="window.location.href=(window.BASE_URL||(window.location.pathname.includes('/AIS/')?'/AIS/':'/'))+'modules/inventory/movable.php'; return false;" class="flex items-center text-xs font-medium text-slate-500 hover:text-blue-600 transition-colors">
                        <i class="fas fa-qrcode w-5 text-center"></i> Labeling & QR Code
                    </a>
                </div>
            </div>
        </div>

        <div class="group bg-white rounded-2xl p-6 shadow-sm border border-slate-100 hover:shadow-xl hover:-translate-y-1 transition-all duration-300 relative overflow-hidden">
            <div class="absolute top-0 right-0 w-24 h-24 bg-emerald-50 rounded-bl-[100px] -mr-4 -mt-4 transition-transform group-hover:scale-110"></div>
            <div class="relative z-10 flex flex-col h-full">
                <a href="#" onclick="window.location.href=(window.BASE_URL||(window.location.pathname.includes('/AIS/')?'/AIS/':'/'))+'modules/inventory/vehicles.php'; return false;" class="block">
                    <div class="w-14 h-14 bg-emerald-100 text-emerald-600 rounded-xl flex items-center justify-center text-2xl mb-6 shadow-sm group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                        <i class="fas fa-car"></i>
                    </div>
                    <h3 class="text-xl font-bold text-slate-800 mb-2">Kendaraan</h3>
                    <p class="text-sm text-slate-500 mb-4">Daftar kendaraan dinas, jadwal service, dan pajak.</p>
                </a>
                <div class="mt-auto pt-4 border-t border-slate-100 grid grid-cols-1 gap-2">
                    <a href="#" onclick="window.location.href=(window.BASE_URL||(window.location.pathname.includes('/AIS/')?'/AIS/':'/'))+'modules/inventory/vehicles.php'; return false;" class="flex items-center text-xs font-medium text-slate-500 hover:text-emerald-600 transition-colors">
                        <i class="fas fa-list w-5 text-center"></i> Daftar Unit
                    </a>
                    <a href="#" onclick="window.location.href=(window.BASE_URL||(window.location.pathname.includes('/AIS/')?'/AIS/':'/'))+'modules/inventory/vehicles.php'; return false;" class="flex items-center text-xs font-medium text-slate-500 hover:text-emerald-600 transition-colors">
                        <i class="fas fa-wrench w-5 text-center"></i> Riwayat Service
                    </a>
                    <a href="#" onclick="window.location.href=(window.BASE_URL||(window.location.pathname.includes('/AIS/')?'/AIS/':'/'))+'modules/inventory/vehicles.php'; return false;" class="flex items-center text-xs font-medium text-slate-500 hover:text-emerald-600 transition-colors">
                        <i class="fas fa-gas-pump w-5 text-center"></i> BBM & Operasional
                    </a>
                </div>
            </div>
        </div>

        <div class="group bg-white rounded-2xl p-6 shadow-sm border border-slate-100 hover:shadow-xl hover:-translate-y-1 transition-all duration-300 relative overflow-hidden">
            <div class="absolute top-0 right-0 w-24 h-24 bg-slate-50 rounded-bl-[100px] -mr-4 -mt-4 transition-transform group-hover:scale-110"></div>
            <div class="relative z-10 flex flex-col h-full">
                <a href="#" onclick="window.location.href=(window.BASE_URL||(window.location.pathname.includes('/AIS/')?'/AIS/':'/'))+'modules/inventory/settings.php'; return false;" class="block">
                    <div class="w-14 h-14 bg-slate-100 text-slate-600 rounded-xl flex items-center justify-center text-2xl mb-6 shadow-sm group-hover:bg-slate-600 group-hover:text-white transition-colors">
                        <i class="fas fa-cogs"></i>
                    </div>
                    <h3 class="text-xl font-bold text-slate-800 mb-2">Pengaturan</h3>
                    <p class="text-sm text-slate-500 mb-4">Master data kategori, lokasi, dan laporan inventaris.</p>
                </a>
                <div class="mt-auto pt-4 border-t border-slate-100 grid grid-cols-1 gap-2">
                    <a href="#" onclick="window.location.href=(window.BASE_URL||(window.location.pathname.includes('/AIS/')?'/AIS/':'/'))+'modules/inventory/settings.php'; return false;" class="flex items-center text-xs font-medium text-slate-500 hover:text-slate-800 transition-colors">
                        <i class="fas fa-tags w-5 text-center"></i> Kategori Aset
                    </a>
                    <a href="#" onclick="window.location.href=(window.BASE_URL||(window.location.pathname.includes('/AIS/')?'/AIS/':'/'))+'modules/inventory/settings.php'; return false;" class="flex items-center text-xs font-medium text-slate-500 hover:text-slate-800 transition-colors">
                        <i class="fas fa-map-marker-alt w-5 text-center"></i> Master Lokasi
                    </a>
                    <a href="#" onclick="window.location.href=(window.BASE_URL||(window.location.pathname.includes('/AIS/')?'/AIS/':'/'))+'modules/inventory/settings.php'; return false;" class="flex items-center text-xs font-medium text-slate-500 hover:text-slate-800 transition-colors">
                        <i class="fas fa-file-alt w-5 text-center"></i> Laporan Aset
                    </a>
                    <a href="#" onclick="window.location.href=(window.BASE_URL||(window.location.pathname.includes('/AIS/')?'/AIS/':'/'))+'modules/procurement/submit.php?module=SARPRAS&label=Fasilitas'; return false;" class="flex items-center text-xs font-bold text-indigo-600 hover:text-indigo-700 transition-colors mt-1 pt-1 border-t border-slate-50">
                        <i class="fas fa-shopping-cart w-5 text-center"></i> Procurement
                    </a>
                </div>
            </div>
        </div>
    </div>
</main>
<script>
const { createApp } = Vue;
createApp({
    data() {
        return { vehicles: [], loading: false }
    },
    computed: {
        currentDate() {
            return new Date().toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
        }
    },
    methods: {
        async fetchVehicles() {
            this.loading = true;
            try {
                const res = await fetch(window.BASE_URL + 'api/inventory.php?action=get_vehicles');
                const data = await res.json();
                if (data.success) this.vehicles = data.data;
            } catch (e) {
                console.error(e);
            } finally {
                this.loading = false;
            }
        },
        daysUntil(dateStr) {
            if (!dateStr || dateStr === '-') return null;
            const target = new Date(dateStr);
            const today = new Date();
            const diffMs = target.getTime() - today.getTime();
            return Math.ceil(diffMs / (1000 * 60 * 60 * 24));
        },
        daysOverdue(dateStr) {
            if (!dateStr || dateStr === '-') return 0;
            const d = new Date(dateStr);
            const today = new Date();
            const diffMs = today.getTime() - d.getTime();
            return diffMs > 0 ? Math.ceil(diffMs / (1000 * 60 * 60 * 24)) : 0;
        }
    },
    mounted() {
        this.fetchVehicles();
    }
}).mount('#inventoryDashboard');
</script>
</div>
