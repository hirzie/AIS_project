<?php
require_once '../../includes/guard.php';
require_login_and_module('admin'); // Only Admin/Superadmin
ais_init_session();

// Security Check
if (!in_array($_SESSION['role'], ['SUPERADMIN', 'ADMIN'])) {
    die("Access Denied");
}

require_once '../../config/database.php';

function getDatabaseStats($pdo, $dbname) {
    try {
        // Get Table Count
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = ?");
        $stmt->execute([$dbname]);
        $tableCount = $stmt->fetchColumn();

        // Get DB Size
        $stmt = $pdo->prepare("SELECT SUM(data_length + index_length) FROM information_schema.tables WHERE table_schema = ?");
        $stmt->execute([$dbname]);
        $sizeBytes = $stmt->fetchColumn();
        $sizeMB = round($sizeBytes / 1024 / 1024, 2);

        // Get MySQL Version
        $stmt = $pdo->query("SELECT VERSION()");
        $version = $stmt->fetchColumn();

        return [
            'tables' => $tableCount,
            'size' => $sizeMB . ' MB',
            'version' => $version
        ];
    } catch (Exception $e) {
        return ['tables' => '-', 'size' => '-', 'version' => '-'];
    }
}

// Configuration
$backupDir = __DIR__ . '/../../backups/';
if (!file_exists($backupDir)) {
    mkdir($backupDir, 0755, true);
}

// Metadata Helper Functions
$metaFile = $backupDir . 'backup_meta.json';

function getBackupMeta() {
    global $metaFile;
    if (file_exists($metaFile)) {
        $content = file_get_contents($metaFile);
        return json_decode($content, true) ?? [];
    }
    return [];
}

function saveBackupMeta($filename, $data) {
    global $metaFile;
    $meta = getBackupMeta();
    $meta[$filename] = $data;
    file_put_contents($metaFile, json_encode($meta, JSON_PRETTY_PRINT));
}

function deleteBackupMeta($filename) {
    global $metaFile;
    $meta = getBackupMeta();
    if (isset($meta[$filename])) {
        unset($meta[$filename]);
        file_put_contents($metaFile, json_encode($meta, JSON_PRETTY_PRINT));
    }
}

function getCurrentSchemaVersion($pdo) {
    try {
        $stmt = $pdo->prepare("SELECT setting_value FROM core_settings WHERE setting_key = 'schema_version' LIMIT 1");
        $stmt->execute();
        $row = $stmt->fetch();
        return $row ? $row['setting_value'] : '-';
    } catch (Exception $e) {
        return '-';
    }
}


// Helper functions for PHP-based Backup/Restore (No exec required)
function phpMysqlDump($pdo, $dbname, $filepath) {
    $f = fopen($filepath, 'w');
    if (!$f) return false;

    // Header
    fwrite($f, "-- AIS Backup " . date('Y-m-d H:i:s') . "\n");
    fwrite($f, "SET FOREIGN_KEY_CHECKS=0;\n");
    fwrite($f, "SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';\n\n");

    try {
        // Get Tables
        $stmt = $pdo->query("SHOW TABLES");
        $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);

        foreach ($tables as $table) {
            // Drop
            fwrite($f, "DROP TABLE IF EXISTS `$table`;\n");

            // Create
            $stmt = $pdo->query("SHOW CREATE TABLE `$table`");
            $row = $stmt->fetch(PDO::FETCH_NUM);
            if ($row && isset($row[1])) {
                fwrite($f, $row[1] . ";\n\n");
            }

            // Data
            $stmt = $pdo->query("SELECT * FROM `$table`");
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $cols = array_keys($row);
                $vals = array_values($row);
                
                $vals = array_map(function($v) use ($pdo) {
                    if ($v === null) return "NULL";
                    return $pdo->quote($v);
                }, $vals);

                $sql = "INSERT INTO `$table` (`" . implode("`, `", $cols) . "`) VALUES (" . implode(", ", $vals) . ");\n";
                fwrite($f, $sql);
            }
            fwrite($f, "\n");
        }
    } catch (Exception $e) {
        fclose($f);
        return false;
    }

    fwrite($f, "SET FOREIGN_KEY_CHECKS=1;\n");
    fclose($f);
    return true;
}

function phpMysqlRestore($pdo, $filepath) {
    if (!file_exists($filepath)) return false;
    
    // Read entire file? Or line by line. Line by line is safer for memory.
    // However, multi-line statements need care.
    // For our generated backup, statements end with ;\n.
    // We'll use a simple buffer approach.
    
    $pdo->exec("SET FOREIGN_KEY_CHECKS=0");
    
    $handle = fopen($filepath, "r");
    if ($handle) {
        $query = '';
        while (($line = fgets($handle)) !== false) {
            $trim = trim($line);
            // Skip comments
            if ($trim === '' || strpos($trim, '--') === 0 || strpos($trim, '/*') === 0) continue;
            
            $query .= $line;
            if (substr(rtrim($line), -1) === ';') {
                try {
                    $pdo->exec($query);
                } catch (Exception $e) {
                    // Continue on error, or stop?
                    // Ideally log it.
                }
                $query = '';
            }
        }
        fclose($handle);
    } else {
        return false;
    }
    
    $pdo->exec("SET FOREIGN_KEY_CHECKS=1");
    return true;
}

$message = '';
$error = '';

// Handle Actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'create_point') {
        $filename = 'backup_' . date('Y-m-d_H-i-s') . '_' . uniqid() . '.sql';
        $filepath = $backupDir . $filename;
        
        // Execute PHP Backup
        $success = phpMysqlDump($pdo, $dbname, $filepath);
        
        if ($success && file_exists($filepath) && filesize($filepath) > 0) {
            $message = "Restore Point berhasil dibuat: $filename";
            
            // Save Metadata
            $note = trim($_POST['note'] ?? '');
            $version = getCurrentSchemaVersion($pdo);
            saveBackupMeta($filename, [
                'note' => $note,
                'schema_version' => $version,
                'created_at' => date('Y-m-d H:i:s'),
                'created_by' => $_SESSION['user_id'] ?? 'System'
            ]);

        } else {
            $error = "Gagal membuat backup. " . implode("\n", $output);
            if (file_exists($filepath)) unlink($filepath);
        }
    }
    
    if ($action === 'upload_restore') {
        if (isset($_FILES['backup_file']) && $_FILES['backup_file']['error'] === UPLOAD_ERR_OK) {
            $tmpName = $_FILES['backup_file']['tmp_name'];
            $name = basename($_FILES['backup_file']['name']);
            $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
            
            if ($ext !== 'sql') {
                $error = "Hanya file .sql yang diperbolehkan.";
            } else {
                $targetFile = $backupDir . 'uploaded_' . date('YmdHis') . '_' . $name;
                if (move_uploaded_file($tmpName, $targetFile)) {
                    // Auto restore after upload? Or just add to list?
                    // User implies "restore bisa upload", so maybe separate flow.
                    // But to be safe, let's just add it to list first, or allow immediate restore?
                    // Let's add to list with success message, user can then click restore.
                    $message = "File backup berhasil diupload. Silakan klik tombol Restore pada file tersebut di bawah.";
                    
                    // Save Metadata for Upload
                    $note = trim($_POST['note'] ?? 'Uploaded Backup');
                    saveBackupMeta($name, [
                        'note' => $note,
                        'schema_version' => 'Unknown', // Could parse file, but expensive
                        'created_at' => date('Y-m-d H:i:s'),
                        'uploaded_by' => $_SESSION['user_id'] ?? 'System'
                    ]);
                    
                } else {
                    $error = "Gagal mengupload file.";
                }
            }
        } else {
            $error = "Terjadi kesalahan saat upload file.";
        }
    }

    if ($action === 'restore_point') {
        $file = $_POST['file'] ?? '';
        $filepath = $backupDir . basename($file); // Security: basename to prevent traversal
        
        if (file_exists($filepath)) {
            // Execute PHP Restore
            $success = phpMysqlRestore($pdo, $filepath);
            
            if ($success) {
                $message = "Database berhasil dipulihkan ke titik: $file";
            } else {
                $error = "Gagal memulihkan database. Terjadi kesalahan saat memproses file SQL.";
            }
        } else {
            $error = "File backup tidak ditemukan.";
        }
    }

    if ($action === 'delete_point') {
        $file = $_POST['file'] ?? '';
        $filepath = $backupDir . basename($file);
        if (file_exists($filepath)) {
            unlink($filepath);
            deleteBackupMeta(basename($file)); // Delete metadata
            $message = "Restore Point dihapus.";
        }
    }

    if ($action === 'download_point') {
        $file = $_POST['file'] ?? '';
        $filename = basename($file);
        $filepath = $backupDir . $filename;
        
        if (file_exists($filepath)) {
            header('Content-Description: File Transfer');
            header('Content-Type: application/sql');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            header('Content-Length: ' . filesize($filepath));
            readfile($filepath);
            exit;
        } else {
            $error = "File backup tidak ditemukan.";
        }
    }
}

// Get List of Backups
$backups = [];
$files = glob($backupDir . '*.sql');
$meta = getBackupMeta(); // Load all metadata

foreach ($files as $file) {
    $filename = basename($file);
    $fileMeta = $meta[$filename] ?? [];
    
    $backups[] = [
        'name' => $filename,
        'size' => round(filesize($file) / 1024, 2) . ' KB',
        'date' => date('d M Y H:i:s', filemtime($file)),
        'timestamp' => filemtime($file),
        'note' => $fileMeta['note'] ?? '-',
        'schema_version' => $fileMeta['schema_version'] ?? '-'
    ];
}
// Sort by newest first
usort($backups, function($a, $b) {
    return $b['timestamp'] - $a['timestamp'];
});

$dbStats = getDatabaseStats($pdo, $dbname);

require_once '../../includes/header.php';
?>

<div id="app" class="flex flex-col h-screen bg-slate-50">
    <!-- Navbar (Simplified) -->
    <nav class="bg-white border-b border-slate-200 h-16 flex items-center justify-between px-6 z-20 shadow-sm">
        <div class="flex items-center gap-3">
            <a href="index.php" class="w-10 h-10 bg-slate-100 hover:bg-slate-200 rounded-lg flex items-center justify-center text-slate-600 transition-colors">
                <i class="fas fa-arrow-left text-lg"></i>
            </a>
            <div>
                <h1 class="text-xl font-bold text-slate-800 leading-none">Backup & Restore</h1>
                <span class="text-xs text-slate-500 font-medium">System Restore Points</span>
            </div>
        </div>
    </nav>

    <main class="flex-1 overflow-y-auto p-6 max-w-7xl mx-auto w-full">
        
        <?php if ($message): ?>
            <div class="bg-emerald-50 border border-emerald-200 text-emerald-700 px-4 py-3 rounded-lg mb-6 flex items-center gap-2">
                <i class="fas fa-check-circle text-xl"></i>
                <div>
                    <p class="font-bold">Sukses</p>
                    <p class="text-sm"><?php echo htmlspecialchars($message); ?></p>
                </div>
            </div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6 flex items-center gap-2">
                <i class="fas fa-exclamation-triangle text-xl"></i>
                <div>
                    <p class="font-bold">Error</p>
                    <p class="text-sm"><?php echo htmlspecialchars($error); ?></p>
                </div>
            </div>
        <?php endif; ?>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <!-- CREATE BACKUP CARD -->
            <div class="md:col-span-1">
                <div class="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                    <div class="w-16 h-16 bg-blue-100 text-blue-600 rounded-2xl flex items-center justify-center text-3xl mb-4 mx-auto">
                        <i class="fas fa-save"></i>
                    </div>
                    <h2 class="text-xl font-bold text-slate-800 text-center mb-2">Buat Restore Point</h2>
                    <p class="text-slate-500 text-center text-sm mb-6">Simpan kondisi database saat ini agar bisa dikembalikan jika terjadi kesalahan.</p>
                    
                    <form method="POST" onsubmit="return confirm('Buat restore point baru?');">
                        <input type="hidden" name="action" value="create_point">
                        
                        <div class="mb-4">
                            <label class="block text-xs font-bold text-slate-700 mb-2">Catatan Checkpoint</label>
                            <textarea name="note" rows="2" class="w-full text-xs text-slate-600 border border-slate-300 rounded-lg p-2 focus:ring-blue-500 focus:border-blue-500" placeholder="Contoh: Sebelum update fitur Raport..."></textarea>
                        </div>
                        
                        <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-xl shadow-lg shadow-blue-200 transition-all transform hover:-translate-y-1">
                            <i class="fas fa-plus-circle mr-2"></i> Buat Backup Sekarang
                        </button>
                    </form>
                    
                    <div class="mt-6 pt-6 border-t border-slate-100">
                        <div class="flex justify-between items-center mb-2">
                            <h4 class="font-bold text-slate-700 text-sm">Upload Backup (.sql)</h4>
                            <span class="text-[10px] bg-slate-100 text-slate-500 px-2 py-1 rounded-full font-mono">
                                Max: <?php echo ini_get('upload_max_filesize'); ?>
                            </span>
                        </div>
                        <form method="POST" enctype="multipart/form-data" class="flex flex-col gap-2">
                            <input type="hidden" name="action" value="upload_restore">
                            <input type="text" name="note" class="w-full text-xs text-slate-600 border border-slate-300 rounded-lg p-2 focus:ring-blue-500 focus:border-blue-500" placeholder="Catatan untuk file ini...">
                            <input type="file" name="backup_file" accept=".sql" class="block w-full text-xs text-slate-500
                                file:mr-2 file:py-2 file:px-4
                                file:rounded-full file:border-0
                                file:text-xs file:font-semibold
                                file:bg-blue-50 file:text-blue-700
                                hover:file:bg-blue-100
                            " required>
                            <button type="submit" class="w-full bg-slate-600 hover:bg-slate-700 text-white font-bold py-2 px-4 rounded-xl text-xs shadow-sm transition-all">
                                <i class="fas fa-upload mr-2"></i> Upload
                            </button>
                        </form>
                    </div>

                    <div class="mt-6 pt-6 border-t border-slate-100">
                        <h4 class="font-bold text-slate-700 text-sm mb-2">Info Database</h4>
                        <ul class="text-xs text-slate-500 space-y-1">
                            <li class="flex justify-between"><span>Host:</span> <span class="font-mono"><?php echo $host; ?></span></li>
                            <li class="flex justify-between"><span>Database:</span> <span class="font-mono"><?php echo $dbname; ?></span></li>
                            <li class="flex justify-between"><span>User:</span> <span class="font-mono"><?php echo $username; ?></span></li>
                            <li class="flex justify-between"><span>Tables:</span> <span class="font-mono"><?php echo $dbStats['tables']; ?></span></li>
                            <li class="flex justify-between"><span>DB Size:</span> <span class="font-mono"><?php echo $dbStats['size']; ?></span></li>
                            <li class="flex justify-between"><span>MySQL Ver:</span> <span class="font-mono text-[10px]"><?php echo $dbStats['version']; ?></span></li>
                            <li class="flex justify-between border-t border-slate-100 pt-1 mt-1">
                                <span>Current Schema:</span> 
                                <span class="font-mono font-bold text-blue-600"><?php echo getCurrentSchemaVersion($pdo); ?></span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            <!-- RESTORE LIST -->
            <div class="md:col-span-2">
                <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                    <div class="p-4 border-b border-slate-100 bg-slate-50 flex justify-between items-center">
                        <h3 class="font-bold text-slate-800">Riwayat Restore Point</h3>
                        <span class="bg-blue-100 text-blue-700 text-xs font-bold px-2 py-1 rounded-full"><?php echo count($backups); ?> Point</span>
                    </div>
                    
                    <?php if (empty($backups)): ?>
                        <div class="p-12 text-center">
                            <i class="fas fa-history text-4xl text-slate-200 mb-4"></i>
                            <p class="text-slate-400 font-medium">Belum ada restore point yang dibuat.</p>
                        </div>
                    <?php else: ?>
                        <div class="overflow-x-auto">
                            <table class="w-full text-sm text-left">
                                <thead class="bg-slate-50 text-slate-500 font-bold uppercase text-xs">
                                    <tr>
                                        <th class="px-6 py-3">Waktu Backup</th>
                                        <th class="px-6 py-3">Checkpoint / Note</th>
                                        <th class="px-6 py-3">Schema</th>
                                        <th class="px-6 py-3">Ukuran</th>
                                        <th class="px-6 py-3 text-right">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-slate-100">
                                    <?php foreach ($backups as $backup): ?>
                                    <tr class="hover:bg-slate-50 group">
                                        <td class="px-6 py-4 font-bold text-slate-700">
                                            <div class="flex items-center gap-3">
                                                <div class="w-8 h-8 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center">
                                                    <i class="fas fa-check"></i>
                                                </div>
                                                <div class="flex flex-col">
                                                    <span><?php echo $backup['date']; ?></span>
                                                    <span class="text-[10px] text-slate-400 font-mono"><?php echo $backup['name']; ?></span>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="px-6 py-4 text-slate-600 text-sm">
                                            <?php if($backup['note'] && $backup['note'] !== '-'): ?>
                                                <p class="font-medium"><?php echo htmlspecialchars($backup['note']); ?></p>
                                            <?php else: ?>
                                                <span class="text-slate-400 italic text-xs">Tidak ada catatan</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="px-6 py-4">
                                            <?php if($backup['schema_version'] && $backup['schema_version'] !== '-'): ?>
                                                <span class="bg-blue-100 text-blue-700 text-[10px] font-bold px-2 py-1 rounded-full font-mono">
                                                    <?php echo htmlspecialchars($backup['schema_version']); ?>
                                                </span>
                                            <?php else: ?>
                                                <span class="text-slate-400 text-xs">-</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="px-6 py-4 text-slate-500 text-xs"><?php echo $backup['size']; ?></td>
                                        <td class="px-6 py-4 text-right">
                                            <div class="flex items-center justify-end gap-2">
                                                <form method="POST">
                                                    <input type="hidden" name="action" value="download_point">
                                                    <input type="hidden" name="file" value="<?php echo $backup['name']; ?>">
                                                    <button type="submit" class="text-slate-400 hover:text-blue-600 px-2 py-1 transition-colors" title="Download SQL">
                                                        <i class="fas fa-download"></i>
                                                    </button>
                                                </form>
                                                    <button type="button" onclick="openRestoreModal('<?php echo $backup['name']; ?>')" class="bg-white border border-slate-300 text-slate-600 hover:bg-blue-50 hover:text-blue-600 hover:border-blue-300 px-3 py-1.5 rounded-lg text-xs font-bold transition-all shadow-sm">
                                                        <i class="fas fa-undo-alt mr-1"></i> Restore
                                                    </button>
                                                <form method="POST" onsubmit="return confirm('Hapus restore point ini secara permanen?');">
                                                    <input type="hidden" name="action" value="delete_point">
                                                    <input type="hidden" name="file" value="<?php echo $backup['name']; ?>">
                                                    <button type="submit" class="text-slate-400 hover:text-red-600 px-2 py-1 transition-colors" title="Hapus Backup">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>

<?php require_once '../../includes/footer.php'; ?>

<!-- Restore Confirmation Modal -->
<div id="restoreModal" class="fixed inset-0 bg-slate-900/50 hidden z-50 flex items-center justify-center backdrop-blur-sm p-4">
    <div class="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 transform transition-all scale-100">
        <div class="text-center mb-6">
            <div class="w-16 h-16 bg-red-100 text-red-600 rounded-full flex items-center justify-center text-3xl mx-auto mb-4">
                <i class="fas fa-exclamation-triangle"></i>
            </div>
            <h3 class="text-xl font-bold text-slate-800">Konfirmasi Restore</h3>
            <p class="text-slate-500 text-sm mt-2">
                Tindakan ini akan <strong class="text-red-600">MENIMPA</strong> seluruh database saat ini. 
                Data yang ada akan hilang dan digantikan dengan data dari backup <span id="restoreFileName" class="font-mono bg-slate-100 px-1 rounded text-xs"></span>.
            </p>
        </div>

        <form method="POST" id="restoreForm">
            <input type="hidden" name="action" value="restore_point">
            <input type="hidden" name="file" id="restoreFileConf">
            
            <div class="bg-slate-50 p-4 rounded-xl border border-slate-200 mb-6">
                <label class="block text-xs font-bold text-slate-500 uppercase mb-2 text-center">Masukkan Kode Verifikasi</label>
                <div class="flex items-center justify-center gap-4 mb-3">
                    <span id="randomCode" class="text-3xl font-mono font-bold text-slate-700 tracking-widest bg-white border border-slate-300 px-4 py-2 rounded-lg select-none"></span>
                    <button type="button" onclick="generateCode()" class="text-slate-400 hover:text-blue-600">
                        <i class="fas fa-sync-alt"></i>
                    </button>
                </div>
                <input type="text" id="codeParams" class="w-full text-center text-xl font-bold tracking-widest border-slate-300 rounded-lg focus:ring-red-500 focus:border-red-500 uppercase" placeholder="____" maxlength="4" oninput="checkCode()">
                <p class="text-xs text-center text-slate-400 mt-2">Ketik kode di atas untuk membuka tombol konfirmasi</p>
            </div>

            <div class="flex gap-3">
                <button type="button" onclick="closeRestoreModal()" class="flex-1 px-4 py-2 bg-white border border-slate-300 text-slate-700 font-bold rounded-xl hover:bg-slate-50">
                    Batal
                </button>
                <button type="submit" id="btnConfirmRestore" disabled class="flex-1 px-4 py-2 bg-red-600 text-white font-bold rounded-xl hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-red-200">
                    <i class="fas fa-undo-alt mr-2"></i> Restore Database
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    let currentCode = '';

    function generateCode() {
        currentCode = Math.floor(1000 + Math.random() * 9000).toString();
        document.getElementById('randomCode').textContent = currentCode;
        document.getElementById('codeParams').value = '';
        checkCode();
    }

    function openRestoreModal(filename) {
        document.getElementById('restoreFileName').textContent = filename;
        document.getElementById('restoreFileConf').value = filename;
        generateCode();
        document.getElementById('restoreModal').classList.remove('hidden');
        document.getElementById('codeParams').focus();
    }

    function closeRestoreModal() {
        document.getElementById('restoreModal').classList.add('hidden');
    }

    function checkCode() {
        const input = document.getElementById('codeParams').value;
        const btn = document.getElementById('btnConfirmRestore');
        if (input === currentCode) {
            btn.disabled = false;
        } else {
            btn.disabled = true;
        }
    }
</script>
